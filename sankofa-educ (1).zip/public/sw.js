/* Service Worker pour Sankofa Educ - Push Notifications & Rappels de Révision */

const CACHE_NAME = 'sankofa-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/pwa-icon.png'
];

// Installation & mise en cache initiale
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {});
    })
  );
});

// Activation et nettoyage des anciens caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Réception des notifications Push du serveur
self.addEventListener('push', (event) => {
  let data = {
    title: '📚 Sankofa Educ - Rappel de Révision',
    body: "C'est l'heure de ta session quotidienne de révision ! Viens tester tes connaissances.",
    icon: '/pwa-icon.png',
    badge: '/pwa-icon.png',
    url: '/'
  };

  if (event.data) {
    try {
      data = { ...data, ...event.data.json() };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: data.icon || '/pwa-icon.png',
    badge: data.badge || '/pwa-icon.png',
    vibrate: [100, 50, 100],
    data: { url: data.url || '/' },
    actions: [
      { action: 'open', title: 'Réviser maintenant 🚀' },
      { action: 'close', title: 'Plus tard' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Clic sur la notification
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'close') return;

  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

// Communication avec l'application (Messages client)
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SHOW_TEST_NOTIFICATION') {
    const { title, body } = event.data;
    self.registration.showNotification(title || '📚 Rappel de Révision Sankofa', {
      body: body || "C'est l'heure de réviser tes cours pour le BEPC / BAC !",
      icon: '/pwa-icon.png',
      badge: '/pwa-icon.png',
      vibrate: [200, 100, 200],
      tag: 'sankofa-reminder',
      actions: [
        { action: 'open', title: 'Ouvrir Sankofa 🚀' }
      ]
    });
  }
});
