/* Firebase Cloud Messaging Service Worker for Sankofa Educ */
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

firebase.initializeApp({
  projectId: "subtle-box-n7c1c",
  appId: "1:27739222968:web:2a752439cdaa006e30154d",
  apiKey: "AIzaSyCN77HxENoyf4ERbrcwyTYEBnhYe5BI5gk",
  authDomain: "subtle-box-n7c1c.firebaseapp.com",
  storageBucket: "subtle-box-n7c1c.firebasestorage.app",
  messagingSenderId: "27739222968"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Background notification received:', payload);
  const title = payload.notification?.title || payload.data?.title || '📚 Sankofa Educ';
  const body = payload.notification?.body || payload.data?.body || 'Nouvelle notification de révision !';
  
  const notificationOptions = {
    body,
    icon: '/pwa-icon.png',
    badge: '/pwa-icon.png',
    vibrate: [100, 50, 100],
    data: payload.data || { url: '/' },
    actions: [
      { action: 'open', title: 'Ouvrir Sankofa 🚀' }
    ]
  };

  self.registration.showNotification(title, notificationOptions);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = event.notification.data?.url || '/';
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
