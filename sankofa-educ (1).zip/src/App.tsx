/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  Award,
  Camera,
  Play,
  User,
  Bell,
  BellOff,
  Sparkles,
  Smartphone,
  Maximize2,
  Minimize2,
  Crown,
  LogOut,
  ChevronRight,
  Plus,
  Compass,
  TrendingUp,
  FileText,
  Clock,
  CheckCircle,
  HelpCircle,
  Shield,
  Activity,
  Loader2,
  AlertCircle,
  Edit3,
  WifiOff,
  MessageSquare,
  RefreshCw,
  Power,
  PowerOff
} from 'lucide-react';

// Modular child components
import Splash from './components/Splash';
import Auth from './components/Auth';
import RevisionSheets from './components/RevisionSheets';
import QuizView from './components/QuizView';
import AIScanner from './components/AIScanner';
import VideosView from './components/VideosView';
import ForumView from './components/ForumView';
import SankofaLogo from './components/SankofaLogo';
import AdminPanel from './components/AdminPanel';
import ProfileEdit from './components/ProfileEdit';

import { RevisionSheet, Quiz, ExamType, AppNotification } from './types';
import { getReminderSettings, sendTestNotification } from './lib/pwaNotification';
import { initializeFCM, setupFcmForegroundListener } from './lib/fcm';

type ActiveTab = 'home' | 'sheets' | 'scanner' | 'videos' | 'forum' | 'profile';

export default function App() {
  // Navigation & Frame wrapper states
  const [appState, setAppState] = useState<'splash' | 'auth' | 'app'>('splash');
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  
  // Server-synced states
  const [user, setUser] = useState<{ name: string; email: string; phone: string; targetExam: ExamType; series: string } | null>(null);
  const [sheets, setSheets] = useState<RevisionSheet[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_sheets');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_quizzes');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [downloads, setDownloads] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_downloads');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [completedSheets, setCompletedSheets] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_completed_sheets');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [completedQuizzes, setCompletedQuizzes] = useState<{ id: string; score: number; total: number }[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_completed_quizzes');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_notifications');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isPremium, setIsPremium] = useState(true);
  const [studyStats, setStudyStats] = useState(() => {
    try {
      const saved = localStorage.getItem('sankofa_cached_study_stats');
      return saved ? JSON.parse(saved) : { totalTime: 0, quizAvg: 0, rank: 'Élève motivé' };
    } catch {
      return { totalTime: 0, quizAvg: 0, rank: 'Élève motivé' };
    }
  });

  const [isOffline, setIsOffline] = useState(() => !navigator.onLine);
  const [appStatus, setAppStatus] = useState<'active' | 'inactive'>('active');

  // Periodic check for app status (republication detection)
  useEffect(() => {
    const checkAppStatus = async () => {
      try {
        const res = await fetch('/api/app/status');
        const data = await res.json();
        if (data.success && data.appStatus) {
          setAppStatus(data.appStatus);
        }
      } catch (e) {
        // network or server error fallback
      }
    };
    checkAppStatus();
    const interval = setInterval(checkAppStatus, 8000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      triggerToast('Connexion Internet rétablie ! ⚡');
      fetchData();
    };
    const handleOffline = () => {
      setIsOffline(true);
      triggerToast('Connexion Internet perdue. Mode hors-ligne activé 📡');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [user?.email]);

  // Periodic check for PWA daily revision reminder alarm
  useEffect(() => {
    let lastNotifiedMinute = '';
    const interval = setInterval(() => {
      const settings = getReminderSettings();
      if (!settings.enabled) return;

      const now = new Date();
      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const timeStr = `${currentHours}:${currentMinutes}`;

      if (timeStr === settings.time && lastNotifiedMinute !== timeStr) {
        lastNotifiedMinute = timeStr;
        sendTestNotification(
          '⏰ Heure de Révision Sankofa !',
          `C'est l'heure de ta session quotidienne pour le ${user?.targetExam || 'BAC/BEPC'} !`
        );
      }
    }, 30000); // Check every 30s

    return () => clearInterval(interval);
  }, [user?.targetExam]);

  // Firebase Cloud Messaging (FCM) Initialization & Foreground Listener
  useEffect(() => {
    if (user && user.email) {
      initializeFCM(user.email).then((token) => {
        if (token) {
          console.log('[App] FCM Token active for user:', user.email);
        }
      });
    } else {
      initializeFCM().catch(() => {});
    }

    setupFcmForegroundListener((payload) => {
      const title = payload.notification?.title || payload.data?.title || '📚 Sankofa Educ FCM';
      const body = payload.notification?.body || payload.data?.body || 'Nouvelle notification !';
      
      triggerToast(`🔔 Notification Push FCM: ${title}`);
      
      const newNotif: AppNotification = {
        id: `fcm-${Date.now()}`,
        title,
        body,
        read: false,
        type: 'info',
        date: new Date().toISOString()
      };

      setNotifications((prev) => [newNotif, ...prev]);
    });
  }, [user?.email]);

  // Secondary interactive overlays
  const [activeQuizId, setActiveQuizId] = useState<string | null>(null);
  const [showQuizSelectionModal, setShowQuizSelectionModal] = useState(false);
  const [videoSearchKeywords, setVideoSearchKeywords] = useState('');
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showProfileEdit, setShowProfileEdit] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [isFocusActive, setIsFocusActive] = useState(false);

  // Real-time CinetPay transaction verification states
  const [cinetpayCheckingTx, setCinetpayCheckingTx] = useState<string | null>(null);
  const [cinetpayCheckStatus, setCinetpayCheckStatus] = useState<'checking' | 'success' | 'failed' | null>(null);
  const [cinetpayMessage, setCinetpayMessage] = useState<string>('');

  // Fetch all user session data on startup & when refreshed
  const fetchData = async (currentUser?: any) => {
    const activeUser = currentUser !== undefined ? currentUser : user;
    try {
      const url = activeUser ? `/api/data?userId=${encodeURIComponent(activeUser.email)}` : '/api/data';
      const response = await fetch(url);
      const data = await response.json();
      if (data.success) {
        if (data.appStatus) setAppStatus(data.appStatus);
        setSheets(data.sheets || []);
        setQuizzes(data.quizzes || []);
        localStorage.setItem('sankofa_cached_sheets', JSON.stringify(data.sheets || []));
        localStorage.setItem('sankofa_cached_quizzes', JSON.stringify(data.quizzes || []));

        if (activeUser && activeUser.email) {
          try {
            const { dbLoadAllUserData } = await import('./lib/firebase');
            const defaultData = {
              profile: {
                email: activeUser.email,
                name: activeUser.name,
                phone: activeUser.phone,
                targetExam: activeUser.targetExam,
                series: activeUser.series
              },
              progress: {
                userId: activeUser.email,
                quizCount: 0,
                studyTimeMinutes: 0,
                streakDays: 0,
                completedQuizzes: [],
                completedSheets: [],
                favorites: data.favorites || [],
                downloads: data.downloads || []
              },
              subscription: {
                userId: activeUser.email,
                isPremium: true,
                trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
                history: []
              },
              notifications: data.notifications || []
            };

            const fsData = await dbLoadAllUserData(activeUser.email, defaultData);
            if (fsData) {
              setFavorites(fsData.progress.favorites || []);
              setDownloads(fsData.progress.downloads || []);
              setCompletedSheets(fsData.progress.completedSheets || []);
              setCompletedQuizzes(fsData.progress.completedQuizzes || []);
              setNotifications(fsData.notifications || []);
              setIsPremium(true);

              const quizCount = fsData.progress.completedQuizzes?.length || 0;
              const totalStudyTime = fsData.progress.studyTimeMinutes || 0;
              const quizAvg = fsData.progress.completedQuizzes && fsData.progress.completedQuizzes.length > 0
                ? Math.round(fsData.progress.completedQuizzes.reduce((acc: number, q: any) => acc + (q.score / q.total), 0) / fsData.progress.completedQuizzes.length * 100)
                : 0;

              const stats = {
                totalTime: totalStudyTime,
                quizAvg: quizAvg,
                rank: fsData.subscription.isPremium ? 'Major de promo 👑' : 'Élève motivé'
              };
              setStudyStats(stats);

              // Update offline cache for user progress
              localStorage.setItem('sankofa_cached_favorites', JSON.stringify(fsData.progress.favorites || []));
              localStorage.setItem('sankofa_cached_downloads', JSON.stringify(fsData.progress.downloads || []));
              localStorage.setItem('sankofa_cached_completed_sheets', JSON.stringify(fsData.progress.completedSheets || []));
              localStorage.setItem('sankofa_cached_completed_quizzes', JSON.stringify(fsData.progress.completedQuizzes || []));
              localStorage.setItem('sankofa_cached_notifications', JSON.stringify(fsData.notifications || []));
              localStorage.setItem('sankofa_cached_study_stats', JSON.stringify(stats));
              return;
            }
          } catch (fsErr) {
            console.error("Failed to load from Firestore, falling back to local API:", fsErr);
          }
        }

        setFavorites(data.favorites || []);
        setDownloads(data.downloads || []);
        setCompletedSheets(data.completedSheets || []);
        setCompletedQuizzes(data.completedQuizzes || []);
        setNotifications(data.notifications || []);
        setIsPremium(true);
        if (data.stats) {
          setStudyStats(data.stats);
          localStorage.setItem('sankofa_cached_study_stats', JSON.stringify(data.stats));
        }

        // Cache local API responses
        localStorage.setItem('sankofa_cached_favorites', JSON.stringify(data.favorites || []));
        localStorage.setItem('sankofa_cached_downloads', JSON.stringify(data.downloads || []));
        localStorage.setItem('sankofa_cached_completed_sheets', JSON.stringify(data.completedSheets || []));
        localStorage.setItem('sankofa_cached_completed_quizzes', JSON.stringify(data.completedQuizzes || []));
        localStorage.setItem('sankofa_cached_notifications', JSON.stringify(data.notifications || []));
      }
    } catch (err) {
      console.warn("Erreur lors de la récupération des données en ligne, chargement depuis le cache local :", err);
      // Attempt to load everything from localStorage offline cache
      try {
        const cachedSheets = localStorage.getItem('sankofa_cached_sheets');
        const cachedQuizzes = localStorage.getItem('sankofa_cached_quizzes');
        const cachedFavorites = localStorage.getItem('sankofa_cached_favorites');
        const cachedDownloads = localStorage.getItem('sankofa_cached_downloads');
        const cachedCompletedSheets = localStorage.getItem('sankofa_cached_completed_sheets');
        const cachedCompletedQuizzes = localStorage.getItem('sankofa_cached_completed_quizzes');
        const cachedNotifications = localStorage.getItem('sankofa_cached_notifications');
        const cachedStats = localStorage.getItem('sankofa_cached_study_stats');

        if (cachedSheets) setSheets(JSON.parse(cachedSheets));
        if (cachedQuizzes) setQuizzes(JSON.parse(cachedQuizzes));
        if (cachedFavorites) setFavorites(JSON.parse(cachedFavorites));
        if (cachedDownloads) setDownloads(JSON.parse(cachedDownloads));
        if (cachedCompletedSheets) setCompletedSheets(JSON.parse(cachedCompletedSheets));
        if (cachedCompletedQuizzes) setCompletedQuizzes(JSON.parse(cachedCompletedQuizzes));
        if (cachedNotifications) setNotifications(JSON.parse(cachedNotifications));
        if (cachedStats) setStudyStats(JSON.parse(cachedStats));

        setIsOffline(true);
      } catch (cacheErr) {
        console.error("Failed to load offline cache :", cacheErr);
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, [user?.email]);

  const verifyCinetpayTx = async (txId: string) => {
    setCinetpayCheckStatus('checking');
    try {
      const response = await fetch('/api/payments/verify-cinetpay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionId: txId,
          userId: user?.email
        })
      });
      const data = await response.json();
      if (data.success) {
        setIsPremium(true);
        setCinetpayCheckStatus('success');
        fetchData();
        
        // Sync subscription state to Firestore immediately
        if (user?.email && data.subscription) {
          try {
            const { dbSaveSubscription } = await import('./lib/firebase');
            await dbSaveSubscription(user.email, {
              isPremium: true,
              expiresAt: data.subscription.expiresAt,
              paymentMethod: data.subscription.paymentMethod || 'CinetPay',
              phoneNumber: data.subscription.phoneNumber || '',
              history: data.subscription.history || []
            });
          } catch (fsErr) {
            console.error("Failed to save CinetPay subscription sync to Firestore:", fsErr);
          }
        }
      } else {
        setCinetpayCheckStatus('failed');
        setCinetpayMessage(data.error || data.message || "La vérification a échoué.");
      }
    } catch (err) {
      setCinetpayCheckStatus('failed');
      setCinetpayMessage("Impossible de se connecter au service de vérification. Veuillez vérifier votre connexion.");
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const payment = params.get('payment');
    const tx = params.get('tx');
    if (payment === 'check' && tx) {
      setCinetpayCheckingTx(tx);
      verifyCinetpayTx(tx);
      // Clean up search parameters without page reload
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [user?.email]);

  // Quick helper to trigger custom mobile toast message
  const triggerToast = (msg: string) => {
    // Silently block/disable notification toasts during focus mode
    if (isFocusActive) {
      console.log(`[Mode Focus] Notification bloquée : ${msg}`);
      return;
    }
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 4000);
  };

  // Auth Completed trigger
  const handleAuthSuccess = async (authUser: { name: string; email: string; phone: string; targetExam: ExamType; series: string }) => {
    localStorage.setItem('sankofa_user', JSON.stringify(authUser));
    setUser(authUser);
    setShowAdminPanel(false);
    setAppState('app');
    triggerToast(`Heureux de vous revoir, ${authUser.name} ! 👋`);

    try {
      const { dbSaveProfile } = await import('./lib/firebase');
      await dbSaveProfile(authUser.email, authUser);
    } catch (fsErr) {
      console.error("Failed to save user profile to Firestore:", fsErr);
    }
  };

  // Helper to determine if a resource belongs to the current user's series
  const isResourceInSeries = (
    exam: ExamType,
    subject: string,
    title: string,
    seriesList?: string[],
    userSeriesVal?: string
  ): boolean => {
    const activeSeries = userSeriesVal || user?.series || 'D';
    if (exam !== 'BAC') return true;
    if (seriesList && seriesList.length > 0) {
      return seriesList.includes(activeSeries);
    }
    const titleLower = title.toLowerCase();
    const subjLower = subject.toLowerCase();

    if (activeSeries === 'A') {
      if (subjLower.includes('physique') || subjLower.includes('chimie')) return false;
      if (titleLower.includes('terminale d') || titleLower.includes('terminale c') || titleLower.includes('terminale s')) {
        if (!titleLower.includes('terminale a')) return false;
      }
      return true;
    }
    if (activeSeries === 'C') {
      if (titleLower.includes('terminale d') && !titleLower.includes('terminale c') && !titleLower.includes('terminale s')) {
        return false;
      }
      return true;
    }
    if (activeSeries === 'D') {
      if (titleLower.includes('terminale c') && !titleLower.includes('terminale d') && !titleLower.includes('terminale s')) {
        return false;
      }
      return true;
    }
    return true;
  };

  // Sync favorites with database
  const handleToggleFavorite = async (id: string) => {
    try {
      const response = await fetch('/api/user/favorite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, userId: user?.email })
      });
      const data = await response.json();
      if (data.success) {
        setFavorites(data.favorites);
        const added = data.favorites.includes(id);
        triggerToast(added ? 'Fiche ajoutée à vos favoris ⭐' : 'Fiche retirée de vos favoris');

        if (user?.email) {
          try {
            const { dbSaveProgress } = await import('./lib/firebase');
            await dbSaveProgress(user.email, {
              quizCount: completedQuizzes.length,
              studyTimeMinutes: studyStats.totalTime,
              streakDays: 3,
              completedQuizzes,
              completedSheets,
              favorites: data.favorites,
              downloads
            });
          } catch (fsErr) {
            console.error("Failed to sync favorites with Firestore:", fsErr);
          }
        }
      }
    } catch (err) {
      triggerToast('Erreur de réseau');
    }
  };

  // Sync downloads with database
  const handleToggleDownload = async (id: string) => {
    try {
      const response = await fetch('/api/user/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, userId: user?.email })
      });
      const data = await response.json();
      if (data.success) {
        setDownloads(data.downloads);
        const downloaded = data.downloads.includes(id);
        triggerToast(downloaded ? 'Leçon téléchargée pour révision hors-ligne 💾' : 'Fiche supprimée de l\'appareil');

        if (user?.email) {
          try {
            const { dbSaveProgress } = await import('./lib/firebase');
            await dbSaveProgress(user.email, {
              quizCount: completedQuizzes.length,
              studyTimeMinutes: studyStats.totalTime,
              streakDays: 3,
              completedQuizzes,
              completedSheets,
              favorites,
              downloads: data.downloads
            });
          } catch (fsErr) {
            console.error("Failed to sync downloads with Firestore:", fsErr);
          }
        }
      }
    } catch (err) {
      triggerToast('Erreur de réseau');
    }
  };

  // Mark revision card as read
  const handleMarkAsRead = async (id: string) => {
    if (completedSheets.includes(id)) return;
    try {
      const response = await fetch('/api/user/sheet/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, userId: user?.email })
      });
      const data = await response.json();
      if (data.success) {
        setCompletedSheets(data.completedSheets);
        triggerToast('Cours validé ! +15 min de révision 📚');

        if (user?.email) {
          try {
            const { dbSaveProgress } = await import('./lib/firebase');
            await dbSaveProgress(user.email, {
              quizCount: completedQuizzes.length,
              studyTimeMinutes: studyStats.totalTime + 15,
              streakDays: 3,
              completedQuizzes,
              completedSheets: data.completedSheets,
              favorites,
              downloads
            });
          } catch (fsErr) {
            console.error("Failed to sync completed sheets with Firestore:", fsErr);
          }
        }
        fetchData(); // Sync updated stats
      }
    } catch (err) {
      console.log(err);
    }
  };

  // Completed quiz submission handler
  const handleQuizComplete = async (score: number, total: number) => {
    if (!activeQuizId) return;
    try {
      const response = await fetch('/api/user/quiz/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeQuizId, score, total, userId: user?.email })
      });
      const data = await response.json();
      if (data.success) {
        setCompletedQuizzes(data.completedQuizzes);
        triggerToast('Quiz validé ! Vos statistiques ont été mises à jour ⭐');

        if (user?.email) {
          try {
            const { dbSaveProgress, dbSaveNotification } = await import('./lib/firebase');
            await dbSaveProgress(user.email, {
              quizCount: data.completedQuizzes.length,
              studyTimeMinutes: studyStats.totalTime + 15,
              streakDays: 3,
              completedQuizzes: data.completedQuizzes,
              completedSheets,
              favorites,
              downloads
            });

            if (score === total) {
              const perfectNotif = {
                id: `notif-${Date.now()}`,
                title: 'Score Parfait ! 🎉',
                body: `Félicitations ! Vous avez obtenu un score parfait de ${score}/${total} sur un quiz.`,
                date: new Date().toISOString(),
                read: false,
                type: 'quiz'
              };
              await dbSaveNotification(user.email, perfectNotif);
            }
          } catch (fsErr) {
            console.error("Failed to sync quiz completed with Firestore:", fsErr);
          }
        }
        fetchData(); // Sync updated statistics
      }
    } catch (err) {
      console.log(err);
    }
  };

  // Notification reading trigger
  const handleReadNotification = async (id: string) => {
    try {
      const response = await fetch('/api/user/notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, userId: user?.email })
      });
      const data = await response.json();
      if (data.success) {
        setNotifications(data.notifications);

        if (user?.email) {
          try {
            const { dbSaveNotification } = await import('./lib/firebase');
            const target = data.notifications.find((n: any) => n.id === id);
            if (target) {
              await dbSaveNotification(user.email, target);
            }
          } catch (fsErr) {
            console.error("Failed to sync notifications with Firestore:", fsErr);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  };

  // AIScanner successful callback
  const handleScanSuccess = (newSheet: RevisionSheet, newQuiz: Quiz) => {
    fetchData(); // Refresh list to get new items
    triggerToast('Cours numérisé ! Fiche et Quiz générés avec l\'IA ! ✨');
    // Set view to sheets directly to review it
    setActiveTab('sheets');
  };

  // Watch video search launcher
  const handleLaunchVideoSearch = (keywords: string) => {
    setVideoSearchKeywords(keywords);
    setActiveTab('videos');
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-start font-sans overflow-hidden select-none w-full">
      {/* Main layout container (gorgeous normal responsive web view) */}
      <div
        className="w-full max-w-lg md:max-w-2xl lg:max-w-4xl xl:max-w-5xl h-screen flex flex-col bg-white md:shadow-xl md:border-x md:border-stone-200/50 relative overflow-hidden"
        id="applet-frame"
      >
        {/* Dynamic Mobile Toast notification overlay */}
        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 20, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              className="absolute top-4 inset-x-4 bg-stone-900/95 border border-stone-700 text-amber-400 px-4 py-3 rounded-2xl text-xs shadow-xl z-50 flex items-center gap-2 font-semibold backdrop-blur-md"
            >
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0 animate-spin" style={{ animationDuration: '4s' }} />
              <span>{toastMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Dynamic active sub-screen manager */}
        <div className="flex-1 overflow-hidden flex flex-col bg-[#fcfbf7] relative">
          <AnimatePresence mode="wait">
            
            {/* REPUBLICATION INACTIVE APPLICATION OVERLAY */}
            {appStatus === 'inactive' && !showAdminPanel && (
              <motion.div
                key="inactive-screen"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-stone-950 text-white z-40 flex flex-col items-center justify-center p-6 text-center"
              >
                <div className="max-w-sm w-full bg-stone-900/95 border border-amber-500/30 rounded-3xl p-6 shadow-2xl backdrop-blur-md flex flex-col items-center space-y-5">
                  {/* Icon */}
                  <div className="relative">
                    <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-center text-amber-500 shadow-inner">
                      <RefreshCw className="w-8 h-8 animate-spin text-amber-400" />
                    </div>
                    <span className="absolute -bottom-2 -right-2 bg-amber-500 text-stone-950 font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider animate-bounce">
                      Républication
                    </span>
                  </div>

                  {/* Title & Description */}
                  <div className="space-y-1.5">
                    <h3 className="text-base font-black font-display text-amber-400">
                      Application Inactive (Républication)
                    </h3>
                    <p className="text-xs text-stone-300 leading-relaxed font-medium">
                      Une républication et mise à jour des cours et exercices <strong className="text-white font-bold">BEPC & BAC</strong> est actuellement en cours.
                    </p>
                  </div>

                  {/* Status Banner */}
                  <div className="w-full bg-stone-950/80 border border-stone-800 rounded-xl p-3 text-left space-y-1.5">
                    <div className="flex items-center justify-between text-[10px] font-bold">
                      <span className="text-stone-400">Statut Républication :</span>
                      <span className="text-amber-400 flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                        Inactif / Maintenance
                      </span>
                    </div>
                    <p className="text-[10px] text-stone-400 leading-normal">
                      L'accès aux cours et examens est temporairement suspendu. L'application redeviendra active automatiquement dès la fin de la républication.
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="w-full space-y-2.5 pt-1">
                    <button
                      type="button"
                      onClick={async () => {
                        triggerToast('Vérification du statut de l\'application...');
                        try {
                          const res = await fetch('/api/app/status');
                          const data = await res.json();
                          if (data.success && data.appStatus) {
                            setAppStatus(data.appStatus);
                            if (data.appStatus === 'active') {
                              triggerToast('L\'application est à nouveau active ! 🎉');
                            } else {
                              triggerToast('Républication toujours en cours. Patientez un instant.');
                            }
                          }
                        } catch (e) {
                          triggerToast('Serveur indisponible.');
                        }
                      }}
                      className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md active:scale-98"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Vérifier la disponibilité</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowAdminPanel(true)}
                      className="text-[10px] text-stone-400 hover:text-amber-400 font-semibold underline underline-offset-4 transition-colors cursor-pointer"
                    >
                      Espace Administration / Enseignant (Accès Admin)
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* SPLASH LAUNCH SCREEN */}
            {appState === 'splash' && (
              <motion.div key="splash" className="h-full" exit={{ opacity: 0 }}>
                <Splash onComplete={() => setAppState('auth')} />
              </motion.div>
            )}

            {/* REGISTER & PHONE OTP AUTH SCREEN */}
            {appState === 'auth' && (
              <motion.div key="auth" className="h-full" exit={{ opacity: 0 }}>
                <Auth onSuccess={handleAuthSuccess} onAdminClick={() => setShowAdminPanel(true)} />
              </motion.div>
            )}

            {/* CORE APPLICATION AND DASHBOARD */}
            {appState === 'app' && user && (
              <motion.div
                key="application"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col justify-between relative"
              >
                
                {/* INTERACTIVE COMPONENT MODALS OVERLAYS */}
                
                {/* 1. QUIZ SCREEN OVERLAY */}
                {activeQuizId && (
                  <div className="absolute inset-0 bg-[#fcfbf7] z-40 flex flex-col">
                    {(() => {
                      const quizObj = quizzes.find((q) => q.id === activeQuizId);
                      if (quizObj) {
                        return (
                          <QuizView
                            quiz={quizObj}
                            onComplete={handleQuizComplete}
                            onClose={() => setActiveQuizId(null)}
                          />
                        );
                      }
                      return null;
                    })()}
                  </div>
                )}

                {/* 1.5. QUIZ SELECTION AND FOMESOUTRA DEVOIRS & EXERCICES MODAL */}
                {showQuizSelectionModal && (
                  <div className="absolute inset-0 bg-[#fcfbf7] z-40 flex flex-col overflow-hidden">
                    {/* Header */}
                    <div className="p-4 bg-white border-b border-stone-200/50 flex justify-between items-center shrink-0 shadow-xs">
                      <div className="flex flex-col">
                        <span className="text-[9px] font-black uppercase tracking-widest text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full inline-block self-start">
                          Évaluations • {user.targetExam}
                        </span>
                        <h3 className="text-xs font-bold text-stone-800 font-display mt-0.5">Quiz de niveau & Devoirs</h3>
                      </div>
                      <button
                        onClick={() => setShowQuizSelectionModal(false)}
                        className="text-stone-500 hover:text-stone-700 font-bold text-xs bg-stone-100 px-2.5 py-1.5 rounded-xl cursor-pointer"
                      >
                        Fermer
                      </button>
                    </div>

                    {/* Scrollable content */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
                      
                      {/* Section: Sankofa Quizzes */}
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-stone-400 flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-orange-600" />
                            Quiz Interactifs Sankofa
                          </h4>
                        </div>

                        {/* List of quizzes */}
                        <div className="space-y-2.5">
                          {quizzes.filter((q) => q.exam === user.targetExam && isResourceInSeries(q.exam, q.subject, q.title, q.series)).length > 0 ? (
                            quizzes
                              .filter((q) => q.exam === user.targetExam && isResourceInSeries(q.exam, q.subject, q.title, q.series))
                              .map((quiz) => {
                                const attempt = completedQuizzes.find((cq) => cq.id === quiz.id);
                                return (
                                  <div
                                    key={quiz.id}
                                    className="bg-white border border-stone-200/60 p-3.5 rounded-2xl flex items-center justify-between gap-3 shadow-xs"
                                  >
                                    <div className="min-w-0 flex-1 leading-tight space-y-1">
                                      <div className="flex items-center gap-1.5">
                                        <span className="text-[9px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded uppercase tracking-wide">
                                          {quiz.subject}
                                        </span>
                                        <span className="text-[9px] font-bold text-stone-400">
                                          {quiz.difficulty}
                                        </span>
                                      </div>
                                      <strong className="text-stone-900 font-display font-bold text-xs truncate block">
                                        {quiz.title}
                                      </strong>
                                      {attempt ? (
                                        <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-1">
                                          <CheckCircle className="w-3 h-3" />
                                          Dernier score : {attempt.score}/{attempt.total}
                                        </span>
                                      ) : (
                                        <span className="text-[10px] text-stone-400 italic block">
                                          Non tenté • {quiz.questions.length} questions
                                        </span>
                                      )}
                                    </div>
                                    <button
                                      onClick={() => {
                                        setShowQuizSelectionModal(false);
                                        setActiveQuizId(quiz.id);
                                      }}
                                      className="py-2 px-3 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-[10px] uppercase tracking-wider shrink-0 transition-all cursor-pointer"
                                    >
                                      Démarrer
                                    </button>
                                  </div>
                                );
                              })
                          ) : (
                            <p className="text-center text-xs text-stone-400 italic py-4">
                              Aucun quiz interactif disponible pour cet examen actuellement.
                            </p>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {/* APP HEADER */}
                <header className="px-4 py-2.5 bg-white border-b border-stone-200/50 flex justify-between items-center shrink-0 shadow-xs z-30">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 shrink-0 flex items-center justify-center">
                      <SankofaLogo size={36} showText={false} />
                    </div>
                    <div className="leading-none">
                      <h4 className="text-xs font-display font-black text-stone-900 tracking-tight">Sankofa Educ</h4>
                      <span className="text-[9px] text-stone-400 font-bold uppercase tracking-wider">
                        {user.targetExam} {user.series === 'Général' ? 'Général' : `Série ${user.series}`}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Free educational access badge */}
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 border border-emerald-200 text-emerald-800 rounded-full text-[9px] font-black shadow-2xs select-none">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                      <span>ACCÈS GRATUIT</span>
                    </div>

                    {/* Notifications bell button with badge */}
                    <div className="relative">
                      {isFocusActive ? (
                        <div
                          className="w-8 h-8 bg-stone-900 text-amber-500 rounded-full flex items-center justify-center border border-stone-800 transition-all"
                          title="Mode Focus Actif - Notifications désactivées"
                        >
                          <BellOff className="w-3.5 h-3.5 animate-pulse" />
                        </div>
                      ) : (
                        <button
                          onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
                          className="w-8 h-8 bg-stone-100 hover:bg-stone-200 rounded-full flex items-center justify-center text-stone-600 transition-all cursor-pointer"
                        >
                          <Bell className="w-4 h-4" />
                          {unreadNotificationsCount > 0 && (
                            <span className="absolute -top-1 -right-1 w-4 h-4 bg-orange-600 text-white rounded-full flex items-center justify-center text-[8px] font-black font-mono">
                              {unreadNotificationsCount}
                            </span>
                          )}
                        </button>
                      )}

                      {/* Dropdown containing school bulletins */}
                      <AnimatePresence>
                        {showNotificationsDropdown && (
                          <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            className="absolute right-0 mt-2 w-72 bg-white border border-stone-200 rounded-2xl shadow-xl p-3 z-50 space-y-2 max-h-80 overflow-y-auto no-scrollbar"
                          >
                            <div className="flex justify-between items-center border-b border-stone-100 pb-2">
                              <h5 className="text-[10px] uppercase tracking-widest font-black text-stone-500">Notifications scolaires</h5>
                              <button
                                onClick={() => setShowNotificationsDropdown(false)}
                                className="text-[10px] text-stone-400 font-bold"
                              >
                                Fermer
                              </button>
                            </div>

                            {notifications.length > 0 ? (
                              <div className="space-y-1.5">
                                {notifications.map((n) => (
                                  <div
                                    key={n.id}
                                    onClick={() => handleReadNotification(n.id)}
                                    className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                                      n.read
                                        ? 'bg-stone-50 border-stone-100 opacity-60'
                                        : 'bg-orange-500/[0.03] border-orange-200'
                                    }`}
                                  >
                                    <div className="flex justify-between items-start">
                                      <strong className="text-[11px] font-bold text-stone-800">{n.title}</strong>
                                      {!n.read && <span className="w-2 h-2 bg-orange-500 rounded-full shrink-0" />}
                                    </div>
                                    <p className="text-[10px] text-stone-500 mt-0.5 leading-snug">{n.message}</p>
                                    <span className="text-[8px] text-stone-400 mt-1 block font-mono">Simulé en temps réel</span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-center text-[10px] text-stone-400 italic py-4">Aucune notification disponible.</p>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </header>

                {isOffline && (
                  <div className="bg-amber-600 text-stone-100 px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider text-center flex items-center justify-center gap-2 shrink-0 z-20">
                    <WifiOff className="w-3.5 h-3.5" />
                    <span>Mode Hors-ligne actif • Seules les fiches téléchargées sont accessibles</span>
                  </div>
                )}

                {/* MAIN SCREEN AREA BODY CONTAINER */}
                <main className="flex-1 overflow-hidden relative">
                  
                  {/* TAB 1: HOME PANEL */}
                  {activeTab === 'home' && (
                    <div className="h-full overflow-y-auto no-scrollbar p-4 space-y-5">
                      
                      {/* Welcome message greeting */}
                      <div className="space-y-0.5">
                        <span className="text-[10px] text-stone-500 font-bold uppercase tracking-wider">Akwaba (Bienvenue) 👋</span>
                        <h3 className="text-lg font-display font-black text-stone-900 leading-tight">
                          Prêt à réviser, <span className="text-orange-600">{user.name.split(' ')[0]}</span> ?
                        </h3>
                      </div>

                      {/* Quick study metrics tracker cards */}
                      <div className="bg-white border border-stone-200/50 p-4 rounded-2xl shadow-xs space-y-3">
                        <div className="flex justify-between items-center">
                          <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest flex items-center gap-1">
                            <Activity className="w-3.5 h-3.5 text-orange-600" />
                            Votre Progression
                          </h4>
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-500/10 px-2 py-0.5 rounded-md">
                            {studyStats.rank}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-0.5">
                            <span className="text-[10px] text-stone-400 block font-medium">Temps d'étude</span>
                            <div className="flex items-baseline gap-1">
                              <strong className="text-lg font-black text-stone-900 font-display">{studyStats.totalTime}</strong>
                              <span className="text-[10px] text-stone-500 font-bold">mins</span>
                            </div>
                            {/* Visual indicator bar */}
                            <div className="w-full h-1 bg-stone-100 rounded-full overflow-hidden">
                              <div className="h-full bg-orange-500 w-1/2" />
                            </div>
                          </div>

                          <div className="space-y-0.5">
                            <span className="text-[10px] text-stone-400 block font-medium">Fiches Validées</span>
                            <div className="flex items-baseline gap-1">
                              <strong className="text-lg font-black text-stone-900 font-display">
                                {completedSheets.length} / {sheets.filter((s) => s.exam === user.targetExam && isResourceInSeries(s.exam, s.subject, s.title, s.series)).length || 5}
                              </strong>
                            </div>
                            <div className="w-full h-1 bg-stone-100 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-emerald-500"
                                style={{
                                  width: `${
                                    (completedSheets.length / (sheets.filter((s) => s.exam === user.targetExam && isResourceInSeries(s.exam, s.subject, s.title, s.series)).length || 5)) * 100
                                  }%`
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Sankofa AI Scanner quick launcher promo banner */}
                      <div
                        onClick={() => setActiveTab('scanner')}
                        className="bg-gradient-to-r from-orange-600 to-amber-500 p-4 rounded-2xl text-white relative overflow-hidden shadow-md cursor-pointer group hover:shadow-lg transition-all"
                      >
                        <div className="absolute right-2 bottom-2 text-white/10 shrink-0 select-none">
                          <Camera className="w-24 h-24 stroke-[1]" />
                        </div>
                        <div className="relative space-y-1">
                          <span className="bg-white/20 text-white font-black text-[9px] px-2 py-0.5 rounded inline-block uppercase tracking-wider">
                            Nouveau : Sankofa OCR 📸
                          </span>
                          <strong className="text-sm font-display font-black block">Numérisez vos cours avec l'IA</strong>
                          <p className="text-[10px] text-orange-50 leading-tight">
                            Prenez en photo votre cahier d'école pour en faire une fiche officielle de révision et un quiz corrigé en 3 secondes.
                          </p>
                        </div>
                      </div>

                      {/* Popular Subjects & quick review launcher */}
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-stone-400">Recommandations pour vous</h4>
                          <button
                            onClick={() => setActiveTab('sheets')}
                            className="text-[10px] font-bold text-orange-600 hover:underline flex items-center gap-0.5"
                          >
                            Voir tout
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Staggered beautiful recommended list */}
                        <div className="space-y-2.5">
                          {sheets
                            .filter((s) => s.exam === user.targetExam && isResourceInSeries(s.exam, s.subject, s.title, s.series))
                            .slice(0, 3)
                            .map((sheet) => (
                              <div
                                key={sheet.id}
                                onClick={() => {
                                  setActiveTab('sheets');
                                  // This triggers viewing inside sheets component
                                }}
                                className="bg-white border border-stone-200/60 p-3 rounded-2xl flex items-center gap-3 shadow-xs hover:shadow-md hover:border-orange-200 transition-all cursor-pointer"
                              >
                                <div className="w-10 h-10 bg-amber-500/10 rounded-xl flex items-center justify-center text-amber-600 shrink-0 font-bold text-xs">
                                  {sheet.subject.substring(0, 2).toUpperCase()}
                                </div>
                                <div className="flex-1 min-w-0 leading-tight">
                                  <span className="text-[9px] font-bold text-orange-600 uppercase tracking-wide block">{sheet.subject}</span>
                                  <strong className="text-stone-900 font-display font-semibold text-xs truncate block mt-0.5">{sheet.title}</strong>
                                  <span className="text-[9px] text-stone-400 block mt-0.5">{sheet.chapter}</span>
                                </div>
                                <ChevronRight className="w-4 h-4 text-stone-400 shrink-0" />
                              </div>
                            ))}
                        </div>
                      </div>

                      {/* Quick access utility bento buttons */}
                      <div className="grid grid-cols-3 gap-2.5 pt-2">
                        <div
                          onClick={() => setActiveTab('sheets')}
                          className="bg-white border border-stone-200/50 p-3 rounded-2xl text-left space-y-1 hover:border-orange-200 shadow-xs cursor-pointer"
                        >
                          <BookOpen className="w-4 h-4 text-orange-600" />
                          <strong className="text-[11px] font-bold text-stone-800 block pt-0.5">Fiches</strong>
                          <span className="text-[9px] text-stone-500 block leading-tight">Bibliothèque de cours</span>
                        </div>
                        <div
                          onClick={() => {
                            setShowQuizSelectionModal(true);
                          }}
                          className="bg-white border border-stone-200/50 p-3 rounded-2xl text-left space-y-1 hover:border-orange-200 shadow-xs cursor-pointer"
                        >
                          <Award className="w-4 h-4 text-amber-500" />
                          <strong className="text-[11px] font-bold text-stone-800 block pt-0.5">Quiz</strong>
                          <span className="text-[9px] text-stone-500 block leading-tight">S'auto-évaluer</span>
                        </div>
                        <div
                          onClick={() => setActiveTab('forum')}
                          className="bg-white border border-stone-200/50 p-3 rounded-2xl text-left space-y-1 hover:border-orange-200 shadow-xs cursor-pointer bg-gradient-to-br from-orange-500/5 to-amber-500/10 border-orange-200"
                        >
                          <MessageSquare className="w-4 h-4 text-orange-600" />
                          <strong className="text-[11px] font-bold text-stone-800 block pt-0.5">Forum 💬</strong>
                          <span className="text-[9px] text-stone-500 block leading-tight">Poser vos questions</span>
                        </div>
                      </div>

                    </div>
                  )}

                  {/* TAB 2: REVISION SHEETS DIRECTORY */}
                  {activeTab === 'sheets' && (
                    <RevisionSheets
                      sheets={sheets}
                      quizzes={quizzes}
                      favorites={favorites}
                      downloads={downloads}
                      completedSheets={completedSheets}
                      targetExam={user ? user.targetExam : 'BAC'}
                      userSeries={user ? user.series : 'D'}
                      isPremium={isPremium}
                      onToggleFavorite={handleToggleFavorite}
                      onToggleDownload={handleToggleDownload}
                      onMarkAsRead={handleMarkAsRead}
                      onLaunchQuiz={(qId) => setActiveQuizId(qId)}
                      onLaunchVideoSearch={handleLaunchVideoSearch}
                      onRefreshData={fetchData}
                      onChangeSeries={(newSeries) => setUser(prev => prev ? { ...prev, series: newSeries } : null)}
                      isFocusActive={isFocusActive}
                      onToggleFocusMode={setIsFocusActive}
                      isOffline={isOffline}
                    />
                  )}

                  {/* TAB 3: CAMERA AI SCANNER */}
                  {activeTab === 'scanner' && (
                    <AIScanner
                      onScanSuccess={handleScanSuccess}
                      isPremium={isPremium}
                      onOpenPremium={() => setShowSubscriptionModal(true)}
                      isOffline={isOffline}
                    />
                  )}

                  {/* TAB 4: VIDEOS VIEW */}
                  {activeTab === 'videos' && (
                    <VideosView
                      initialSearchKeywords={videoSearchKeywords}
                      onClearKeywords={() => setVideoSearchKeywords('')}
                    />
                  )}

                  {/* TAB 5: FORUM / QUESTIONNAIRE VIEW */}
                  {activeTab === 'forum' && (
                    <ForumView
                      currentUserName={user ? user.name : 'Élève Sankofa'}
                      currentUserExam={user ? user.targetExam : 'BAC'}
                      onShowToast={triggerToast}
                    />
                  )}

                  {/* TAB 6: USER PROFILE VIEW */}
                  {activeTab === 'profile' && (
                    showProfileEdit ? (
                      <ProfileEdit
                        user={user!}
                        onSave={(updatedUser) => {
                          setUser(updatedUser);
                          localStorage.setItem('sankofa_user', JSON.stringify(updatedUser));
                        }}
                        onClose={() => setShowProfileEdit(false)}
                        triggerToast={triggerToast}
                      />
                    ) : (
                      <div className="h-full overflow-y-auto no-scrollbar p-4 space-y-6">
                        
                        {/* Profile header with edit action */}
                        <div className="flex items-center justify-between gap-4 bg-white border border-stone-200/50 p-4 rounded-3xl shadow-xs">
                          <div className="flex items-center gap-4">
                            {/* Styled African generic/minimalist profile icon avatar */}
                            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white font-bold text-lg border-2 border-white shadow">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <div className="leading-tight space-y-0.5">
                              <h4 className="text-stone-900 font-display font-black text-sm">{user.name}</h4>
                              <p className="text-[10px] text-stone-500">{user.email}</p>
                              {user.phone && user.phone !== 'Non renseigné' && (
                                <p className="text-[10px] text-stone-400 font-mono">{user.phone}</p>
                              )}
                              <div className="flex gap-2 items-center mt-1">
                                <span className="bg-[#3c2518] text-white px-2 py-0.5 rounded-md text-[9px] font-black uppercase">
                                  {user.targetExam} {user.series !== 'Général' ? `(${user.series})` : ''}
                                </span>
                                <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase bg-emerald-500 text-white">
                                  Gratuit & Illimité ✨
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <button
                            onClick={() => setShowProfileEdit(true)}
                            className="p-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-600 rounded-2xl transition-all cursor-pointer shadow-3xs hover:text-stone-900"
                            title="Modifier le profil"
                          >
                            <Edit3 className="w-4.5 h-4.5" />
                          </button>
                        </div>

                        {/* Detailed reading metrics */}
                        <div className="space-y-3">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-stone-400">Statistiques d'apprentissage</h4>
                          <div className="bg-white border border-stone-200/50 rounded-2xl p-4 space-y-3.5 text-xs">
                            <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                              <span className="text-stone-500">Score moyen aux quiz</span>
                              <strong className="text-stone-800 font-bold">{studyStats.quizAvg}%</strong>
                            </div>
                            <div className="flex justify-between items-center pb-2 border-b border-stone-100">
                              <span className="text-stone-500">Temps total d'étude</span>
                              <strong className="text-stone-800 font-bold">{studyStats.totalTime} minutes</strong>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-stone-500">Quiz terminés</span>
                              <strong className="text-stone-800 font-bold">{completedQuizzes.length}</strong>
                            </div>
                          </div>
                        </div>

                        {/* Announcement of free access model */}
                        <div className="space-y-3">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-stone-400">Accès et Gratuité</h4>
                          <div className="bg-emerald-50 border border-emerald-200/50 p-4 rounded-2xl">
                            <strong className="text-xs font-bold text-emerald-900 block flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                              Accès Gratuit & Illimité Actif
                            </strong>
                            <span className="text-[10px] text-emerald-700 leading-normal block mt-1.5">
                              Sankofa Educ est désormais 100% gratuit ! Toutes les leçons, les quiz interactifs et le Scanner IA sont ouverts à tous les élèves sans abonnement. Bonnes révisions !
                            </span>
                          </div>
                        </div>

                        {/* Portal / Action buttons section */}
                        <div className="space-y-3 pt-2">
                          {/* Instructor dashboard trigger button */}
                          <button
                            onClick={() => setShowAdminPanel(true)}
                            className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-amber-400 font-bold rounded-xl text-xs flex items-center justify-center gap-2 border border-stone-700 shadow-sm cursor-pointer"
                          >
                            <Shield className="w-4 h-4 text-amber-500" />
                            Accéder au Portail Admin (Enseignants)
                          </button>

                          <button
                            onClick={() => {
                              localStorage.removeItem('sankofa_user');
                              setUser(null);
                              setShowAdminPanel(false);
                              setAppState('auth');
                              triggerToast('Déconnexion réussie.');
                            }}
                            className="w-full py-3 border border-red-200 text-red-600 font-bold rounded-xl text-xs flex items-center justify-center gap-2 hover:bg-red-50 transition-all cursor-pointer"
                          >
                            <LogOut className="w-4 h-4" />
                            Se déconnecter
                          </button>
                        </div>

                      </div>
                    )
                  )}

                </main>

                {/* APP BOTTOM NAVIGATION BAR */}
                <nav className="bg-white border-t border-stone-200/60 px-4 py-2 flex justify-between items-center shrink-0 shadow-lg z-30">
                  <button
                    onClick={() => { setActiveTab('home'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'home' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <Compass className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Akwaba</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('sheets'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'sheets' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <BookOpen className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Fiches</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('scanner'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'scanner' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <Camera className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Scanner IA</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('videos'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'videos' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <Play className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Vidéos</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('forum'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'forum' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Forum</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('profile'); setVideoSearchKeywords(''); }}
                    className={`flex flex-col items-center gap-1 py-1.5 transition-all cursor-pointer ${
                      activeTab === 'profile' ? 'text-orange-600 scale-105' : 'text-stone-400 hover:text-stone-600'
                    }`}
                  >
                    <User className="w-5 h-5" />
                    <span className="text-[9px] font-bold">Profil</span>
                  </button>
                </nav>

              </motion.div>
            )}

          </AnimatePresence>

          {/* 3. SECURE ADMINISTRATOR CONTROL PANEL */}
          {showAdminPanel && (
            <div className="absolute inset-0 bg-[#fcfbf7] z-50 flex flex-col">
              <AdminPanel
                sheets={sheets}
                onRefreshData={fetchData}
                onShowToast={triggerToast}
                onClose={() => setShowAdminPanel(false)}
              />
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
