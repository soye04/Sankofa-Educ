/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ExamType = 'BEPC' | 'BAC' | 'Concours';
export type AppStatus = 'active' | 'inactive';

export interface DefinitionItem {
  term: string;
  definition: string;
}

export interface RevisionSheet {
  id: string;
  title: string;
  exam: ExamType;
  subject: string;
  chapter: string;
  summary: string;
  content: string;
  formulas?: string[];
  definitions?: DefinitionItem[];
  youtubeKeywords?: string;
  isFavorite?: boolean;
  isDownloaded?: boolean;
  illustrationUrl?: string;
  isAIGenerated?: boolean;
  series?: string[];
}

export type QuizQuestionType = 'QCM' | 'VraiFaux' | 'Libre';

export interface QuizQuestion {
  id: string;
  type: QuizQuestionType;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  sheetId?: string;
  subject: string;
  exam: ExamType;
  difficulty: 'Facile' | 'Moyen' | 'Difficile';
  questions: QuizQuestion[];
  series?: string[];
}

export interface CompletedQuizAttempt {
  quizId: string;
  quizTitle: string;
  subject: string;
  exam: ExamType;
  score: number;
  total: number;
  date: string;
}

export interface UserProgress {
  userId: string;
  quizCount: number;
  studyTimeMinutes: number;
  streakDays: number;
  completedQuizzes: CompletedQuizAttempt[];
  completedSheets: string[]; // List of sheet IDs read
  favorites: string[]; // List of sheet IDs
  downloads: string[]; // List of downloaded sheet IDs
}

export interface SubscriptionState {
  isPremium: boolean;
  expiresAt?: string;
  trialEndsAt: string;
  paymentMethod?: 'Wave' | 'Orange Money' | 'MTN MoMo';
  phoneNumber?: string;
  history: {
    id: string;
    amount: number;
    date: string;
    status: 'Succès' | 'Échoué' | 'En attente';
    method: string;
    phone: string;
  }[];
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  date: string;
  read: boolean;
  type: 'info' | 'quiz' | 'sub';
}

export interface VideoInfo {
  id: string;
  title: string;
  channelTitle: string;
  duration: string;
  viewCount: string;
  thumbnailUrl: string;
}

export interface ForumAnswer {
  id: string;
  authorName: string;
  authorRole?: 'Élève' | 'Enseignant' | 'Admin';
  content: string;
  createdAt: string;
  likes: number;
}

export interface ForumQuestion {
  id: string;
  authorName: string;
  authorExam: ExamType;
  subject: string;
  title: string;
  content: string;
  createdAt: string;
  likes: number;
  answers: ForumAnswer[];
  isResolved?: boolean;
}

export interface ScanResult {
  text: string;
  sheet: RevisionSheet;
  quiz: Quiz;
}
