/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Plus, Search, ThumbsUp, CheckCircle2, User, Send, Filter, Sparkles, HelpCircle, GraduationCap, X, CornerDownRight } from 'lucide-react';
import { ForumQuestion, ExamType } from '../types';

interface ForumViewProps {
  currentUserName: string;
  currentUserExam: ExamType;
  onShowToast: (msg: string) => void;
}

export default function ForumView({ currentUserName, currentUserExam, onShowToast }: ForumViewProps) {
  const [questions, setQuestions] = useState<ForumQuestion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('Toutes');
  const [selectedExamFilter, setSelectedExamFilter] = useState<string>('Tous');

  // Modal State for posting a new question
  const [showPostModal, setShowPostModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('Mathématiques');
  const [newExam, setNewExam] = useState<ExamType>(currentUserExam || 'BAC');
  const [newContent, setNewContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Selected active question for detailed discussion
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);

  const fetchQuestions = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/forum/questions');
      const data = await res.json();
      if (data.success) {
        setQuestions(data.questions);
      }
    } catch (err) {
      console.error('Error fetching forum questions:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQuestions();
  }, []);

  const handleCreateQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) {
      onShowToast('Veuillez remplir le titre et le contenu de votre question.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/forum/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: currentUserName || 'Élève Sankofa',
          authorExam: newExam,
          subject: newSubject,
          title: newTitle.trim(),
          content: newContent.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        onShowToast('Votre question a été publiée sur le forum ! 💬');
        setNewTitle('');
        setNewContent('');
        setShowPostModal(false);
        setQuestions(data.questions);
      } else {
        onShowToast(data.error || 'Erreur lors de la publication.');
      }
    } catch (err) {
      onShowToast('Erreur de connexion au serveur.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikeQuestion = async (e: React.MouseEvent, questionId: string) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/forum/questions/${questionId}/like`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.success) {
        setQuestions(data.questions);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddReply = async (questionId: string) => {
    if (!replyContent.trim()) return;

    setIsSubmittingReply(true);
    try {
      const res = await fetch(`/api/forum/questions/${questionId}/answers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: currentUserName || 'Élève Sankofa',
          authorRole: 'Élève',
          content: replyContent.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        onShowToast('Réponse ajoutée !');
        setReplyContent('');
        setQuestions(data.questions);
      } else {
        onShowToast(data.error || "Erreur lors de l'envoi de la réponse.");
      }
    } catch (err) {
      onShowToast('Erreur de connexion au serveur.');
    } finally {
      setIsSubmittingReply(false);
    }
  };

  const filteredQuestions = useMemo(() => {
    return questions.filter((q) => {
      const matchesSearch =
        searchQuery === '' ||
        q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.subject.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesSubject = selectedSubject === 'Toutes' || q.subject === selectedSubject;
      const matchesExam = selectedExamFilter === 'Tous' || q.authorExam === selectedExamFilter;

      return matchesSearch && matchesSubject && matchesExam;
    });
  }, [questions, searchQuery, selectedSubject, selectedExamFilter]);

  return (
    <div className="h-full flex flex-col bg-[#fcfbf7] overflow-hidden">
      
      {/* HEADER BAR */}
      <div className="p-4 bg-white border-b border-stone-200/60 shrink-0 shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[9px] font-black uppercase tracking-widest text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full inline-block">
              Communauté & Entraide
            </span>
            <h3 className="text-sm font-display font-black text-stone-900 mt-0.5 flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-orange-600" />
              Forum & Questionnaire des Élèves
            </h3>
          </div>

          <button
            onClick={() => setShowPostModal(true)}
            className="px-3 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Poser une question</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Rechercher une question (ex: Thalès, Chimie, Dissertation...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-stone-100 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-medium"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-0.5 text-xs">
          <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            Sujets:
          </span>
          {['Toutes', 'Mathématiques', 'Physique-Chimie', 'Français', 'SVT', 'Histoire-Géographie', 'Anglais'].map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 transition-all cursor-pointer ${
                selectedSubject === sub
                  ? 'bg-stone-900 text-amber-400 shadow-xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>
      </div>

      {/* QUESTIONS LIST AREA */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 no-scrollbar">
        
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <div className="w-10 h-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs text-stone-500 font-medium">Chargement des discussions du forum...</p>
          </div>
        ) : filteredQuestions.length === 0 ? (
          <div className="bg-white border border-stone-200/80 p-8 rounded-2xl text-center space-y-3 shadow-xs">
            <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600 mx-auto">
              <HelpCircle className="w-6 h-6" />
            </div>
            <h4 className="text-xs font-bold text-stone-800">Aucune question trouvée</h4>
            <p className="text-[11px] text-stone-500 max-w-xs mx-auto leading-relaxed">
              Soyez le premier à poser votre question ou votre doute sur un chapitre ! La communauté Sankofa vous répondra.
            </p>
            <button
              onClick={() => setShowPostModal(true)}
              className="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-bold shadow-sm inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Poser ma question maintenant
            </button>
          </div>
        ) : (
          filteredQuestions.map((q) => {
            const isExpanded = expandedQuestionId === q.id;
            const hasTeacherAnswer = q.answers?.some((a) => a.authorRole === 'Enseignant' || a.authorRole === 'Admin');

            return (
              <motion.div
                key={q.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-white border rounded-2xl p-4 transition-all shadow-2xs ${
                  isExpanded ? 'border-orange-400 ring-2 ring-orange-400/20' : 'border-stone-200/80 hover:border-orange-300'
                }`}
              >
                {/* Header */}
                <div
                  onClick={() => setExpandedQuestionId(isExpanded ? null : q.id)}
                  className="cursor-pointer space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-bold bg-stone-900 text-amber-400 px-2 py-0.5 rounded-md font-mono">
                        {q.authorExam}
                      </span>
                      <span className="text-[9px] font-bold text-orange-700 bg-orange-50 px-2 py-0.5 rounded-md">
                        {q.subject}
                      </span>
                      {hasTeacherAnswer && (
                        <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <GraduationCap className="w-3 h-3 text-emerald-600" />
                          Réponse Enseignant
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-stone-400 font-medium">
                      {new Date(q.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>

                  <strong className="text-stone-900 font-display font-bold text-sm block leading-snug">
                    {q.title}
                  </strong>

                  <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                    {q.content}
                  </p>

                  <div className="flex items-center justify-between pt-1 border-t border-stone-100 text-[11px] text-stone-500">
                    <span className="font-semibold text-stone-700 flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-stone-400" />
                      {q.authorName}
                    </span>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={(e) => handleLikeQuestion(e, q.id)}
                        className="flex items-center gap-1 text-stone-500 hover:text-orange-600 transition-all font-bold cursor-pointer"
                      >
                        <ThumbsUp className="w-3.5 h-3.5 text-orange-500" />
                        <span>{q.likes || 0}</span>
                      </button>

                      <span className="flex items-center gap-1 text-stone-600 font-bold bg-stone-100 px-2 py-0.5 rounded-lg">
                        <MessageSquare className="w-3.5 h-3.5 text-stone-500" />
                        <span>{q.answers ? q.answers.length : 0} réponses</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* EXPANDED DISCUSSION THREAD */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 pt-3 border-t border-stone-200 space-y-4"
                  >
                    <h5 className="text-[10px] uppercase font-black tracking-wider text-stone-400 flex items-center gap-1">
                      <MessageSquare className="w-3.5 h-3.5 text-orange-600" />
                      Réponses de la communauté ({q.answers ? q.answers.length : 0})
                    </h5>

                    {q.answers && q.answers.length > 0 ? (
                      <div className="space-y-2.5">
                        {q.answers.map((ans) => {
                          const isTeacher = ans.authorRole === 'Enseignant' || ans.authorRole === 'Admin';
                          return (
                            <div
                              key={ans.id}
                              className={`p-3 rounded-xl border space-y-1.5 ${
                                isTeacher
                                  ? 'bg-amber-500/10 border-amber-300 text-stone-900'
                                  : 'bg-stone-50 border-stone-200/80 text-stone-800'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <CornerDownRight className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                                  <strong className="text-xs font-bold text-stone-900">
                                    {ans.authorName}
                                  </strong>
                                  {isTeacher && (
                                    <span className="text-[9px] bg-stone-900 text-amber-400 font-bold px-1.5 py-0.5 rounded font-mono">
                                      Professeur Vérifié 🎓
                                    </span>
                                  )}
                                </div>
                                <span className="text-[9px] text-stone-400">
                                  {new Date(ans.createdAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                                </span>
                              </div>

                              <p className="text-xs text-stone-700 leading-relaxed pl-5">
                                {ans.content}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-[11px] text-stone-400 italic py-2">
                        Aucune réponse pour le moment. Soyez le premier à aider !
                      </p>
                    )}

                    {/* REPLY INPUT FORM */}
                    <div className="pt-2 flex gap-2">
                      <input
                        type="text"
                        placeholder="Rédiger une réponse ou une explication..."
                        value={replyContent}
                        onChange={(e) => setReplyContent(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleAddReply(q.id);
                        }}
                        className="flex-1 px-3 py-2 bg-stone-100 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500"
                      />
                      <button
                        onClick={() => handleAddReply(q.id)}
                        disabled={isSubmittingReply || !replyContent.trim()}
                        className="px-3 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Répondre</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })
        )}
      </div>

      {/* POST NEW QUESTION MODAL */}
      <AnimatePresence>
        {showPostModal && (
          <div className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-md w-full p-5 space-y-4 shadow-2xl border border-stone-200 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-stone-900 font-display">Poser une question aux professeurs & élèves</h4>
                    <p className="text-[10px] text-stone-500">Posez vos doutes sur un chapitre ou sujet d'examen</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPostModal(false)}
                  className="text-stone-400 hover:text-stone-600 p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateQuestion} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-stone-600">Niveau d'examen</label>
                    <select
                      value={newExam}
                      onChange={(e) => setNewExam(e.target.value as ExamType)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-semibold text-stone-800"
                    >
                      <option value="BEPC">BEPC (3ème)</option>
                      <option value="BAC">BAC (Terminale)</option>
                      <option value="Concours">Concours CI</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-stone-600">Matière</label>
                    <select
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-semibold text-stone-800"
                    >
                      <option value="Mathématiques">Mathématiques</option>
                      <option value="Physique-Chimie">Physique-Chimie</option>
                      <option value="Français">Français</option>
                      <option value="SVT">SVT</option>
                      <option value="Histoire-Géographie">Histoire-Géographie</option>
                      <option value="Anglais">Anglais</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Sujet de votre question *</label>
                  <input
                    type="text"
                    required
                    placeholder="ex: Comment appliquer la formule de la dérivée ?"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-medium text-stone-800 focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Détails & Explication de votre difficulté *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Expliquez précisément où vous bloquez dans votre exercice ou votre cours..."
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 focus:border-orange-500 focus:outline-none leading-relaxed"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowPostModal(false)}
                    className="flex-1 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl transition-all cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? 'Publication...' : 'Publier ma question 🚀'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
