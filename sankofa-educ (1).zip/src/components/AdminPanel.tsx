/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, BarChart3, BookOpen, Send, Plus, Trash2, CheckCircle2, UserCheck, Smartphone, HelpCircle, Sparkles, Video, Edit, LogOut, Key, Shield, Power, PowerOff, RefreshCw } from 'lucide-react';
import { RevisionSheet, ExamType, VideoInfo } from '../types';

interface AdminPanelProps {
  sheets: RevisionSheet[];
  onRefreshData: () => void;
  onShowToast: (msg: string) => void;
  onClose?: () => void;
}

export default function AdminPanel({ sheets, onRefreshData, onShowToast, onClose }: AdminPanelProps) {
  const [isAdminAuth, setIsAdminAuth] = useState(false);
  const [adminAuthMode, setAdminAuthMode] = useState<'login' | 'register'>('login');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminName, setAdminName] = useState('');
  const [adminSubject, setAdminSubject] = useState('Mathématiques');
  const [activationCode, setActivationCode] = useState('');
  const [authError, setAuthError] = useState('');
  const [isLoadingAuth, setIsLoadingAuth] = useState(false);
  const [currentTeacher, setCurrentTeacher] = useState<{ name: string; email: string; subject: string } | null>(null);

  // App Status & Republication mode state
  const [currentAppStatus, setCurrentAppStatus] = useState<'active' | 'inactive'>('active');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  const fetchAppStatus = async () => {
    try {
      const res = await fetch('/api/app/status');
      const data = await res.json();
      if (data.success && data.appStatus) {
        setCurrentAppStatus(data.appStatus);
      }
    } catch (e) {
      console.error('Failed to fetch app status:', e);
    }
  };

  useEffect(() => {
    fetchAppStatus();
  }, []);

  const handleToggleAppStatus = async (targetStatus: 'active' | 'inactive') => {
    setIsUpdatingStatus(true);
    try {
      const res = await fetch('/api/app/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appStatus: targetStatus,
          reason: targetStatus === 'inactive' ? 'Républication et maintenance des contenus pédagogiques' : undefined
        })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentAppStatus(data.appStatus);
        onShowToast(data.message);
        onRefreshData();
      } else {
        onShowToast(data.error || 'Erreur lors du changement de statut.');
      }
    } catch (e) {
      onShowToast('Erreur de connexion au serveur.');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  // Active sub-sections
  const [activeTab, setActiveTab] = useState<'stats' | 'add-fiche' | 'broadcast' | 'manage' | 'videos'>('stats');

  // Video Management state
  const [adminVideos, setAdminVideos] = useState<VideoInfo[]>([]);
  const [isLoadingVideos, setIsLoadingVideos] = useState(false);
  const [videoFormMode, setVideoFormMode] = useState<'add' | 'edit'>('add');
  const [editingVideoId, setEditingVideoId] = useState<string | null>(null);
  
  // Video Form inputs
  const [vidId, setVidId] = useState('');
  const [vidTitle, setVidTitle] = useState('');
  const [vidChannelTitle, setVidChannelTitle] = useState('');
  const [vidDuration, setVidDuration] = useState('');
  const [vidViewCount, setVidViewCount] = useState('');
  const [vidThumbnailUrl, setVidThumbnailUrl] = useState('');

  // Add Fiche form state
  const [ficheExam, setFicheExam] = useState<ExamType>('BAC');
  const [ficheSubject, setFicheSubject] = useState('Mathématiques');
  const [ficheChapter, setFicheChapter] = useState('');
  const [ficheTitle, setFicheTitle] = useState('');
  const [ficheSummary, setFicheSummary] = useState('');
  const [ficheContent, setFicheContent] = useState('');
  const [ficheFormulasText, setFicheFormulasText] = useState('');
  const [ficheDefinitions, setFicheDefinitions] = useState<{ term: string; definition: string }[]>([{ term: '', definition: '' }]);

  // Broadcast notification form state
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifTarget, setNotifTarget] = useState<'Tous' | ExamType>('Tous');
  const [notifType, setNotifType] = useState<'info' | 'rappel' | 'promo'>('info');

  const fetchAdminVideos = async () => {
    setIsLoadingVideos(true);
    try {
      const response = await fetch('/api/videos');
      const data = await response.json();
      if (data.success) {
        setAdminVideos(data.videos);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingVideos(false);
    }
  };

  useEffect(() => {
    if (isAdminAuth) {
      fetchAdminVideos();
    }
  }, [isAdminAuth]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoadingAuth(true);

    try {
      const response = await fetch('/api/admin/teachers/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: adminEmail, password: adminPassword })
      });
      const data = await response.json();

      if (response.ok && data.success) {
        setIsAdminAuth(true);
        setCurrentTeacher(data.teacher);
        onShowToast(`Ravi de vous revoir, M. ${data.teacher.name} ! 👋`);
      } else {
        setAuthError(data.error || 'Identifiants invalides ou mot de passe incorrect.');
      }
    } catch (err) {
      setAuthError('Erreur de communication avec le serveur.');
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleAdminRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoadingAuth(true);

    try {
      const response = await fetch('/api/admin/teachers/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: adminName,
          email: adminEmail,
          password: adminPassword,
          subject: adminSubject,
          activationCode
        })
      });
      const data = await response.json();

      if (response.ok && data.success) {
        onShowToast('Inscription réussie ! Connectez-vous maintenant. ✨');
        setAdminAuthMode('login');
        setAdminPassword('');
      } else {
        setAuthError(data.error || "Une erreur est survenue lors de l'inscription.");
      }
    } catch (err) {
      setAuthError('Erreur de communication avec le serveur.');
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleSaveVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vidId.trim() || !vidTitle.trim() || !vidChannelTitle.trim() || !vidDuration.trim()) {
      onShowToast('Veuillez remplir tous les champs obligatoires.');
      return;
    }

    const payload = {
      id: vidId.trim(),
      title: vidTitle.trim(),
      channelTitle: vidChannelTitle.trim(),
      duration: vidDuration.trim(),
      viewCount: vidViewCount.trim() || '0 vue',
      thumbnailUrl: vidThumbnailUrl.trim()
    };

    try {
      const url = videoFormMode === 'edit' ? `/api/videos/${editingVideoId}` : '/api/videos';
      const method = videoFormMode === 'edit' ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();

      if (data.success) {
        onShowToast(videoFormMode === 'edit' ? 'Vidéo mise à jour avec succès ! 📝' : 'Nouvelle vidéo de révision ajoutée ! 🎬');
        // Reset form
        setVidId('');
        setVidTitle('');
        setVidChannelTitle('');
        setVidDuration('');
        setVidViewCount('');
        setVidThumbnailUrl('');
        setVideoFormMode('add');
        setEditingVideoId(null);
        // Refresh
        setAdminVideos(data.videos);
      } else {
        onShowToast(data.error || "Erreur lors de l'enregistrement de la vidéo.");
      }
    } catch (err) {
      onShowToast('Erreur de communication avec le serveur.');
    }
  };

  const handleDeleteVideo = async (id: string) => {
    if (!window.confirm('Voulez-vous vraiment supprimer cette vidéo de la liste recommandation ?')) return;

    try {
      const response = await fetch(`/api/videos/${id}`, {
        method: 'DELETE'
      });
      const data = await response.json();

      if (data.success) {
        onShowToast('Vidéo supprimée avec succès.');
        setAdminVideos(data.videos);
      } else {
        onShowToast(data.error || 'Erreur lors de la suppression.');
      }
    } catch (err) {
      onShowToast('Erreur de communication avec le serveur.');
    }
  };

  const handleStartEditVideo = (video: VideoInfo) => {
    setVideoFormMode('edit');
    setEditingVideoId(video.id);
    setVidId(video.id);
    setVidTitle(video.title);
    setVidChannelTitle(video.channelTitle);
    setVidDuration(video.duration);
    setVidViewCount(video.viewCount);
    setVidThumbnailUrl(video.thumbnailUrl);
    onShowToast('Mode modification actif. Faites défiler vers le formulaire.');
  };

  const handleAddFiche = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Clean empty definitions
    const cleanedDefinitions = ficheDefinitions.filter((d) => d.term.trim() && d.definition.trim());
    
    // Clean formulas
    const formulas = ficheFormulasText
      .split(',')
      .map((f) => f.trim())
      .filter((f) => f.length > 0);

    const payload = {
      exam: ficheExam,
      subject: ficheSubject,
      chapter: ficheChapter,
      title: ficheTitle,
      summary: ficheSummary,
      content: ficheContent,
      formulas,
      definitions: cleanedDefinitions
    };

    try {
      const response = await fetch('/api/fiches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();

      if (data.success) {
        onShowToast('Fiche de révision créée et publiée avec succès ! ✨');
        // Reset form
        setFicheChapter('');
        setFicheTitle('');
        setFicheSummary('');
        setFicheContent('');
        setFicheFormulasText('');
        setFicheDefinitions([{ term: '', definition: '' }]);
        onRefreshData();
      } else {
        onShowToast('Erreur lors de la création de la fiche.');
      }
    } catch (err) {
      onShowToast('Erreur réseau lors de la communication serveur.');
    }
  };

  const handleDeleteFiche = async (id: string) => {
    if (!window.confirm('Voulez-vous vraiment supprimer définitivement cette fiche de révision ?')) return;

    try {
      const response = await fetch(`/api/fiches/${id}`, {
        method: 'DELETE'
      });
      const data = await response.json();

      if (data.success) {
        onShowToast('Fiche de révision supprimée avec succès.');
        onRefreshData();
      } else {
        onShowToast('Erreur lors de la suppression de la fiche.');
      }
    } catch (err) {
      onShowToast('Erreur réseau lors de la communication serveur.');
    }
  };

  const handleBroadcastNotification = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      title: notifTitle,
      message: notifMessage,
      target: notifTarget,
      type: notifType
    };

    try {
      const response = await fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();

      if (data.success) {
        const devices = data.fcmDevices !== undefined ? ` (${data.fcmDevices} appareils FCM enregistrés)` : '';
        onShowToast(`Push notification diffusée à tous les élèves ! 📣${devices}`);
        setNotifTitle('');
        setNotifMessage('');
        onRefreshData();
      } else {
        onShowToast('Erreur lors de la diffusion du message.');
      }
    } catch (err) {
      onShowToast('Erreur de réseau.');
    }
  };

  const handleAddDefinitionField = () => {
    setFicheDefinitions([...ficheDefinitions, { term: '', definition: '' }]);
  };

  // Predefined statistics calculations
  const totalSheets = sheets.length;
  const aiGeneratedSheetsCount = sheets.filter((s) => s.isAIGenerated).length;

  // Reset admin authentication state on unmount for security
  useEffect(() => {
    return () => {
      setIsAdminAuth(false);
      setCurrentTeacher(null);
    };
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7] font-sans text-stone-900 overflow-y-auto no-scrollbar">
      
      {/* HEADER BAR */}
      <div className="p-4 bg-stone-900 text-white flex justify-between items-center shrink-0 shadow-md">
        <div className="flex flex-col">
          <h4 className="text-xs font-bold font-display flex items-center gap-1.5 text-amber-400">
            <Shield className="w-4 h-4 text-amber-500 animate-pulse" />
            Portail Enseignants
          </h4>
          {isAdminAuth && currentTeacher && (
            <span className="text-[9px] text-stone-400 mt-0.5 font-semibold">
              M. {currentTeacher.name} • {currentTeacher.subject}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {isAdminAuth && (
            <button
              onClick={() => {
                setIsAdminAuth(false);
                setCurrentTeacher(null);
                onShowToast('Session admin fermée');
              }}
              className="text-[10px] text-red-400 bg-stone-850 px-2.5 py-1.5 rounded-lg border border-stone-750 font-bold flex items-center gap-1.5 hover:bg-stone-800 transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Déconnexion</span>
            </button>
          )}

          {onClose && (
            <button
              onClick={() => {
                setIsAdminAuth(false);
                setCurrentTeacher(null);
                onClose();
              }}
              className="text-[10px] text-stone-300 bg-stone-800 hover:bg-stone-700 px-3 py-1.5 rounded-lg border border-stone-700 font-bold transition-all cursor-pointer"
            >
              Fermer ✕
            </button>
          )}
        </div>
      </div>

      <div className="p-5 flex-1">
        
        {!isAdminAuth ? (
          /* --- STATE 1: SECURE AUTHENTICATION SCREEN --- */
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-sm mx-auto py-6 flex flex-col space-y-6"
          >
            <div className="flex flex-col items-center text-center space-y-2">
              <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-600">
                <Shield className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="text-lg font-display font-black text-stone-900">Portail Enseignants Sankofa</h3>
              <p className="text-xs text-stone-500 leading-relaxed">
                Connectez-vous pour ajouter des cours, fiches de révision officiels et configurer les vidéos de lecture des élèves.
              </p>
            </div>

            {/* Login / Register selector */}
            <div className="grid grid-cols-2 p-1 bg-stone-100 rounded-xl">
              <button
                onClick={() => {
                  setAdminAuthMode('login');
                  setAuthError('');
                }}
                className={`py-2 text-xs font-bold rounded-lg transition-all ${
                  adminAuthMode === 'login'
                    ? 'bg-white text-stone-900 shadow-sm'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Connexion
              </button>
              <button
                onClick={() => {
                  setAdminAuthMode('register');
                  setAuthError('');
                }}
                className={`py-2 text-xs font-bold rounded-lg transition-all ${
                  adminAuthMode === 'register'
                    ? 'bg-white text-stone-900 shadow-sm'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Créer un compte
              </button>
            </div>

            {authError && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs leading-normal">
                {authError}
              </div>
            )}

            {adminAuthMode === 'login' ? (
              <form onSubmit={handleAdminLogin} className="space-y-4 text-xs">
                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Email Académique</label>
                  <input
                    type="email"
                    required
                    placeholder="nom@ecole.ci ou admin@sankofa.ci"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Mot de passe</label>
                  <input
                    type="password"
                    required
                    placeholder="Saisissez votre mot de passe (ou 'admin')"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoadingAuth}
                  className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoadingAuth ? 'Connexion...' : 'Se connecter au portail'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleAdminRegister} className="space-y-4 text-xs">
                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Nom complet (M. / Mme)</label>
                  <input
                    type="text"
                    required
                    placeholder="ex: Yao Kouassi"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-stone-600">Matière</label>
                    <select
                      value={adminSubject}
                      onChange={(e) => setAdminSubject(e.target.value)}
                      className="w-full p-2.5 bg-white border border-stone-200 rounded-xl font-medium"
                    >
                      <option value="Mathématiques">Mathématiques</option>
                      <option value="Physique-Chimie">Physique-Chimie</option>
                      <option value="Français">Français</option>
                      <option value="SVT">SVT</option>
                      <option value="Histoire-Géographie">Histoire-Géo</option>
                      <option value="Anglais">Anglais</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-stone-600">Code Enseignant 🔑</label>
                    <input
                      type="text"
                      required
                      placeholder="sankofa225"
                      value={activationCode}
                      onChange={(e) => setActivationCode(e.target.value)}
                      className="w-full px-3 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Email Académique</label>
                  <input
                    type="email"
                    required
                    placeholder="ex: yao@sankofa.ci"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-stone-600">Mot de passe</label>
                  <input
                    type="password"
                    required
                    placeholder="Choisissez un mot de passe"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-amber-500 font-semibold shadow-xs"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoadingAuth}
                  className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoadingAuth ? 'Inscription...' : "S'inscrire et créer le compte"}
                </button>
              </form>
            )}
          </motion.div>
        ) : (
          /* --- STATE 2: CONTROL DECK TABS --- */
          <div className="space-y-6">
            
            {/* Republication Status & App Power Control Card */}
            <div className="bg-stone-900 border border-stone-800 rounded-2xl p-4 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-sm">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                  currentAppStatus === 'inactive' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}>
                  {currentAppStatus === 'inactive' ? <PowerOff className="w-5 h-5 text-amber-400 animate-pulse" /> : <Power className="w-5 h-5 text-emerald-400" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-black font-display text-stone-100">Statut Républication & Disponibilité</h4>
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md ${
                      currentAppStatus === 'inactive' ? 'bg-amber-500 text-stone-950 animate-pulse' : 'bg-emerald-500 text-stone-950'
                    }`}>
                      {currentAppStatus === 'inactive' ? 'INACTIF (Republication)' : 'ACTIF (En Ligne)'}
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-400 mt-0.5">
                    {currentAppStatus === 'inactive'
                      ? 'L\'application est actuellement inactif pour tous les élèves durant la républication.'
                      : 'L\'application est active et utilisable par tous les élèves.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                {currentAppStatus === 'active' ? (
                  <button
                    type="button"
                    disabled={isUpdatingStatus}
                    onClick={() => handleToggleAppStatus('inactive')}
                    className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-black rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    <PowerOff className="w-3.5 h-3.5" />
                    <span>Rendre Inactif (Lancer Républication)</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={isUpdatingStatus}
                    onClick={() => handleToggleAppStatus('active')}
                    className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-stone-950 text-xs font-black rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Réactiver l'Application</span>
                  </button>
                )}
              </div>
            </div>

            {/* Horizontal sub-navigation bar */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1.5 border-b border-stone-200">
              <button
                onClick={() => setActiveTab('stats')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'stats'
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Statistiques
              </button>
              <button
                onClick={() => setActiveTab('add-fiche')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'add-fiche'
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Publier une fiche
              </button>
              <button
                onClick={() => setActiveTab('broadcast')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'broadcast'
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Diffuser une alerte
              </button>
              <button
                onClick={() => setActiveTab('manage')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                  activeTab === 'manage'
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Gérer les fiches ({sheets.length})
              </button>
              <button
                onClick={() => setActiveTab('videos')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1 ${
                  activeTab === 'videos'
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                <Video className="w-3.5 h-3.5" />
                Gérer les Vidéos ({adminVideos.length})
              </button>
            </div>

            <AnimatePresence mode="wait">
              
              {/* STATS DECK */}
              {activeTab === 'stats' && (
                <motion.div
                  key="stats"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <h4 className="text-xs uppercase font-black text-stone-400 flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-stone-500" />
                    Statistiques de la plateforme (Simulées)
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white border border-stone-200/50 p-4 rounded-xl leading-tight shadow-xs">
                      <span className="text-[9px] text-stone-400 uppercase font-bold">Total Inscrits 🇨🇮</span>
                      <strong className="text-xl font-black text-stone-900 font-display mt-0.5 block">1 428</strong>
                    </div>
                    <div className="bg-white border border-stone-200/50 p-4 rounded-xl leading-tight shadow-xs">
                      <span className="text-[9px] text-stone-400 uppercase font-bold">Abonnés Premium 👑</span>
                      <strong className="text-xl font-black text-[#e0620d] font-display mt-0.5 block">325</strong>
                    </div>
                    <div className="bg-white border border-stone-200/50 p-4 rounded-xl leading-tight shadow-xs">
                      <span className="text-[9px] text-stone-400 uppercase font-bold">Fiches de Révision</span>
                      <strong className="text-xl font-black text-stone-900 font-display mt-0.5 block">{totalSheets}</strong>
                    </div>
                    <div className="bg-white border border-stone-200/50 p-4 rounded-xl leading-tight shadow-xs">
                      <span className="text-[9px] text-stone-400 uppercase font-bold">Scans OCR IA</span>
                      <strong className="text-xl font-black text-amber-600 font-display mt-0.5 block">{aiGeneratedSheetsCount}</strong>
                    </div>
                  </div>

                  <div className="bg-amber-500/[0.04] border border-amber-500/10 p-4 rounded-xl text-xs text-stone-600 leading-relaxed">
                    <strong className="font-bold text-stone-800 block mb-1">Matières les plus actives cette semaine :</strong>
                    <div className="flex gap-2 flex-wrap mt-1">
                      <span className="bg-white px-2 py-0.5 rounded border border-stone-200 font-mono font-bold text-stone-700">Mathématiques Terminale (BAC)</span>
                      <span className="bg-white px-2 py-0.5 rounded border border-stone-200 font-mono font-bold text-stone-700">SVT 3ème (BEPC)</span>
                      <span className="bg-white px-2 py-0.5 rounded border border-stone-200 font-mono font-bold text-stone-700">Culture Générale (Concours)</span>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* ADD FICHE FORM */}
              {activeTab === 'add-fiche' && (
                <motion.div
                  key="add-fiche"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <h4 className="text-xs uppercase font-black text-stone-400 flex items-center gap-1.5">
                    <Plus className="w-4 h-4 text-stone-500" />
                    Ajouter une fiche pédagogique officielle
                  </h4>

                  <form onSubmit={handleAddFiche} className="space-y-4 text-xs">
                    
                    {/* Level and Subject selections */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600">Examen</label>
                        <select
                          value={ficheExam}
                          onChange={(e) => setFicheExam(e.target.value as ExamType)}
                          className="w-full p-2.5 bg-white border border-stone-200 rounded-lg"
                        >
                          <option value="BEPC">BEPC (3ème)</option>
                          <option value="BAC">BAC (Terminale)</option>
                          <option value="Concours">Concours</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600">Matière</label>
                        <input
                          type="text"
                          required
                          value={ficheSubject}
                          onChange={(e) => setFicheSubject(e.target.value)}
                          className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-semibold text-stone-800"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Chapitre / Notion principale</label>
                      <input
                        type="text"
                        required
                        placeholder="ex: Les suites numériques"
                        value={ficheChapter}
                        onChange={(e) => setFicheChapter(e.target.value)}
                        className="w-full p-2.5 bg-white border border-stone-200 rounded-lg"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Titre de la leçon</label>
                      <input
                        type="text"
                        required
                        placeholder="ex: Résolution graphique et calcul d'une suite géométrique"
                        value={ficheTitle}
                        onChange={(e) => setFicheTitle(e.target.value)}
                        className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-semibold"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Résumé en une phrase</label>
                      <input
                        type="text"
                        required
                        placeholder="Donnez un résumé accrocheur pour le cahier de révision..."
                        value={ficheSummary}
                        onChange={(e) => setFicheSummary(e.target.value)}
                        className="w-full p-2.5 bg-white border border-stone-200 rounded-lg italic"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <label className="font-bold text-stone-600">Contenu détaillé (Markdown simple)</label>
                        <span className="text-[10px] text-stone-400">### Titre, * Liste, $$Formule$$</span>
                      </div>
                      <textarea
                        required
                        rows={6}
                        placeholder="Rédigez le cours ici. Utilisez des astérisques pour les listes..."
                        value={ficheContent}
                        onChange={(e) => setFicheContent(e.target.value)}
                        className="w-full p-3 bg-white border border-stone-200 rounded-lg font-sans leading-relaxed"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Formules clés (Séparées par des virgules)</label>
                      <input
                        type="text"
                        placeholder="ex: Un = U0 * q^n, Sn = U0 * (1 - q^n)/(1 - q)"
                        value={ficheFormulasText}
                        onChange={(e) => setFicheFormulasText(e.target.value)}
                        className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-mono"
                      />
                    </div>

                    {/* Definitions addition cards */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="font-bold text-stone-600">Définitions ou Glossaire</label>
                        <button
                          type="button"
                          onClick={handleAddDefinitionField}
                          className="text-[10px] font-bold text-amber-600 hover:underline"
                        >
                          + Ajouter un terme
                        </button>
                      </div>

                      <div className="space-y-2 max-h-32 overflow-y-auto pr-1 no-scrollbar">
                        {ficheDefinitions.map((def, idx) => (
                          <div key={idx} className="flex gap-2 items-center bg-stone-50 border border-stone-200 p-2 rounded-lg">
                            <input
                              type="text"
                              placeholder="Terme"
                              value={def.term}
                              onChange={(e) => {
                                const list = [...ficheDefinitions];
                                list[idx].term = e.target.value;
                                setFicheDefinitions(list);
                              }}
                              className="w-1/3 p-1.5 bg-white border border-stone-200 rounded"
                            />
                            <input
                              type="text"
                              placeholder="Signification du terme..."
                              value={def.definition}
                              onChange={(e) => {
                                const list = [...ficheDefinitions];
                                list[idx].definition = e.target.value;
                                setFicheDefinitions(list);
                              }}
                              className="flex-1 p-1.5 bg-white border border-stone-200 rounded"
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
                    >
                      Enregistrer et diffuser la leçon officielle
                    </button>

                  </form>
                </motion.div>
              )}

              {/* BROADCAST ALERTS */}
              {activeTab === 'broadcast' && (
                <motion.div
                  key="broadcast"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <h4 className="text-xs uppercase font-black text-stone-400 flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-stone-500" />
                    Diffuser une notification Push d'étude
                  </h4>

                  <form onSubmit={handleBroadcastNotification} className="space-y-4 text-xs">
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600">Cible des élèves</label>
                        <select
                          value={notifTarget}
                          onChange={(e) => setNotifTarget(e.target.value as any)}
                          className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-bold"
                        >
                          <option value="Tous">Tous les élèves 🇨🇮</option>
                          <option value="BEPC">Niveau BEPC uniquement</option>
                          <option value="BAC">Niveau BAC uniquement</option>
                          <option value="Concours">Candidats Concours</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-stone-600">Type d'alerte</label>
                        <select
                          value={notifType}
                          onChange={(e) => setNotifType(e.target.value as any)}
                          className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-bold"
                        >
                          <option value="info">Information scolaire 💡</option>
                          <option value="rappel">Rappel de révision ⏰</option>
                          <option value="promo">Offre Premium 👑</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Titre de l'alerte</label>
                      <input
                        type="text"
                        required
                        placeholder="ex: Rappel : C'est l'heure de réviser les SVT !"
                        value={notifTitle}
                        onChange={(e) => setNotifTitle(e.target.value)}
                        className="w-full p-2.5 bg-white border border-stone-200 rounded-lg font-bold"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-stone-600">Corps du message push</label>
                      <textarea
                        required
                        rows={4}
                        placeholder="Rédigez le message qui apparaîtra instantanément dans le menu notifications de l'élève..."
                        value={notifMessage}
                        onChange={(e) => setNotifMessage(e.target.value)}
                        className="w-full p-3 bg-white border border-stone-200 rounded-lg font-sans leading-normal"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-500 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
                    >
                      Diffuser la push notification 📣
                    </button>

                  </form>
                </motion.div>
              )}

              {/* MANAGE / DELETE FICHES */}
              {activeTab === 'manage' && (
                <motion.div
                  key="manage"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-3"
                >
                  <h4 className="text-xs uppercase font-black text-stone-400">
                    Cliquez sur l'icône de suppression pour retirer un cours du catalogue
                  </h4>

                  <div className="space-y-2 max-h-96 overflow-y-auto no-scrollbar">
                    {sheets.map((sheet) => (
                      <div
                        key={sheet.id}
                        className="bg-white border border-stone-200 p-3 rounded-xl flex justify-between items-center text-xs shadow-xs"
                      >
                        <div className="space-y-0.5 pr-2 min-w-0">
                          <div className="flex items-center gap-1.5 text-[9px] font-black text-orange-600 uppercase">
                            <span>{sheet.exam}</span>
                            <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                            <span>{sheet.subject}</span>
                          </div>
                          <strong className="text-stone-900 font-bold block line-clamp-1">
                            {sheet.title}
                          </strong>
                        </div>

                        <button
                          onClick={() => handleDeleteFiche(sheet.id)}
                          className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg shrink-0 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* VIDEOS CONFIGURATION PANEL */}
              {activeTab === 'videos' && (
                <motion.div
                  key="videos"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6 text-xs"
                >
                  <div className="space-y-1">
                    <h4 className="text-xs uppercase font-black text-stone-400 flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-stone-500" />
                      {videoFormMode === 'edit' ? 'Modifier la vidéo de révision' : 'Ajouter une vidéo de révision recommandée'}
                    </h4>
                    <p className="text-[11px] text-stone-500">
                      Configurez les cours vidéos YouTube recommandés aux élèves pour chaque matière et niveau d'examen.
                    </p>
                  </div>

                  <form onSubmit={handleSaveVideo} className="bg-white border border-stone-200 p-4 rounded-xl space-y-4 shadow-sm">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Identifiant Vidéo YouTube *</label>
                        <input
                          type="text"
                          required
                          placeholder="ex: Y3mK0_V6qC8"
                          value={vidId}
                          disabled={videoFormMode === 'edit'}
                          onChange={(e) => setVidId(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg font-mono text-stone-800 disabled:opacity-60"
                        />
                        <span className="text-[10px] text-stone-400 block">
                          L'identifiant unique à la fin de l'URL de la vidéo.
                        </span>
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Titre de la Vidéo *</label>
                        <input
                          type="text"
                          required
                          placeholder="ex: Théorème de Thalès - Cours 3ème"
                          value={vidTitle}
                          onChange={(e) => setVidTitle(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-medium"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Nom de la Chaîne *</label>
                        <input
                          type="text"
                          required
                          placeholder="ex: AlloSchool CI"
                          value={vidChannelTitle}
                          onChange={(e) => setVidChannelTitle(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Durée * (Format MM:SS)</label>
                        <input
                          type="text"
                          required
                          placeholder="ex: 12:45"
                          value={vidDuration}
                          onChange={(e) => setVidDuration(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Nombre de vues (Facultatif)</label>
                        <input
                          type="text"
                          placeholder="ex: 15K vues"
                          value={vidViewCount}
                          onChange={(e) => setVidViewCount(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-stone-600 block">Lien Miniature Image (Facultatif)</label>
                        <input
                          type="text"
                          placeholder="Laisser vide pour la miniature YouTube auto"
                          value={vidThumbnailUrl}
                          onChange={(e) => setVidThumbnailUrl(e.target.value)}
                          className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-mono text-[10px]"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="submit"
                        className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-lg shadow-sm transition-all text-center cursor-pointer"
                      >
                        {videoFormMode === 'edit' ? 'Enregistrer les modifications' : 'Ajouter au catalogue vidéo 🎬'}
                      </button>
                      {videoFormMode === 'edit' && (
                        <button
                          type="button"
                          onClick={() => {
                            setVideoFormMode('add');
                            setEditingVideoId(null);
                            setVidId('');
                            setVidTitle('');
                            setVidChannelTitle('');
                            setVidDuration('');
                            setVidViewCount('');
                            setVidThumbnailUrl('');
                          }}
                          className="px-4 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-700 font-bold rounded-lg transition-all cursor-pointer"
                        >
                          Annuler
                        </button>
                      )}
                    </div>
                  </form>

                  <div className="space-y-3">
                    <h5 className="font-black text-[10px] uppercase text-stone-400 tracking-wider">
                      Vidéos Recommandées Actuelles ({adminVideos.length})
                    </h5>

                    {isLoadingVideos ? (
                      <div className="py-6 text-center text-stone-400 font-bold animate-pulse">
                        Chargement du catalogue vidéos...
                      </div>
                    ) : adminVideos.length === 0 ? (
                      <div className="py-8 text-center bg-white border border-stone-150 rounded-xl text-stone-400 font-bold">
                        Aucune vidéo configurée pour le moment.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto no-scrollbar pr-1">
                        {adminVideos.map((video) => (
                          <div
                            key={video.id}
                            className="bg-white border border-stone-200 p-3 rounded-xl flex gap-3 shadow-xs items-center"
                          >
                            <img
                              src={video.thumbnailUrl || `https://img.youtube.com/vi/${video.id}/mqdefault.jpg`}
                              alt={video.title}
                              className="w-16 h-12 object-cover rounded-lg shrink-0 border border-stone-100 bg-stone-100"
                              referrerPolicy="no-referrer"
                            />
                            <div className="flex-1 min-w-0 leading-tight">
                              <span className="text-[9px] bg-stone-100 px-1.5 py-0.5 rounded text-stone-500 font-black tracking-wider uppercase font-mono">
                                {video.duration}
                              </span>
                              <strong className="text-stone-900 font-bold block truncate mt-0.5" title={video.title}>
                                {video.title}
                              </strong>
                              <span className="text-[10px] text-stone-500 block truncate mt-0.5">
                                {video.channelTitle} • {video.viewCount}
                              </span>
                            </div>
                            <div className="flex gap-1.5 shrink-0">
                              <button
                                onClick={() => handleStartEditVideo(video)}
                                className="p-2 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg transition-all cursor-pointer"
                                title="Modifier"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteVideo(video.id)}
                                className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-all cursor-pointer"
                                title="Supprimer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

            </AnimatePresence>

          </div>
        )}

      </div>
    </div>
  );
}
