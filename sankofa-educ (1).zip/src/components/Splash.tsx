/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import SankofaLogo from './SankofaLogo';

interface SplashProps {
  onComplete: () => void;
}

export default function Splash({ onComplete }: SplashProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 600); // Small buffer for animation
          return 100;
        }
        return prev + 4;
      });
    }, 80);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="flex flex-col items-center justify-between h-full bg-[#fcfbf7] text-stone-900 p-8 font-sans">
      {/* Empty top for centering */}
      <div></div>

      {/* Center content */}
      <div className="flex flex-col items-center text-center">
        {/* Animated Sankofa Bird Emblem */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, type: 'spring' }}
          className="w-64 h-auto mb-4"
        >
          <SankofaLogo showText={true} lightText={false} />
        </motion.div>
      </div>

      {/* Loading section */}
      <div className="w-full max-w-xs flex flex-col items-center">
        <div className="w-full h-1 bg-stone-800 rounded-full overflow-hidden mb-3">
          <motion.div
            className="h-full bg-gradient-to-r from-amber-500 to-orange-500"
            style={{ width: `${progress}%` }}
          ></motion.div>
        </div>
        <span className="text-xs text-stone-400 font-mono">
          Chargement des ressources... {progress}%
        </span>
      </div>
    </div>
  );
}
