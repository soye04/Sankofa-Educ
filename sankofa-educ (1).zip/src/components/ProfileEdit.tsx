/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, User, Phone, Mail, GraduationCap, Save, Loader2, Check, Bell, Clock, Send, ShieldCheck } from 'lucide-react';
import { ExamType } from '../types';
import { dbSaveProfile } from '../lib/firebase';
import { requestNotificationPermission, sendTestNotification, getReminderSettings, saveReminderSettings } from '../lib/pwaNotification';
import { initializeFCM, checkFcmSupport } from '../lib/fcm';

interface ProfileEditProps {
  user: {
    name: string;
    email: string;
    phone: string;
    targetExam: ExamType;
    series: string;
  };
  onSave: (updatedUser: {
    name: string;
    email: string;
    phone: string;
    targetExam: ExamType;
    series: string;
  }) => void;
  onClose: () => void;
  triggerToast: (msg: string) => void;
}

export default function ProfileEdit({ user, onSave, onClose, triggerToast }: ProfileEditProps) {
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone === 'Non renseigné' ? '' : user.phone);
  const [targetExam, setTargetExam] = useState<ExamType>(user.targetExam);
  const [bacSeries, setBacSeries] = useState(user.targetExam === 'BAC' ? user.series : 'D');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  // Push Notification & Revision Reminder state
  const [reminderSettings, setReminderSettings] = useState(getReminderSettings());
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [fcmToken, setFcmToken] = useState<string | null>(localStorage.getItem('sankofa_fcm_token'));
  const [fcmLoading, setFcmLoading] = useState(false);

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const handleRegisterFcm = async () => {
    setFcmLoading(true);
    try {
      const token = await initializeFCM(user.email);
      if (token) {
        setFcmToken(token);
        triggerToast('Firebase Cloud Messaging (FCM) activé avec succès ! 🚀');
      } else {
        triggerToast('Impossible d\'obtenir le jeton FCM. Vérifiez les autorisations du navigateur.');
      }
    } catch (err) {
      triggerToast('Erreur lors de l\'activation de Firebase Cloud Messaging.');
    } finally {
      setFcmLoading(false);
    }
  };

  const handleToggleReminders = async () => {
    if (!reminderSettings.enabled) {
      const perm = await requestNotificationPermission();
      setPermission(perm);
      if (perm === 'granted') {
        const updated = { ...reminderSettings, enabled: true };
        setReminderSettings(updated);
        saveReminderSettings(updated);
        triggerToast('Notifications Push activées pour vos révisions ! 🔔');
      } else {
        triggerToast('Veuillez autoriser les notifications dans votre navigateur.');
      }
    } else {
      const updated = { ...reminderSettings, enabled: false };
      setReminderSettings(updated);
      saveReminderSettings(updated);
      triggerToast('Rappels de révision désactivés.');
    }
  };

  const handleTimeChange = (newTime: string) => {
    const updated = { ...reminderSettings, time: newTime };
    setReminderSettings(updated);
    saveReminderSettings(updated);
    triggerToast(`Rappel quotidien programmé à ${newTime} ! ⏰`);
  };

  const handleTestPush = () => {
    sendTestNotification(
      '📚 Sankofa Educ - Rappel de Révision',
      `C'est l'heure de ta session quotidienne pour le ${targetExam} !`
    );
    triggerToast('Notification de test envoyée 🚀');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Le nom complet est requis.');
      return;
    }

    if (phone) {
      const cleanPhone = phone.replace(/\s+/g, '');
      if (!/^(01|05|07)\d{8}$/.test(cleanPhone)) {
        setError('Veuillez entrer un numéro ivoirien valide à 10 chiffres (commençant par 01, 05 ou 07).');
        return;
      }
    }

    setIsSaving(true);
    const selectedSeries = targetExam === 'BAC' ? bacSeries : 'Général';
    const updatedUser = {
      ...user,
      name: name.trim(),
      phone: phone.trim() || 'Non renseigné',
      targetExam,
      series: selectedSeries,
    };

    try {
      // 1. Save to Firestore if email is available
      if (user.email) {
        await dbSaveProfile(user.email, updatedUser);
      }
      
      // 2. Update parent state & LocalStorage
      onSave(updatedUser);
      triggerToast('Profil mis à jour avec succès ! ✨');
      onClose();
    } catch (err: any) {
      console.error('Failed to save profile:', err);
      // Fallback: save locally even if firestore fails
      onSave(updatedUser);
      triggerToast('Profil mis à jour localement.');
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7] font-sans text-stone-900">
      {/* Header section */}
      <header className="px-4 py-4 bg-white border-b border-stone-200/60 flex items-center justify-between sticky top-0 z-10 shrink-0">
        <button
          onClick={onClose}
          className="p-2 hover:bg-stone-100 rounded-full text-stone-600 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-sm font-black font-display text-stone-900 uppercase tracking-wider">
          Modifier mon Profil
        </h2>
        <div className="w-9" /> {/* Spacer to align title */}
      </header>

      {/* Main Form content */}
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-6">
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-600 font-medium">
            {error}
          </div>
        )}

        {/* Profile picture illustration */}
        <div className="flex flex-col items-center gap-2 py-2">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white font-bold text-2xl border-4 border-white shadow-md relative">
            {name ? name.charAt(0).toUpperCase() : user.name.charAt(0).toUpperCase()}
            <div className="absolute -bottom-1 -right-1 bg-[#3c2518] text-amber-400 p-1.5 rounded-full border border-white shadow-sm">
              <User className="w-3.5 h-3.5" />
            </div>
          </div>
          <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider mt-1">Sankofa Élève</span>
        </div>

        {/* Inputs */}
        <div className="space-y-4">
          {/* Full Name Field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">
              Nom complet
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                required
                placeholder="Votre nom complet"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500 transition-all font-sans"
              />
            </div>
          </div>

          {/* Email Field (Disabled) */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-400 uppercase tracking-wider block flex justify-between">
              <span>Adresse Email</span>
              <span className="text-[9px] text-stone-400 lowercase font-normal italic">Identifiant non modifiable</span>
            </label>
            <div className="relative opacity-60">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                disabled
                value={user.email}
                className="w-full pl-10 pr-4 py-3 bg-stone-100 rounded-xl border border-stone-200 text-stone-500 text-sm focus:outline-none cursor-not-allowed font-sans"
              />
            </div>
          </div>

          {/* Phone Field */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">
              Numéro de téléphone
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-500 font-bold text-sm">
                +225
              </span>
              <input
                type="tel"
                placeholder="07 05 01 23 45"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full pl-14 pr-4 py-3 bg-white rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500 font-mono transition-all"
              />
            </div>
          </div>

          {/* Target Exam */}
          <div className="space-y-2 pt-2">
            <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">
              Examen ou Concours ciblé
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['BEPC', 'BAC', 'Concours'] as ExamType[]).map((exam) => (
                <button
                  type="button"
                  key={exam}
                  onClick={() => setTargetExam(exam)}
                  className={`py-2 px-1 rounded-xl text-center border text-xs font-bold transition-all cursor-pointer ${
                    targetExam === exam
                      ? 'bg-[#3c2518] text-white border-transparent shadow-sm'
                      : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  {exam}
                </button>
              ))}
            </div>

            {/* Subchoices based on selection */}
            {targetExam === 'BAC' && (
              <div className="flex items-center gap-3 bg-stone-100 p-2.5 rounded-xl text-xs mt-2 animate-fade-in">
                <span className="font-semibold text-stone-600">Série BAC :</span>
                {['A', 'C', 'D'].map((s) => (
                  <button
                    type="button"
                    key={s}
                    onClick={() => setBacSeries(s)}
                    className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                      bacSeries === s ? 'bg-amber-500 text-stone-950 shadow-xs' : 'bg-white text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    Série {s}
                  </button>
                ))}
              </div>
            )}

            {targetExam === 'BEPC' && (
              <div className="flex items-center gap-3 bg-stone-100 p-2.5 rounded-xl text-xs mt-2">
                <span className="font-semibold text-stone-600">Série BEPC :</span>
                <span className="bg-amber-500 text-stone-950 px-2.5 py-1 rounded-lg font-bold shadow-xs">
                  Enseignement Général
                </span>
              </div>
            )}

            {targetExam === 'Concours' && (
              <div className="flex items-center gap-3 bg-stone-100 p-2.5 rounded-xl text-xs mt-2">
                <span className="font-semibold text-stone-600">Filière :</span>
                <span className="bg-amber-500 text-stone-950 px-2.5 py-1 rounded-lg font-bold shadow-xs">
                  Préparation Standard
                </span>
              </div>
            )}
          </div>
        </div>

        {/* SECTION: PWA PUSH NOTIFICATIONS & DAILY REMINDERS */}
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-orange-200/80 p-4.5 rounded-2xl space-y-3.5 shadow-2xs mt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-orange-600 text-white flex items-center justify-center shadow-xs">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-black font-display text-stone-900">Rappels Quotidiens PWA</h4>
                <p className="text-[10px] text-stone-600 font-medium">Notifications push de révision aux heures choisies</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleToggleReminders}
              className={`w-12 h-6.5 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                reminderSettings.enabled ? 'bg-orange-600' : 'bg-stone-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform ${
                  reminderSettings.enabled ? 'translate-x-5.5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {reminderSettings.enabled && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3 pt-2 border-t border-orange-200/60"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-stone-700 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-orange-600" />
                  Heure du rappel quotidien :
                </span>
                <select
                  value={reminderSettings.time}
                  onChange={(e) => handleTimeChange(e.target.value)}
                  className="px-3 py-1.5 bg-white border border-orange-300 rounded-xl font-bold text-stone-800 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-2xs"
                >
                  <option value="07:00">07:00 (Matin réveil)</option>
                  <option value="12:00">12:00 (Pause midi)</option>
                  <option value="17:00">17:00 (Après les cours)</option>
                  <option value="18:30">18:30 (Soirée révision)</option>
                  <option value="20:00">20:00 (Avant de dormir)</option>
                </select>
              </div>

              <div className="flex items-center justify-between text-[11px] bg-white/70 p-2.5 rounded-xl border border-orange-100">
                <span className="text-stone-600 font-medium flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Statut Navigateur: <strong className="text-stone-800 capitalize">{permission}</strong>
                </span>

                <button
                  type="button"
                  onClick={handleTestPush}
                  className="px-2.5 py-1 bg-stone-900 hover:bg-stone-800 text-amber-400 font-bold rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer shadow-2xs"
                >
                  <Send className="w-3 h-3" />
                  Tester la notification
                </button>
              </div>
            </motion.div>
          )}
        </div>

        {/* SECTION: FIREBASE CLOUD MESSAGING (FCM) STATUS & REGISTRATION */}
        <div className="bg-stone-900 border border-stone-800 p-4.5 rounded-2xl space-y-3 text-white shadow-sm mt-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black shadow-xs">
                FCM
              </div>
              <div>
                <h4 className="text-xs font-black font-display text-amber-400 flex items-center gap-1.5">
                  Firebase Cloud Messaging
                  {fcmToken && (
                    <span className="bg-emerald-500/20 text-emerald-400 text-[9px] px-1.5 py-0.5 rounded-md font-mono border border-emerald-500/30">
                      Actif
                    </span>
                  )}
                </h4>
                <p className="text-[10px] text-stone-400">Push notifications en temps réel pour le BEPC / BAC</p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleRegisterFcm}
              disabled={fcmLoading}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
            >
              {fcmLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : fcmToken ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Jeton Actif
                </>
              ) : (
                <>
                  <Bell className="w-3.5 h-3.5" />
                  Activer FCM
                </>
              )}
            </button>
          </div>

          {fcmToken && (
            <div className="bg-stone-950/80 p-2.5 rounded-xl border border-stone-800 text-[10px] space-y-1 font-mono text-stone-400 break-all">
              <span className="text-amber-400 font-bold font-sans">Jeton FCM de l'appareil :</span>
              <p className="text-[9px] opacity-80">{fcmToken.slice(0, 45)}...</p>
            </div>
          )}
        </div>

        {/* Action Button */}
        <button
          type="submit"
          disabled={isSaving}
          className="w-full py-3.5 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 disabled:opacity-50 text-white font-bold rounded-xl shadow-md hover:shadow-lg flex items-center justify-center gap-2 mt-8 transition-all text-sm cursor-pointer"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Enregistrement en cours...</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>Enregistrer les modifications</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}
