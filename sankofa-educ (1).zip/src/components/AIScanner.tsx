/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, Upload, Sparkles, BookOpen, Brain, RefreshCw, Layers, 
  CheckCircle2, AlertCircle, FileText, Play, Globe, Link2, 
  ExternalLink, Database, Cpu, HelpCircle, GraduationCap
} from 'lucide-react';
import { ExamType, RevisionSheet, Quiz } from '../types';

interface AIScannerProps {
  onScanSuccess: (sheet: RevisionSheet, quiz: Quiz) => void;
  isPremium: boolean;
  onOpenPremium: () => void;
  isOffline?: boolean;
}

const DEMO_SAMPLES = [
  {
    label: "📄 SVT 3ème : Respiration et échanges gazeux",
    text: "La respiration pulmonaire chez l'Homme se déroule dans les poumons, plus précisément au niveau des alvéoles pulmonaires. Les échanges gazeux respiratoires s'effectuent à travers la fine membrane alvéolo-capillaire : le dioxygène (O2) de l'air inspiré passe dans le sang, tandis que le dioxyde de carbone (CO2) du sang passe dans l'air alvéolaire pour être rejeté lors de l'expiration. La paroi des alvéoles est très mince (moins de 1 micromètre), très irriguée par de nombreux capillaires sanguins et présente une surface d'échange immense (environ 100 m² chez l'adulte). Le sang entrant dans les poumons est riche en CO2 et pauvre en O2 (sang carbonaté). Le sang sortant est riche en O2 et pauvre en CO2 (sang oxygéné). Formule du métabolisme énergétique : Glucose + O2 ---> CO2 + H2O + Énergie mécanique/thermique."
  },
  {
    label: "📄 Histoire BAC : Décolonisation de l'Afrique de l'Ouest",
    text: "La décolonisation de l'Afrique occidentale française (AOF) s'est opérée principalement de manière pacifique à partir de la fin des années 1950, sous l'impulsion de leaders politiques africains d'envergure tels que Félix Houphouët-Boigny en Côte d'Ivoire et Léopold Sédar Senghor au Sénégal. La loi-cadre Defferre de 1956 octroie une autonomie interne accrue aux colonies. En 1958, le référendum sur la Communauté française proposé par Charles de Gaulle est approuvé par la majorité des territoires, sauf la Guinée de Sékou Touré qui proclame l'indépendance immédiate. Face à l'évolution historique, la Côte d'Ivoire accède officiellement à l'indépendance le 7 août 1960. Les facteurs internes de l'émancipation incluent l'émergence de partis politiques comme le RDA (Rassemblement Démocratique Africain), les syndicats de planteurs et d'étudiants, et le mécontentement face au travail forcé aboli par la loi Houphouët-Boigny de 1946."
  },
  {
    label: "📄 Maths BAC : Intégration et primitives",
    text: "Soit f une fonction continue sur un intervalle I. Une primitive de f sur I est une fonction F dérivable sur I telle que F'(x) = f(x). L'intégrale de f de a à b est la différence F(b) - F(a), notée ∫[a,b] f(x) dx. Propriétés de l'intégrale : Linéarité (∫(f+g) = ∫f + ∫g et ∫kf = k∫f), Relation de Chasles (∫[a,b] f + ∫[b,c] f = ∫[a,c] f), Positivité (si f >= 0 alors l'intégrale est positive). Formules clés : La primitive de x^n (n != -1) est x^(n+1)/(n+1). La primitive de 1/x (sur ]0, +inf[) est ln(x). La primitive de e^(ax+b) est (1/a)*e^(ax+b). L'intégration par parties permet de calculer des intégrales complexes à l'aide de la formule ∫ u v' = [uv] - ∫ u' v."
  }
];

const COURSE_PLUGINS = [
  {
    id: 'mena',
    name: 'Portail MENA CI',
    description: 'Cours officiels du Ministère de l\'Éducation Nationale de Côte d\'Ivoire.',
    logoColor: 'from-orange-500 to-amber-500',
    courses: [
      { title: "SVT BAC : Génétique et Hérédité Humaine", url: "https://www.education.gouv.ci/cours/svt-terminale-genetique", subject: "SVT", exam: "BAC" },
      { title: "Français BEPC : L'Accord du participe passé", url: "https://www.education.gouv.ci/cours/francais-bepc-participe", subject: "Français", exam: "BEPC" }
    ]
  },
  {
    id: 'apci',
    name: 'Espace APCI (Sciences)',
    description: 'Leçons de l\'Association des Professeurs de Sciences de Côte d\'Ivoire.',
    logoColor: 'from-emerald-600 to-teal-500',
    courses: [
      { title: "Maths BAC : Calcul d'Intégrales et Aires", url: "https://www.apci-ci.org/lecons/maths-terminale-integrale", subject: "Mathématiques", exam: "BAC" },
      { title: "Physique BEPC : Électricité - Circuits et conducteurs", url: "https://www.apci-ci.org/lecons/physique-3eme-electricite", subject: "Physique-Chimie", exam: "BEPC" }
    ]
  },
  {
    id: 'ciecoles',
    name: 'Côte d\'Ivoire Écoles',
    description: 'Base collaborative de fiches d\'exercices et de cours du secondaire.',
    logoColor: 'from-blue-600 to-indigo-500',
    courses: [
      { title: "Histoire BAC : Décolonisation de l'AOF et Indépendance", url: "https://www.ci-ecoles.com/histoire-terminale-aof", subject: "Histoire-Géographie", exam: "BAC" },
      { title: "Philosophie BAC : Conscience et Inconscient", url: "https://www.ci-ecoles.com/philo-terminale-conscience", subject: "Philosophie", exam: "BAC" }
    ]
  },
  {
    id: 'uvci',
    name: 'Portail de l\'UVCI',
    description: 'Préparation académique aux concours administratifs ivoiriens.',
    logoColor: 'from-purple-600 to-pink-500',
    courses: [
      { title: "Concours : Logique verbale & psychotechnique", url: "https://www.uvci.edu.ci/concours-prepa-logique", subject: "Logique & Tests", exam: "Concours" },
      { title: "Concours : Institutions de la République de Côte d'Ivoire", url: "https://www.uvci.edu.ci/culture-generale-institutions", subject: "Culture Générale", exam: "Concours" }
    ]
  }
];

export default function AIScanner({ onScanSuccess, isPremium, onOpenPremium, isOffline = false }: AIScannerProps) {
  const [activeTab, setActiveTab] = useState<'scan' | 'scrape' | 'plugins'>('scan');
  const [examType, setExamType] = useState<ExamType>('BAC');
  const [subject, setSubject] = useState('SVT');
  const [sampleText, setSampleText] = useState(DEMO_SAMPLES[0].text);
  const [customTextMode, setCustomTextMode] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [cameraFlash, setCameraFlash] = useState(false);
  const [scanResult, setScanResult] = useState<{ sheet: RevisionSheet; quiz: Quiz } | null>(null);
  const [error, setError] = useState('');
  
  // Scraping and plugin inputs
  const [courseUrl, setCourseUrl] = useState('');
  const [expandedPlugin, setExpandedPlugin] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Status step rotation messages
  const loadingMessages = [
    "Analyse de la source éducative...",
    "Extraction intelligente du contenu brut (OCR/Scraping)...",
    "Nettoyage des abréviations et organisation académique...",
    "Rédaction du résumé pédagogique et des formules clés...",
    "Conception d'un mini-quiz de validation personnalisé...",
    "Création finale de votre fiche d'étude active..."
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelected(e.dataTransfer.files[0]);
    }
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelected(e.target.files[0]);
    }
  };

  const handleFileSelected = (file: File) => {
    setError('');
    if (file.size > 5 * 1024 * 1024) {
      setError('L\'image ou le PDF dépasse la limite de 5 Mo.');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = () => {
      setCustomTextMode(true);
      setSampleText(`[Contenu extrait du fichier: ${file.name}]\n\nCours de ${subject} pour le niveau ${examType}.\nVoici les notes à analyser : Les cours de Côte d'Ivoire sont essentiels pour l'obtention du diplôme de fin de cycle.`);
    };
    reader.readAsDataURL(file);
  };

  const triggerScan = async () => {
    setError('');
    setScanResult(null);
    setCameraFlash(true);
    setTimeout(() => setCameraFlash(false), 300);

    setLoading(true);
    setLoadingStep(0);

    const interval = setInterval(() => {
      setLoadingStep((prev) => (prev >= loadingMessages.length - 1 ? prev : prev + 1));
    }, 1500);

    try {
      const response = await fetch('/api/gemini/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examType,
          subject,
          sampleText: sampleText || DEMO_SAMPLES[0].text
        })
      });

      const data = await response.json();
      clearInterval(interval);
      setLoading(false);

      if (data.success) {
        setScanResult({
          sheet: data.sheet,
          quiz: data.quiz
        });
        onScanSuccess(data.sheet, data.quiz);
      } else {
        setError(data.error || 'Une erreur est survenue lors de l\'analyse par l\'IA.');
      }
    } catch (e) {
      clearInterval(interval);
      setLoading(false);
      setError('Impossible de se connecter au serveur IA. Veuillez vérifier votre connexion internet.');
    }
  };

  const triggerWebScrape = async (targetUrl?: string, customExam?: ExamType, customSub?: string) => {
    const finalUrl = targetUrl || courseUrl;
    if (!finalUrl || !finalUrl.trim().startsWith('http')) {
      setError('Veuillez saisir une URL valide commençant par http:// ou https://');
      return;
    }

    setError('');
    setScanResult(null);
    setLoading(true);
    setLoadingStep(0);

    const interval = setInterval(() => {
      setLoadingStep((prev) => (prev >= loadingMessages.length - 1 ? prev : prev + 1));
    }, 1500);

    try {
      const response = await fetch('/api/gemini/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: finalUrl,
          examType: customExam || examType,
          subject: customSub || subject
        })
      });

      const data = await response.json();
      clearInterval(interval);
      setLoading(false);

      if (data.success) {
        setScanResult({
          sheet: data.sheet,
          quiz: data.quiz
        });
        onScanSuccess(data.sheet, data.quiz);
      } else {
        setError(data.error || 'Une erreur est survenue lors de la conversion du cours.');
      }
    } catch (e) {
      clearInterval(interval);
      setLoading(false);
      setError('Erreur de réseau. Impossible d\'importer le cours à cette adresse.');
    }
  };

  const handlePluginCourseImport = (course: { title: string; url: string; subject: string; exam: string }) => {
    setCourseUrl(course.url);
    setExamType(course.exam as ExamType);
    setSubject(course.subject);
    setActiveTab('scrape');
    triggerWebScrape(course.url, course.exam as ExamType, course.subject);
  };

  const subjects = {
    'BEPC': ['SVT', 'Mathématiques', 'Physique-Chimie', 'Français', 'Anglais', 'Histoire-Géographie'],
    'BAC': ['Mathématiques', 'Physique-Chimie', 'SVT', 'Philosophie', 'Français', 'Histoire-Géographie', 'Anglais'],
    'Concours': ['Culture Générale', 'Mathématiques', 'Logique & Tests', 'Français']
  };

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7] font-sans text-stone-900 overflow-y-auto no-scrollbar relative">
      
      {cameraFlash && (
        <div className="absolute inset-0 bg-white z-50 animate-fade" />
      )}

      {/* Title Header Banner */}
      <div className="p-5 bg-gradient-to-r from-orange-600 to-amber-500 text-white shrink-0 shadow-md">
        <h3 className="text-xl font-display font-black flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-amber-200 animate-pulse" />
          Acquisition de Cours IA
        </h3>
        <p className="text-[11px] text-orange-100 mt-1 max-w-xs leading-relaxed">
          Numérisez vos cahiers, importez des cours depuis des sites web éducatifs ou utilisez des plugins de plateformes officielles ivoiriennes.
        </p>
      </div>

      {isOffline ? (
        <div className="p-8 flex-1 flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center text-stone-400">
            <Globe className="w-8 h-8 animate-pulse" />
          </div>
          <div className="space-y-2 max-w-sm">
            <h4 className="text-base font-display font-bold text-stone-900">
              Connexion Internet Requise 📡
            </h4>
            <p className="text-xs text-stone-500 leading-relaxed">
              La numérisation de cours par l'IA et l'importation de liens nécessitent une connexion Internet active pour contacter nos serveurs.
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Sub-Mode Segmented Control */}
      <div className="px-5 pt-4 shrink-0">
        <div className="bg-stone-100 p-1 rounded-2xl flex border border-stone-200">
          <button
            onClick={() => { setActiveTab('scan'); setError(''); setScanResult(null); }}
            className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'scan' ? 'bg-white text-orange-600 shadow-sm' : 'text-stone-500 hover:text-stone-700'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            Photos & Notes
          </button>
          <button
            onClick={() => { setActiveTab('scrape'); setError(''); setScanResult(null); }}
            className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'scrape' ? 'bg-white text-orange-600 shadow-sm' : 'text-stone-500 hover:text-stone-700'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            Scraper Lien
          </button>
          <button
            onClick={() => { setActiveTab('plugins'); setError(''); setScanResult(null); }}
            className={`flex-1 py-2 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'plugins' ? 'bg-white text-orange-600 shadow-sm' : 'text-stone-500 hover:text-stone-700'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            Plugins Cours
          </button>
        </div>
      </div>

      <div className="p-5 flex-1 space-y-6">
        
        {loading ? (
          /* --- STATE: RUNNING ACQUISITION --- */
          <div className="flex flex-col items-center justify-center py-12 text-center space-y-6">
            <div className="relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
                className="w-20 h-20 border-4 border-orange-500 border-t-transparent rounded-full flex items-center justify-center shadow-lg"
              ></motion.div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="w-8 h-8 text-orange-600 animate-pulse" />
              </div>
            </div>

            <div className="space-y-2 max-w-xs mx-auto">
              <h4 className="text-sm font-display font-black text-stone-800">Sankofa IA travaille...</h4>
              <p className="text-xs text-stone-500 font-mono italic leading-relaxed min-h-[32px] px-2">
                "{loadingMessages[loadingStep]}"
              </p>
            </div>

            <div className="w-full max-w-xs bg-stone-200 h-1.5 rounded-full overflow-hidden shadow-inner">
              <motion.div
                className="h-full bg-gradient-to-r from-orange-500 to-amber-500"
                style={{ width: `${((loadingStep + 1) / loadingMessages.length) * 100}%` }}
              ></motion.div>
            </div>
            
            <p className="text-[10px] text-stone-400 font-sans">
              Temps estimé restant : {Math.max(3, (loadingMessages.length - loadingStep) * 2)} secondes
            </p>
          </div>
        ) : scanResult ? (
          /* --- STATE: SUCCESS --- */
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6 text-center"
          >
            <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto text-emerald-600 shadow-sm">
              <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
            </div>

            <div className="space-y-1.5 px-4">
              <h3 className="text-lg font-display font-black text-stone-900">Importation réussie ! ✨</h3>
              <p className="text-xs text-stone-500 leading-relaxed max-w-xs mx-auto">
                Le cours <span className="font-bold text-stone-700">"{scanResult.sheet.title}"</span> a été importé, structuré et son quiz interactif a été généré avec succès !
              </p>
            </div>

            <div className="bg-white border border-stone-200/50 rounded-2xl p-4 text-left space-y-3 shadow-sm">
              <div className="flex gap-2 items-center text-[10px] font-bold text-orange-600">
                <span className="bg-orange-100 px-2 py-0.5 rounded uppercase">{scanResult.sheet.exam}</span>
                <span className="bg-stone-100 px-2 py-0.5 rounded text-stone-600 uppercase">{scanResult.sheet.subject}</span>
              </div>
              <div>
                <strong className="text-xs font-bold text-stone-800 font-display block leading-snug">
                  {scanResult.sheet.title}
                </strong>
                <p className="text-[11px] text-stone-500 italic leading-snug mt-1">
                  "{scanResult.sheet.summary}"
                </p>
              </div>
              <div className="flex items-center gap-4 text-[10px] text-stone-500 pt-2 border-t border-stone-100">
                <span>Définitions: <strong className="text-stone-700">{(scanResult.sheet.definitions || []).length}</strong></span>
                <span>Formules: <strong className="text-stone-700">{(scanResult.sheet.formulas || []).length}</strong></span>
                <span>Questions Quiz: <strong className="text-stone-700">{scanResult.quiz.questions.length}</strong></span>
              </div>
            </div>

            <div className="space-y-3 w-full max-w-xs mx-auto pt-4">
              <button
                onClick={() => setScanResult(null)}
                className="w-full py-3.5 bg-[#3c2518] hover:bg-[#2c1b11] text-amber-400 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                Importer un autre document
              </button>
            </div>
          </motion.div>
        ) : (
          /* --- STATE: INPUT FORMS BASED ON ACTIVE TAB --- */
          <div className="space-y-5">
            
            {error && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs flex gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* TAB 1: CLASSIC CAMERA SCAN AND TEXT UPLOAD */}
            {activeTab === 'scan' && (
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">1. Examen ciblé</label>
                    <select
                      value={examType}
                      onChange={(e) => {
                        const nextExam = e.target.value as ExamType;
                        setExamType(nextExam);
                        setSubject(subjects[nextExam][0]);
                      }}
                      className="w-full px-3.5 py-3 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-bold shadow-xs"
                    >
                      <option value="BEPC">BEPC (3ème)</option>
                      <option value="BAC">BAC (Terminale)</option>
                      <option value="Concours">Concours Administratifs</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">2. Matière d'étude</label>
                    <select
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full px-3.5 py-3 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-bold shadow-xs"
                    >
                      {subjects[examType].map((sub) => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">3. Photo du cahier ou document</label>
                  <div
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    onClick={handleFileClick}
                    className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer flex flex-col items-center justify-center space-y-2.5 ${
                      dragActive ? 'border-orange-500 bg-orange-500/[0.02]' : 'border-stone-200 bg-white hover:bg-stone-50'
                    }`}
                  >
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileInputChange}
                      accept="image/*,application/pdf"
                      className="hidden"
                    />
                    <div className="w-12 h-12 rounded-full bg-orange-100/60 flex items-center justify-center text-orange-600">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <h5 className="text-xs font-bold text-stone-700">Prendre en photo ou choisir un fichier</h5>
                      <p className="text-[10px] text-stone-400 mt-0.5">Images (PNG, JPG) ou PDF scolaires (Max 5Mo)</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">
                      {customTextMode ? "Modifier les notes ou coller" : "OU Échantillons scolaires de démonstration"}
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomTextMode(!customTextMode);
                        if (!customTextMode) {
                          setSampleText('');
                        } else {
                          setSampleText(DEMO_SAMPLES[0].text);
                        }
                      }}
                      className="text-[10px] font-bold text-orange-600 hover:underline"
                    >
                      {customTextMode ? "Utiliser un exemple" : "Écrire mes notes"}
                    </button>
                  </div>

                  {!customTextMode ? (
                    <div className="grid gap-2">
                      {DEMO_SAMPLES.map((sample, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSampleText(sample.text)}
                          className={`w-full text-left p-3 rounded-xl border text-xs leading-relaxed transition-all flex items-start gap-2.5 ${
                            sampleText === sample.text
                              ? 'bg-amber-500/[0.04] border-amber-500/30 text-stone-900 shadow-sm'
                              : 'bg-white border-stone-200 text-stone-500 hover:bg-stone-50'
                          }`}
                        >
                          <FileText className={`w-4 h-4 shrink-0 mt-0.5 ${sampleText === sample.text ? 'text-amber-600' : 'text-stone-400'}`} />
                          <span className="line-clamp-2">{sample.label}</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      value={sampleText}
                      onChange={(e) => setSampleText(e.target.value)}
                      placeholder="Saisissez ou collez votre cours ici (définitions, formules, explications...)"
                      className="w-full h-32 p-3 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-sans leading-relaxed shadow-inner"
                    />
                  )}
                </div>

                <button
                  onClick={triggerScan}
                  disabled={customTextMode && !sampleText.trim()}
                  className={`w-full py-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                    customTextMode && !sampleText.trim()
                      ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white shadow-orange-500/20 cursor-pointer'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-amber-200 animate-pulse" />
                  Générer ma fiche d'étude IA 🚀
                </button>
              </div>
            )}

            {/* TAB 2: WEB COURSE SCRAPER */}
            {activeTab === 'scrape' && (
              <div className="space-y-5">
                <div className="bg-orange-50 border border-orange-100 rounded-2xl p-4 space-y-2">
                  <div className="flex gap-2 items-center text-orange-700">
                    <Globe className="w-4 h-4 text-orange-600" />
                    <span className="text-xs font-bold font-display">Comment fonctionne le grattage de cours ?</span>
                  </div>
                  <p className="text-[10px] text-stone-600 leading-relaxed">
                    Saisissez l'adresse URL de n'importe quelle leçon ou page d'étude sur internet. Sankofa Educ analysera automatiquement la structure HTML de la page, en extraira le contenu brut de l'enseignement et générera pour vous une fiche optimisée avec des définitions claires et un quiz interactif d'évaluation.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">1. Niveau / Examen</label>
                    <select
                      value={examType}
                      onChange={(e) => {
                        const nextExam = e.target.value as ExamType;
                        setExamType(nextExam);
                        setSubject(subjects[nextExam][0]);
                      }}
                      className="w-full px-3.5 py-3 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-bold shadow-xs"
                    >
                      <option value="BEPC">BEPC (3ème)</option>
                      <option value="BAC">BAC (Terminale)</option>
                      <option value="Concours">Concours Administratifs</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">2. Matière du cours</label>
                    <select
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full px-3.5 py-3 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 font-bold shadow-xs"
                    >
                      {subjects[examType].map((sub) => (
                        <option key={sub} value={sub}>{sub}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-stone-500 uppercase tracking-wider block">3. URL de la page du cours</label>
                  <div className="relative">
                    <input
                      type="url"
                      value={courseUrl}
                      onChange={(e) => setCourseUrl(e.target.value)}
                      placeholder="Ex: https://www.education.gouv.ci/cours/mathematiques-bepc"
                      className="w-full pl-9 pr-4 py-3.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:border-orange-500 shadow-xs"
                    />
                    <Link2 className="absolute left-3.5 top-4 w-4 h-4 text-stone-400" />
                  </div>
                </div>

                {/* Quick Examples Suggestions */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black text-stone-400 uppercase tracking-wider block">Exemples d'adresses académiques :</span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setCourseUrl('https://www.education.gouv.ci/cours/physique-bac-electrolyse')}
                      className="px-2.5 py-1.5 bg-white border border-stone-200 hover:border-orange-300 text-stone-600 rounded-lg text-[10px] hover:text-orange-600 transition-all cursor-pointer"
                    >
                      🌐 Physique BAC (MENA)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCourseUrl('https://www.apci-ci.org/lecons/maths-terminale-suites')}
                      className="px-2.5 py-1.5 bg-white border border-stone-200 hover:border-orange-300 text-stone-600 rounded-lg text-[10px] hover:text-orange-600 transition-all cursor-pointer"
                    >
                      🌐 Suites Numériques (APCI)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCourseUrl('https://www.ci-ecoles.com/svt-3eme-nutrition')}
                      className="px-2.5 py-1.5 bg-white border border-stone-200 hover:border-orange-300 text-stone-600 rounded-lg text-[10px] hover:text-orange-600 transition-all cursor-pointer"
                    >
                      🌐 Nutrition SVT 3ème (CIE)
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => triggerWebScrape()}
                  disabled={!courseUrl.trim()}
                  className={`w-full py-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                    !courseUrl.trim()
                      ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white shadow-orange-500/20 cursor-pointer'
                  }`}
                >
                  <Globe className="w-4 h-4 text-amber-200 animate-pulse" />
                  Scraper & Convertir ce cours 🌐
                </button>
              </div>
            )}

            {/* TAB 3: COURSE PLUGINS LIBRARY */}
            {activeTab === 'plugins' && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-black text-stone-500 uppercase tracking-wider">Connexion aux Plateformes d'Enseignement</h4>
                  <p className="text-[10px] text-stone-400 leading-relaxed">
                    Accédez aux bases de données et catalogues de cours officiels de nos partenaires. Sélectionnez une leçon pour l'importer instantanément via notre scraper IA.
                  </p>
                </div>

                <div className="grid gap-3">
                  {COURSE_PLUGINS.map((plugin) => (
                    <div 
                      key={plugin.id} 
                      className="bg-white border border-stone-200/60 rounded-2xl overflow-hidden shadow-xs transition-all"
                    >
                      <button
                        onClick={() => setExpandedPlugin(expandedPlugin === plugin.id ? null : plugin.id)}
                        className="w-full p-4 flex items-center justify-between text-left hover:bg-stone-50/50 transition-all cursor-pointer"
                      >
                        <div className="flex gap-3 items-center">
                          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${plugin.logoColor} flex items-center justify-center text-white font-display font-black text-sm shadow-inner`}>
                            {plugin.name.charAt(0)}
                          </div>
                          <div>
                            <h5 className="text-xs font-bold text-stone-800">{plugin.name}</h5>
                            <p className="text-[10px] text-stone-400 mt-0.5 line-clamp-1">{plugin.description}</p>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold text-orange-600">
                          {expandedPlugin === plugin.id ? 'Masquer' : 'Voir cours'}
                        </span>
                      </button>

                      <AnimatePresence>
                        {expandedPlugin === plugin.id && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: 'auto' }}
                            exit={{ height: 0 }}
                            className="overflow-hidden border-t border-stone-100 bg-stone-50/50 px-4 py-2"
                          >
                            <div className="space-y-2 py-2">
                              {plugin.courses.map((course, cIdx) => (
                                <div 
                                  key={cIdx} 
                                  className="bg-white border border-stone-200/40 p-3 rounded-xl flex items-center justify-between shadow-2xs gap-4"
                                >
                                  <div className="space-y-1 flex-1">
                                    <div className="flex gap-1.5 items-center">
                                      <span className="text-[9px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded uppercase font-bold">{course.exam}</span>
                                      <span className="text-[9px] bg-stone-100 text-stone-500 px-1.5 py-0.5 rounded font-bold uppercase">{course.subject}</span>
                                    </div>
                                    <h6 className="text-xs font-bold text-stone-800 leading-snug">{course.title}</h6>
                                    <p className="text-[9px] text-stone-400 font-mono flex items-center gap-1">
                                      <Link2 className="w-3 h-3" />
                                      {course.url.substring(0, 45)}...
                                    </p>
                                  </div>
                                  
                                  <button
                                    onClick={() => handlePluginCourseImport(course)}
                                    className="bg-orange-600 hover:bg-orange-700 text-white font-bold text-[10px] px-3 py-2 rounded-lg shrink-0 flex items-center gap-1 shadow-xs hover:scale-105 transition-all cursor-pointer"
                                  >
                                    <DownloadIcon className="w-3 h-3" />
                                    Importer
                                  </button>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>

              </div>
            )}

          </div>
        )}

        </div>
      </>
    )}

    </div>
  );
}

// Minimal placeholder Download icon component to prevent compile errors
function DownloadIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" x2="12" y1="15" y2="3" />
    </svg>
  );
}
