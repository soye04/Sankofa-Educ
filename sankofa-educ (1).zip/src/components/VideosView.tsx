/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Search, Play, Youtube, Clock, Eye, AlertCircle, ChevronLeft, Settings, Moon, Sun, Bookmark, BookmarkCheck, Volume2, Maximize, FastForward, Sliders, FileText, Download, Copy, Check } from 'lucide-react';
import { VideoInfo } from '../types';

interface VideosViewProps {
  initialSearchKeywords?: string;
  onClearKeywords?: () => void;
}

const PRE_CURATED_VIDEOS: VideoInfo[] = [
  {
    id: 'Y3mK0_V6qC8',
    title: 'Théorème de Thalès - Cours de Géométrie 3ème (BEPC)',
    channelTitle: 'AlloSchool CI',
    duration: '12:45',
    viewCount: '15K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1453733190148-c44698c265a8?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'f8S6_N0qBv4',
    title: 'Solutions acides et basiques - Physique Chimie 3ème',
    channelTitle: 'Télé-Enseignement Côte d\'Ivoire',
    duration: '18:20',
    viewCount: '9.4K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'mL9S_B8xC2e',
    title: 'La fonction Logarithme Népérien : Limites et Dérivées - Terminale D',
    channelTitle: 'La Chaine Pédagogique',
    duration: '25:10',
    viewCount: '28K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'pZ4_X0mKe90',
    title: 'Cinétique Chimique : Facteurs cinétiques et Vitesses - Terminale C/D',
    channelTitle: 'Maths & Sciences FACILE',
    duration: '14:50',
    viewCount: '12K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'kL3_M1oPw55',
    title: 'Les Institutions de la République Ivoirienne - Éducation Civique',
    channelTitle: 'Concours CI Prépa',
    duration: '11:15',
    viewCount: '34K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'hT8_S1qAs22',
    title: 'Sujet Type BEPC Corrigé : Rédaction en Français',
    channelTitle: 'AlloSchool CI',
    duration: '22:30',
    viewCount: '8.1K vues',
    thumbnailUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  }
];

export default function VideosView({ initialSearchKeywords, onClearKeywords }: VideosViewProps) {
  const [searchQuery, setSearchQuery] = useState(initialSearchKeywords || '');
  const [activeVideo, setActiveVideo] = useState<VideoInfo | null>(null);
  const [searchMode, setSearchMode] = useState<'recommended' | 'live' | 'saved'>(initialSearchKeywords ? 'live' : 'recommended');
  const [liveVideos, setLiveVideos] = useState<VideoInfo[]>([]);
  const [isLoadingLive, setIsLoadingLive] = useState(false);
  const [errorLive, setErrorLive] = useState<string | null>(null);

  const [recommendedVideos, setRecommendedVideos] = useState<VideoInfo[]>([]);
  const [isLoadingRecommended, setIsLoadingRecommended] = useState(true);

  // Video Player Configuration States
  const [videoQuality, setVideoQuality] = useState<'small' | 'medium' | 'hd720' | 'auto'>('small'); // Default to 360p Data Saver for CI
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isAutoplay, setIsAutoplay] = useState<boolean>(true);
  const [isLoop, setIsLoop] = useState<boolean>(false);
  const [isCcEnabled, setIsCcEnabled] = useState<boolean>(false);
  const [isTheatreMode, setIsTheatreMode] = useState<boolean>(false);
  const [showSettingsDrawer, setShowSettingsDrawer] = useState<boolean>(false);

  // Bookmarks & Personal Revision Notes
  const [savedVideoIds, setSavedVideoIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('sankofa_saved_videos');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [currentNote, setCurrentNote] = useState<string>('');
  const [isNoteCopied, setIsNoteCopied] = useState<boolean>(false);

  // Load note when active video changes
  useEffect(() => {
    if (activeVideo) {
      try {
        const savedNotes = localStorage.getItem(`sankofa_video_note_${activeVideo.id}`);
        setCurrentNote(savedNotes || '');
      } catch (e) {
        setCurrentNote('');
      }
    }
  }, [activeVideo]);

  const handleSaveNote = (text: string) => {
    setCurrentNote(text);
    if (activeVideo) {
      try {
        localStorage.setItem(`sankofa_video_note_${activeVideo.id}`, text);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleToggleBookmark = (videoId: string) => {
    let updated: string[];
    if (savedVideoIds.includes(videoId)) {
      updated = savedVideoIds.filter(id => id !== videoId);
    } else {
      updated = [...savedVideoIds, videoId];
    }
    setSavedVideoIds(updated);
    try {
      localStorage.setItem('sankofa_saved_videos', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Compute list of bookmarked/saved videos
  const savedVideosList = useMemo(() => {
    const allKnown = [...recommendedVideos, ...liveVideos, ...PRE_CURATED_VIDEOS];
    const uniqueKnownMap = new Map<string, VideoInfo>();
    allKnown.forEach(v => uniqueKnownMap.set(v.id, v));
    return savedVideoIds.map(id => uniqueKnownMap.get(id)).filter((v): v is VideoInfo => !!v);
  }, [savedVideoIds, recommendedVideos, liveVideos]);
  useEffect(() => {
    const fetchRecommended = async () => {
      try {
        const res = await fetch('/api/videos');
        const data = await res.json();
        if (data.success && data.videos && data.videos.length > 0) {
          setRecommendedVideos(data.videos);
        } else {
          setRecommendedVideos(PRE_CURATED_VIDEOS);
        }
      } catch (err) {
        console.error('Error fetching videos from server:', err);
        setRecommendedVideos(PRE_CURATED_VIDEOS);
      } finally {
        setIsLoadingRecommended(false);
      }
    };
    fetchRecommended();
  }, []);

  // Filter video results
  const filteredVideos = useMemo(() => {
    if (searchQuery.trim() === '') {
      return recommendedVideos;
    }
    const query = searchQuery.toLowerCase();
    return recommendedVideos.filter(
      (v) =>
        v.title.toLowerCase().includes(query) ||
        v.channelTitle.toLowerCase().includes(query)
    );
  }, [searchQuery, recommendedVideos]);

  // If they switch to 'live' and liveVideos is empty, trigger search
  const triggerLiveSearch = async (queryToSearch: string) => {
    if (!queryToSearch.trim()) {
      setLiveVideos([]);
      return;
    }
    setIsLoadingLive(true);
    setErrorLive(null);
    try {
      const response = await fetch(`/api/youtube/search?q=${encodeURIComponent(queryToSearch)}`);
      const data = await response.json();
      if (data.success) {
        setLiveVideos(data.videos || []);
      } else {
        setErrorLive('Impossible de récupérer les vidéos de YouTube.');
      }
    } catch (err) {
      console.error(err);
      setErrorLive('Une erreur de connexion est survenue lors de la recherche.');
    } finally {
      setIsLoadingLive(false);
    }
  };

  // Debounced search for live YouTube videos
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setLiveVideos([]);
      return;
    }

    if (searchMode !== 'live') {
      return;
    }

    const delayDebounceFn = setTimeout(() => {
      triggerLiveSearch(searchQuery);
    }, 600); // 600ms debounce for smoother live typing

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery, searchMode]);

  // Initial trigger if keywords are passed from another screen
  useEffect(() => {
    if (initialSearchKeywords) {
      triggerLiveSearch(initialSearchKeywords);
    }
  }, [initialSearchKeywords]);

  // Computed Youtube Embed URL with configuration parameters
  const embedUrl = useMemo(() => {
    if (!activeVideo) return '';
    const isDirectFile = activeVideo.id.startsWith('http://') || activeVideo.id.startsWith('https://');
    if (isDirectFile) return activeVideo.id;

    const params = new URLSearchParams();
    params.set('autoplay', isAutoplay ? '1' : '0');
    params.set('playsinline', '1');
    if (isLoop) {
      params.set('loop', '1');
      params.set('playlist', activeVideo.id);
    }
    if (isCcEnabled) {
      params.set('cc_load_policy', '1');
      params.set('cc_lang_pref', 'fr');
    }
    if (videoQuality !== 'auto') {
      params.set('vq', videoQuality);
    }
    params.set('rel', '0');
    params.set('modestbranding', '1');
    params.set('enablejsapi', '1');

    return `https://www.youtube-nocookie.com/embed/${activeVideo.id}?${params.toString()}`;
  }, [activeVideo, isAutoplay, isLoop, isCcEnabled, videoQuality]);

  return (
    <div className={`flex flex-col h-full font-sans transition-colors duration-300 ${isTheatreMode && activeVideo ? 'bg-stone-950 text-white' : 'bg-[#fcfbf7] text-stone-900'}`}>
      
      {activeVideo ? (
        /* --- SUB-VIEW 1 : CONFIGURED VIDEO PLAYER SCREEN --- */
        <div className="flex flex-col h-full overflow-y-auto no-scrollbar">
          
          {/* Header navigation bar */}
          <div className={`p-4 border-b flex items-center justify-between shrink-0 ${isTheatreMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200/50'}`}>
            <div className="flex items-center gap-3 min-w-0">
              <button
                onClick={() => {
                  setActiveVideo(null);
                  setIsTheatreMode(false);
                  setShowSettingsDrawer(false);
                }}
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${isTheatreMode ? 'hover:bg-stone-800 text-stone-300' : 'hover:bg-stone-100 text-stone-600'}`}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <h4 className={`text-xs font-bold font-display line-clamp-1 ${isTheatreMode ? 'text-stone-100' : 'text-stone-800'}`}>
                Lecture : {activeVideo.title}
              </h4>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setIsTheatreMode(!isTheatreMode)}
                title={isTheatreMode ? 'Quitter le mode cinéma' : 'Mode Cinéma (Sombre)'}
                className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isTheatreMode ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {isTheatreMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-stone-700" />}
                <span className="hidden sm:inline">{isTheatreMode ? 'Lumineux' : 'Cinéma'}</span>
              </button>

              <button
                onClick={() => setShowSettingsDrawer(!showSettingsDrawer)}
                className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  showSettingsDrawer ? 'bg-orange-600 text-white' : isTheatreMode ? 'bg-stone-800 text-stone-200' : 'bg-orange-50 text-orange-600 border border-orange-200/60'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Configuration</span>
              </button>
            </div>
          </div>

          {/* Video Player Container */}
          <div className={`w-full relative flex items-center justify-center overflow-hidden shrink-0 shadow-xl transition-all ${
            isTheatreMode ? 'aspect-video bg-black max-h-[60vh]' : 'aspect-video bg-black'
          }`}>
            {activeVideo.id.startsWith('http://') || activeVideo.id.startsWith('https://') ? (
              <video
                src={activeVideo.id}
                controls
                autoPlay={isAutoplay}
                loop={isLoop}
                className="w-full h-full object-contain"
              />
            ) : (
              <iframe
                src={embedUrl}
                title={activeVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                allowFullScreen
                className="absolute inset-0 w-full h-full border-none z-10"
                referrerPolicy="no-referrer"
              />
            )}

            <div className="flex flex-col items-center justify-center p-6 text-center space-y-3 text-stone-500 z-0 select-none">
              <Youtube className="w-12 h-12 text-red-600" />
              <p className="text-xs">Chargement du lecteur vidéo Sankofa...</p>
            </div>
          </div>

          {/* QUICK CONFIGURATION BAR & ACTIONS */}
          <div className={`p-3 border-b flex items-center justify-between gap-2 text-xs font-medium overflow-x-auto no-scrollbar shrink-0 ${
            isTheatreMode ? 'bg-stone-900 border-stone-800 text-stone-300' : 'bg-white border-stone-200/50 text-stone-700'
          }`}>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSettingsDrawer(!showSettingsDrawer)}
                className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                  showSettingsDrawer 
                    ? 'bg-orange-600 text-white border-orange-600' 
                    : isTheatreMode ? 'bg-stone-800 border-stone-700 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-800 hover:bg-stone-100'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Régler le lecteur</span>
                <span className="text-[10px] bg-orange-500/20 text-orange-600 font-black px-1.5 py-0.5 rounded ml-1 uppercase">
                  {videoQuality === 'small' ? '360p Éco' : videoQuality === 'hd720' ? '720p HD' : videoQuality}
                </span>
              </button>

              <button
                onClick={() => handleToggleBookmark(activeVideo.id)}
                className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                  savedVideoIds.includes(activeVideo.id)
                    ? 'bg-amber-500 text-white border-amber-500'
                    : isTheatreMode ? 'bg-stone-800 border-stone-700 text-stone-200' : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                }`}
              >
                {savedVideoIds.includes(activeVideo.id) ? (
                  <>
                    <BookmarkCheck className="w-3.5 h-3.5 fill-current" />
                    <span>Mémorisée</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Sauvegarder</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center gap-2">
              {/* Playback speed quick buttons */}
              <div className={`flex items-center rounded-xl p-0.5 border ${isTheatreMode ? 'bg-stone-800 border-stone-700' : 'bg-stone-100 border-stone-200'}`}>
                {[1, 1.25, 1.5].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => setPlaybackSpeed(speed)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                      playbackSpeed === speed
                        ? 'bg-orange-600 text-white shadow-2xs'
                        : isTheatreMode ? 'text-stone-400 hover:text-stone-100' : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* EXPANDABLE SETTINGS DRAWER / CONFIGURATION MODAL */}
          {showSettingsDrawer && (
            <div className={`p-4 border-b space-y-4 shadow-inner ${
              isTheatreMode ? 'bg-stone-900 border-stone-800 text-stone-200' : 'bg-orange-50/50 border-orange-200/60 text-stone-800'
            }`}>
              <div className="flex items-center justify-between border-b border-orange-200/40 pb-2">
                <h4 className="text-xs font-black font-display uppercase tracking-wider flex items-center gap-1.5 text-orange-600">
                  <Settings className="w-4 h-4" />
                  Configuration Avancée du Lecteur Vidéo
                </h4>
                <button
                  onClick={() => setShowSettingsDrawer(false)}
                  className="text-xs text-stone-400 hover:text-stone-600 font-bold cursor-pointer"
                >
                  Fermer ✕
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Option 1: Quality / Data Saver */}
                <div className="space-y-1.5">
                  <label className="font-bold flex items-center gap-1.5 text-stone-700">
                    📶 Qualité & Économie de Data Mobile :
                  </label>
                  <select
                    value={videoQuality}
                    onChange={(e) => setVideoQuality(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl font-bold text-stone-800 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-2xs cursor-pointer"
                  >
                    <option value="small">360p (Mode Économie Data Orange/MTN/Moov ⚡)</option>
                    <option value="medium">480p (Standard SD)</option>
                    <option value="hd720">720p (Haute Définition HD 🎬)</option>
                    <option value="auto">Automatique (Qualité Réseau)</option>
                  </select>
                  <p className="text-[10px] text-stone-500">
                    Le mode 360p réduit la consommation de vos Mo de pass internet pendant vos révisions.
                  </p>
                </div>

                {/* Option 2: Playback Speed */}
                <div className="space-y-1.5">
                  <label className="font-bold flex items-center gap-1.5 text-stone-700">
                    ⚡ Vitesse de Lecture du Cours :
                  </label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {[0.75, 1, 1.25, 1.5, 2].map((sp) => (
                      <button
                        key={sp}
                        type="button"
                        onClick={() => setPlaybackSpeed(sp)}
                        className={`py-2 rounded-xl text-xs font-black transition-all cursor-pointer border ${
                          playbackSpeed === sp
                            ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                            : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        {sp}x
                      </button>
                    ))}
                  </div>
                </div>

                {/* Option 3: Autoplay & Loop */}
                <div className="space-y-2">
                  <label className="font-bold text-stone-700">🔄 Mode de Lecture :</label>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer font-medium">
                      <input
                        type="checkbox"
                        checked={isAutoplay}
                        onChange={(e) => setIsAutoplay(e.target.checked)}
                        className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500 cursor-pointer"
                      />
                      <span>Lecture auto</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer font-medium">
                      <input
                        type="checkbox"
                        checked={isLoop}
                        onChange={(e) => setIsLoop(e.target.checked)}
                        className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500 cursor-pointer"
                      />
                      <span>Répéter en boucle</span>
                    </label>
                  </div>
                </div>

                {/* Option 4: Subtitles CC */}
                <div className="space-y-2">
                  <label className="font-bold text-stone-700">💬 Sous-Titres / Transcript :</label>
                  <label className="flex items-center gap-2 cursor-pointer font-medium">
                    <input
                      type="checkbox"
                      checked={isCcEnabled}
                      onChange={(e) => setIsCcEnabled(e.target.checked)}
                      className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500 cursor-pointer"
                    />
                    <span>Forcer les sous-titres en Français</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Video Metadata & Student Revision Notes Panel */}
          <div className="p-5 space-y-5">
            <div className="space-y-2">
              <h3 className={`font-display font-bold text-sm leading-snug ${isTheatreMode ? 'text-white' : 'text-stone-950'}`}>
                {activeVideo.title}
              </h3>
              
              <div className="flex items-center gap-3 text-[10px] text-stone-500 font-medium">
                <span className="text-red-600 font-bold uppercase tracking-wider">{activeVideo.channelTitle}</span>
                <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {activeVideo.viewCount}</span>
                <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {activeVideo.duration}</span>
              </div>
            </div>

            {/* DATA CONSUMPTION TIP */}
            <div className={`p-4 rounded-2xl flex gap-3 leading-relaxed text-xs border ${
              isTheatreMode ? 'bg-stone-900 border-stone-800 text-stone-300' : 'bg-amber-50 border-amber-200/50 text-amber-950'
            }`}>
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <strong className="font-bold text-amber-900 dark:text-amber-400 block">Astuce Économie Data Mobile 📶</strong>
                <span>
                  Qualité configurée : <strong>{videoQuality === 'small' ? '360p (Mode Éco)' : videoQuality}</strong>. Vous pouvez modifier la vitesse (ex: 1.25x) et la qualité dans le menu <strong>Configuration</strong> pour réviser plus vite sans épuiser votre crédit internet.
                </span>
              </div>
            </div>

            {/* STUDENT REVISION NOTEBOOK SECTION */}
            <div className={`p-4 rounded-2xl border space-y-3 ${
              isTheatreMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200/60 shadow-xs'
            }`}>
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black font-display uppercase tracking-wider flex items-center gap-1.5 text-orange-600">
                  <FileText className="w-4 h-4" />
                  Carnet de Notes du Cours Vidéo
                </h4>

                {currentNote.trim() && (
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(currentNote);
                      setIsNoteCopied(true);
                      setTimeout(() => setIsNoteCopied(false), 2000);
                    }}
                    className="text-[11px] font-bold text-orange-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {isNoteCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{isNoteCopied ? 'Copié !' : 'Copier mes notes'}</span>
                  </button>
                )}
              </div>

              <textarea
                value={currentNote}
                onChange={(e) => handleSaveNote(e.target.value)}
                placeholder="Prenez des notes importantes pendant la vidéo (ex: formules de Thalès, définitions, étapes de démonstration)..."
                rows={3}
                className={`w-full p-3 rounded-xl text-xs font-sans focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all ${
                  isTheatreMode ? 'bg-stone-950 border-stone-800 text-stone-200 placeholder-stone-600' : 'bg-stone-50 border-stone-200 text-stone-800 placeholder-stone-400'
                }`}
              />
              <p className="text-[10px] text-stone-400 text-right">
                Vos notes sont sauvegardées automatiquement sur votre appareil.
              </p>
            </div>

            <button
              onClick={() => {
                setActiveVideo(null);
                setIsTheatreMode(false);
              }}
              className="w-full py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all text-center cursor-pointer"
            >
              Retourner à la liste des vidéos
            </button>
          </div>

        </div>
      ) : (
        /* --- SUB-VIEW 2 : SEARCH AND DISCOVERY LIST --- */
        <div className="flex flex-col h-full">
          
          {/* Keywords search filter bar */}
          <div className="p-4 bg-white border-b border-stone-200/50 space-y-3 shrink-0 shadow-xs">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="Rechercher des leçons vidéo..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white transition-all font-sans"
              />
            </div>

            {/* Mode selection tabs */}
            <div className="flex border border-stone-200/60 bg-stone-50 p-1 rounded-xl gap-1">
              <button
                onClick={() => setSearchMode('recommended')}
                className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  searchMode === 'recommended'
                    ? 'bg-white text-stone-900 shadow-xs border border-stone-200/40'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                Cours 🇨🇮
              </button>

              <button
                onClick={() => {
                  setSearchMode('live');
                  if (liveVideos.length === 0 && searchQuery.trim() !== '') {
                    triggerLiveSearch(searchQuery);
                  }
                }}
                className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  searchMode === 'live'
                    ? 'bg-white text-orange-600 shadow-xs border border-stone-200/40'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse"></span>
                En Direct 🌐
              </button>

              <button
                onClick={() => setSearchMode('saved')}
                className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
                  searchMode === 'saved'
                    ? 'bg-amber-500 text-white shadow-xs border border-amber-500'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>Sauvegardes ({savedVideoIds.length})</span>
              </button>
            </div>

            {/* Keyword clear reset tag banner */}
            {initialSearchKeywords && (
              <div className="flex justify-between items-center bg-orange-500/10 border border-orange-500/10 px-3 py-1.5 rounded-lg text-xs">
                <span className="text-orange-800 text-[11px]">
                  Filtre IA : <strong className="font-bold">"{initialSearchKeywords}"</strong>
                </span>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    if (onClearKeywords) onClearKeywords();
                  }}
                  className="text-[10px] font-bold text-orange-600 hover:underline"
                >
                  Effacer le filtre
                </button>
              </div>
            )}
          </div>

          {/* Videos Grid list container */}
          <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
            
            {searchMode === 'saved' ? (
              // Saved Videos View
              savedVideosList.length > 0 ? (
                savedVideosList.map((video) => (
                  <div
                    key={video.id}
                    onClick={() => setActiveVideo(video)}
                    className="bg-white border border-stone-200/60 rounded-2xl overflow-hidden shadow-xs hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group flex flex-col relative"
                  >
                    {/* Thumbnail display area with overlay */}
                    <div className="relative aspect-video bg-stone-800 w-full overflow-hidden">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300 opacity-90"
                        referrerPolicy="no-referrer"
                      />
                      
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-all flex items-center justify-center">
                        <div className="w-11 h-11 bg-amber-500/90 text-white rounded-full flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-all backdrop-blur-xs">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 bg-stone-950/80 text-white text-[10px] font-mono rounded font-bold backdrop-blur-xs">
                        {video.duration}
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleBookmark(video.id);
                        }}
                        className="absolute top-2.5 right-2.5 p-1.5 bg-amber-500 text-white rounded-lg shadow-md hover:scale-110 transition-all cursor-pointer"
                        title="Retirer des sauvegardes"
                      >
                        <BookmarkCheck className="w-4 h-4 fill-current" />
                      </button>
                    </div>

                    {/* Description segment */}
                    <div className="p-3.5 space-y-1.5 min-w-0">
                      <div className="flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest text-amber-600">
                        <Bookmark className="w-3.5 h-3.5 fill-current" />
                        <span>Mémorisée</span>
                        <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                        <span className="text-stone-500 font-medium normal-case flex items-center gap-1">{video.channelTitle}</span>
                      </div>
                      
                      <h4 className="text-stone-900 font-display font-bold text-xs leading-snug line-clamp-2">
                        {video.title}
                      </h4>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                  <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto">
                    <Bookmark className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-display font-bold text-stone-800">Aucune vidéo sauvegardée</h4>
                    <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed mb-4">
                      Vous n'avez pas encore mémorisé de vidéos. Cliquez sur le bouton "Sauvegarder 🔖" sous n'importe quelle vidéo pour la retrouver ici facilement !
                    </p>
                    <button
                      onClick={() => setSearchMode('recommended')}
                      className="px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5"
                    >
                      Explorer les cours vidéo
                    </button>
                  </div>
                </div>
              )
            ) : searchMode === 'live' ? (
              // Live YouTube Search View
              isLoadingLive ? (
                <div className="flex flex-col items-center justify-center py-20 space-y-4">
                  <div className="w-10 h-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-xs text-stone-500 font-medium">Recherche de cours en direct sur YouTube...</p>
                </div>
              ) : errorLive ? (
                <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                  <div className="w-12 h-12 bg-red-100/60 text-red-600 rounded-full flex items-center justify-center mx-auto">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-display font-bold text-stone-800">Erreur de chargement</h4>
                    <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                      {errorLive}
                    </p>
                    <button
                      onClick={() => triggerLiveSearch(searchQuery)}
                      className="mt-4 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl transition-all"
                    >
                      Réessayer la recherche
                    </button>
                  </div>
                </div>
              ) : searchQuery.trim() === '' ? (
                <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                  <div className="w-12 h-12 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center mx-auto">
                    <Search className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-display font-bold text-stone-800">Prêt pour la recherche</h4>
                    <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                      Saisissez vos mots-clés de révision ci-dessus (ex: "bac philosophie", "cours thales 3eme") pour chercher sur YouTube en temps réel !
                    </p>
                  </div>
                </div>
              ) : liveVideos.length > 0 ? (
                liveVideos.map((video) => (
                  <div
                    key={video.id}
                    onClick={() => setActiveVideo(video)}
                    className="bg-white border border-stone-200/60 rounded-2xl overflow-hidden shadow-xs hover:shadow-md hover:border-orange-200 transition-all cursor-pointer group flex flex-col"
                  >
                    {/* Thumbnail display area with overlay */}
                    <div className="relative aspect-video bg-stone-800 w-full overflow-hidden">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300 opacity-90"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Floating play action and duration tags */}
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-all flex items-center justify-center">
                        <div className="w-11 h-11 bg-orange-600/90 text-white rounded-full flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-all backdrop-blur-xs">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 bg-stone-950/80 text-white text-[10px] font-mono rounded font-bold backdrop-blur-xs">
                        {video.duration}
                      </span>
                    </div>

                    {/* Description segment */}
                    <div className="p-3.5 space-y-1.5 min-w-0">
                      <div className="flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest text-red-600">
                        <Youtube className="w-3.5 h-3.5 fill-current" />
                        <span>{video.channelTitle}</span>
                        <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                        <span className="text-stone-500 font-medium normal-case flex items-center gap-1"><Eye className="w-3 h-3" /> {video.viewCount}</span>
                      </div>
                      
                      <h4 className="text-stone-900 font-display font-bold text-xs leading-snug line-clamp-2">
                        {video.title}
                      </h4>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                  <div className="w-12 h-12 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto">
                    <Youtube className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-display font-bold text-stone-800">Aucun résultat en direct</h4>
                    <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                      Aucun cours vidéo trouvé en direct sur YouTube pour "{searchQuery}". Essayez avec d'autres mots-clés de révision simples.
                    </p>
                  </div>
                </div>
              )
            ) : (
              // Recommended curated local videos View
              isLoadingRecommended ? (
                <div className="flex flex-col items-center justify-center py-20 space-y-4">
                  <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-xs text-stone-500 font-medium">Chargement des cours recommandés...</p>
                </div>
              ) : filteredVideos.length > 0 ? (
                filteredVideos.map((video) => (
                  <div
                    key={video.id}
                    onClick={() => setActiveVideo(video)}
                    className="bg-white border border-stone-200/60 rounded-2xl overflow-hidden shadow-xs hover:shadow-md hover:border-orange-200 transition-all cursor-pointer group flex flex-col"
                  >
                    {/* Thumbnail display area with overlay */}
                    <div className="relative aspect-video bg-stone-800 w-full overflow-hidden">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300 opacity-90"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Floating play action and duration tags */}
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-all flex items-center justify-center">
                        <div className="w-11 h-11 bg-orange-600/90 text-white rounded-full flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-all backdrop-blur-xs">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                      </div>

                      <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 bg-stone-950/80 text-white text-[10px] font-mono rounded font-bold backdrop-blur-xs">
                        {video.duration}
                      </span>
                    </div>

                    {/* Description segment */}
                    <div className="p-3.5 space-y-1.5 min-w-0">
                      <div className="flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest text-red-600">
                        <Youtube className="w-3.5 h-3.5 fill-current" />
                        <span>{video.channelTitle}</span>
                        <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                        <span className="text-stone-500 font-medium normal-case flex items-center gap-1"><Eye className="w-3 h-3" /> {video.viewCount}</span>
                      </div>
                      
                      <h4 className="text-stone-900 font-display font-bold text-xs leading-snug line-clamp-2">
                        {video.title}
                      </h4>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                  <div className="w-12 h-12 bg-red-100/60 text-red-600 rounded-full flex items-center justify-center mx-auto">
                    <Youtube className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-display font-bold text-stone-800">Aucune vidéo recommandée</h4>
                    <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed mb-4">
                      Notre sélection de cours ivoiriens n'a pas de vidéo recommandée avec ces mots-clés.
                    </p>
                    <button
                      onClick={() => {
                        setSearchMode('live');
                        triggerLiveSearch(searchQuery);
                      }}
                      className="px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5" />
                      Chercher en direct sur YouTube 🌐
                    </button>
                  </div>
                </div>
              )
            )}

          </div>
        </div>
      )}

    </div>
  );
}
