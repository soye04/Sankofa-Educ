/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Search, Star, Download, CheckCircle2, ChevronLeft, ArrowRight, Play, BookOpen, Clock, Layers, Sparkles, ExternalLink, Cpu, Globe, RefreshCw, AlertCircle, Pause, RotateCcw, Brain, BellOff, Timer } from 'lucide-react';
import { RevisionSheet, ExamType, Quiz } from '../types';

interface RevisionSheetsProps {
  sheets: RevisionSheet[];
  quizzes: Quiz[];
  favorites: string[];
  downloads: string[];
  completedSheets: string[];
  targetExam: ExamType;
  userSeries: string;
  isPremium: boolean;
  onToggleFavorite: (id: string) => void;
  onToggleDownload: (id: string) => void;
  onMarkAsRead: (id: string) => void;
  onLaunchQuiz: (quizId: string) => void;
  onLaunchVideoSearch: (keywords: string) => void;
  onRefreshData?: () => void;
  onChangeSeries?: (series: string) => void;
  isFocusActive?: boolean;
  onToggleFocusMode?: (active: boolean) => void;
  isOffline?: boolean;
}

export default function RevisionSheets({
  sheets,
  quizzes,
  favorites,
  downloads,
  completedSheets,
  targetExam,
  userSeries,
  isPremium,
  onToggleFavorite,
  onToggleDownload,
  onMarkAsRead,
  onLaunchQuiz,
  onLaunchVideoSearch,
  onRefreshData,
  onChangeSeries,
  isFocusActive = false,
  onToggleFocusMode,
  isOffline = false
}: RevisionSheetsProps) {
  // Filters states
  const [selectedExam, setSelectedExam] = useState<ExamType>(targetExam);
  const [selectedSeries, setSelectedSeries] = useState<string>(userSeries || 'D');
  const [selectedSubject, setSelectedSubject] = useState<string>('Tous');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFavorites, setFilterFavorites] = useState(false);
  const [filterOffline, setFilterOffline] = useState(false);

  // Sync selectedSeries if userSeries changes
  React.useEffect(() => {
    if (userSeries) {
      setSelectedSeries(userSeries);
    }
  }, [userSeries]);

  // Helper to determine if a resource belongs to the current user's series
  const isResourceInSeries = (
    exam: ExamType,
    subject: string,
    title: string,
    seriesList?: string[]
  ): boolean => {
    if (exam !== 'BAC') return true;
    if (seriesList && seriesList.length > 0) {
      return seriesList.includes(selectedSeries);
    }
    const titleLower = title.toLowerCase();
    const subjLower = subject.toLowerCase();

    if (selectedSeries === 'A') {
      if (subjLower.includes('physique') || subjLower.includes('chimie')) return false;
      if (titleLower.includes('terminale d') || titleLower.includes('terminale c') || titleLower.includes('terminale s')) {
        if (!titleLower.includes('terminale a')) return false;
      }
      return true;
    }
    if (selectedSeries === 'C') {
      if (titleLower.includes('terminale d') && !titleLower.includes('terminale c') && !titleLower.includes('terminale s')) {
        return false;
      }
      return true;
    }
    if (selectedSeries === 'D') {
      if (titleLower.includes('terminale c') && !titleLower.includes('terminale d') && !titleLower.includes('terminale s')) {
        return false;
      }
      return true;
    }
    return true;
  };
  
  // Detail sheet state
  const [activeSheet, setActiveSheet] = useState<RevisionSheet | null>(null);

  // Focus & Pomodoro states
  const [localFocusActive, setLocalFocusActive] = useState(false);
  const [pomoMode, setPomoMode] = useState<'work' | 'shortBreak' | 'longBreak'>('work');
  const [pomoMinutes, setPomoMinutes] = useState(25);
  const [pomoSeconds, setPomoSeconds] = useState(0);
  const [pomoRunning, setPomoRunning] = useState(false);
  const [pomoCompletedCount, setPomoCompletedCount] = useState(0);
  const [bonusClaimed, setBonusClaimed] = useState(false);

  // Sync Focus mode with global app state when activeSheet changes or when localFocusActive changes
  React.useEffect(() => {
    if (onToggleFocusMode) {
      onToggleFocusMode(localFocusActive && activeSheet !== null);
    }
  }, [localFocusActive, activeSheet, onToggleFocusMode]);

  // Turn off focus mode automatically if the user exits the sheet detail view
  React.useEffect(() => {
    if (!activeSheet) {
      setLocalFocusActive(false);
      setPomoRunning(false);
    }
  }, [activeSheet]);

  const playFocusSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playTone = (freq: number, start: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(freq, start);
        osc.type = 'sine';
        gainNode.gain.setValueAtTime(0.35, start);
        gainNode.gain.exponentialRampToValueAtTime(0.001, start + duration);
        osc.start(start);
        osc.stop(start + duration);
      };
      const now = audioCtx.currentTime;
      // Beautiful triple rising chime
      playTone(523.25, now, 0.25); // C5
      playTone(659.25, now + 0.15, 0.25); // E5
      playTone(783.99, now + 0.3, 0.4); // G5
    } catch (err) {
      console.log("Audio context is blocked or not supported", err);
    }
  };

  // Handle countdown interval
  React.useEffect(() => {
    let interval: any = null;
    
    if (pomoRunning) {
      interval = setInterval(() => {
        if (pomoSeconds > 0) {
          setPomoSeconds((prev) => prev - 1);
        } else if (pomoSeconds === 0) {
          if (pomoMinutes > 0) {
            setPomoMinutes((prev) => prev - 1);
            setPomoSeconds(59);
          } else {
            // Timer finished!
            setPomoRunning(false);
            playFocusSound();
            setPomoCompletedCount((prev) => prev + 1);
            setBonusClaimed(false);
            
            // Mark revision card as read when the Work session completes!
            if (pomoMode === 'work' && activeSheet) {
              onMarkAsRead(activeSheet.id);
            }
          }
        }
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [pomoRunning, pomoMinutes, pomoSeconds, pomoMode, activeSheet, onMarkAsRead]);

  const handleSetPomoMode = (mode: 'work' | 'shortBreak' | 'longBreak') => {
    setPomoMode(mode);
    setPomoRunning(false);
    setPomoSeconds(0);
    if (mode === 'work') setPomoMinutes(25);
    else if (mode === 'shortBreak') setPomoMinutes(5);
    else if (mode === 'longBreak') setPomoMinutes(15);
  };

  const adjustMinutes = (amount: number) => {
    setPomoMinutes((prev) => {
      const next = prev + amount;
      return next > 0 ? next : 1; // Minimum 1 minute
    });
  };

  // No Fomesoutra scraper state

  // Available subjects based on selected exam
  const availableSubjects = useMemo(() => {
    const list = new Set<string>();
    sheets
      .filter((s) => s.exam === selectedExam)
      .forEach((s) => list.add(s.subject));
    return ['Tous', ...Array.from(list)];
  }, [sheets, selectedExam]);

  // Handle changes in exam filter - reset subject
  const handleExamChange = (exam: ExamType) => {
    setSelectedExam(exam);
    setSelectedSubject('Tous');
  };

  // Filter sheets
  const filteredSheets = useMemo(() => {
    return sheets.filter((sheet) => {
      // 1. Exam filter
      if (sheet.exam !== selectedExam) return false;

      // 1.5 Series filter
      if (!isResourceInSeries(sheet.exam, sheet.subject, sheet.title, sheet.series)) return false;
      
      // 2. Subject filter
      if (selectedSubject !== 'Tous' && sheet.subject !== selectedSubject) return false;
      
      // 3. Favorites toggle
      if (filterFavorites && !favorites.includes(sheet.id)) return false;
      
      // 4. Offline toggle
      if (filterOffline && !downloads.includes(sheet.id)) return false;
      
      // 5. Search text query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const inTitle = sheet.title.toLowerCase().includes(query);
        const inSummary = sheet.summary.toLowerCase().includes(query);
        const inChapter = sheet.chapter.toLowerCase().includes(query);
        const inContent = sheet.content.toLowerCase().includes(query);
        return inTitle || inSummary || inChapter || inContent;
      }
      
      return true;
    });
  }, [sheets, selectedExam, selectedSeries, selectedSubject, filterFavorites, filterOffline, searchQuery, favorites, downloads]);

  // No Fomesoutra filtered resources

  // Custom Formatter for Markdown content
  const renderFormattedContent = (content: string) => {
    return content.split('\n').map((line, i) => {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('###')) {
        return (
          <h4 key={i} className="text-base font-display font-bold text-stone-900 mt-6 mb-2 flex items-center gap-2 border-b border-stone-100 pb-1">
            <span className="w-1.5 h-4 bg-orange-500 rounded-full"></span>
            {trimmed.replace('###', '').trim()}
          </h4>
        );
      }
      
      if (trimmed.startsWith('##')) {
        return (
          <h3 key={i} className="text-lg font-display font-bold text-stone-900 mt-7 mb-3 border-l-4 border-amber-500 pl-2">
            {trimmed.replace('##', '').trim()}
          </h3>
        );
      }
      
      if (trimmed.startsWith('*')) {
        const textPart = trimmed.replace('*', '').trim();
        const isBoldPart = textPart.split(':');
        
        if (isBoldPart.length > 1) {
          return (
            <li key={i} className="ml-4 list-disc text-stone-700 text-sm mb-1.5 leading-relaxed">
              <strong className="text-stone-900">{isBoldPart[0]}:</strong>
              {isBoldPart.slice(1).join(':')}
            </li>
          );
        }
        return (
          <li key={i} className="ml-4 list-disc text-stone-700 text-sm mb-1.5 leading-relaxed">
            {textPart}
          </li>
        );
      }
      
      if (trimmed.startsWith('$$') && trimmed.endsWith('$$')) {
        const math = trimmed.slice(2, -2);
        return (
          <div key={i} className="my-4 p-3 bg-stone-50 border border-stone-200/50 rounded-xl overflow-x-auto font-mono text-xs text-center text-orange-700 font-bold shadow-inner">
            {math}
          </div>
        );
      }

      if (trimmed === '') return <div key={i} className="h-2"></div>;

      return (
        <p key={i} className="text-stone-700 text-sm leading-relaxed mb-3">
          {trimmed}
        </p>
      );
    });
  };

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7]">
      {activeSheet ? (
        /* --- VIEW 1 : SHEET DETAIL VIEW --- */
        <div className="flex flex-col h-full overflow-y-auto no-scrollbar">
          
          {/* Banner Image */}
          <div className="relative h-44 w-full bg-stone-800 shrink-0">
            <img
              src={activeSheet.illustrationUrl || 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'}
              alt={activeSheet.title}
              className="w-full h-full object-cover opacity-60"
            />
            {/* Header control buttons */}
            <div className="absolute inset-x-0 top-0 p-4 flex justify-between items-center bg-gradient-to-b from-black/60 to-transparent">
              <button
                onClick={() => {
                  onMarkAsRead(activeSheet.id); // auto update reading progress
                  setActiveSheet(null);
                }}
                className="w-9 h-9 bg-stone-900/60 hover:bg-stone-900 text-white rounded-full flex items-center justify-center transition-all backdrop-blur-sm"
              >
                <ChevronLeft className="w-5 h-5 mr-0.5" />
              </button>
              
              <div className="flex gap-2">
                {/* Download / Offline Toggle */}
                <button
                  onClick={() => onToggleDownload(activeSheet.id)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all backdrop-blur-sm ${
                    downloads.includes(activeSheet.id)
                      ? 'bg-orange-500 text-white'
                      : 'bg-stone-900/60 hover:bg-stone-900 text-white'
                  }`}
                  title="Télécharger pour lire hors-ligne"
                >
                  <Download className="w-4 h-4" />
                </button>
                
                {/* Favorite Toggle */}
                <button
                  onClick={() => onToggleFavorite(activeSheet.id)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all backdrop-blur-sm ${
                    favorites.includes(activeSheet.id)
                      ? 'bg-amber-500 text-stone-950'
                      : 'bg-stone-900/60 hover:bg-stone-900 text-white'
                  }`}
                >
                  <Star className={`w-4 h-4 ${favorites.includes(activeSheet.id) ? 'fill-current' : ''}`} />
                </button>

                {/* Mode Focus Toggle */}
                <button
                  onClick={() => setLocalFocusActive(!localFocusActive)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-all backdrop-blur-sm ${
                    localFocusActive
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-stone-900/60 hover:bg-stone-900 text-white'
                  }`}
                  title={localFocusActive ? "Désactiver le Mode Focus" : "Activer le Mode Focus"}
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Title & tags on image overlay */}
            <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-stone-950 to-transparent flex flex-col justify-end">
              <div className="flex gap-1.5 items-center mb-1">
                <span className="px-2 py-0.5 bg-orange-600 text-white font-black text-[10px] rounded-md tracking-wider">
                  {activeSheet.exam}
                </span>
                <span className="px-2 py-0.5 bg-white/20 text-white text-[10px] rounded-md backdrop-blur-sm font-semibold">
                  {activeSheet.subject}
                </span>
              </div>
              <h3 className="text-white text-lg font-display font-bold leading-tight">
                {activeSheet.title}
              </h3>
            </div>
          </div>

          {/* Core sheet elements */}
          {isOffline && !downloads.includes(activeSheet.id) ? (
            <div className="p-8 flex-1 flex flex-col items-center justify-center text-center space-y-4 bg-stone-50">
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center text-amber-600 animate-bounce">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="space-y-2 max-w-sm">
                <h4 className="text-base font-display font-bold text-stone-900">
                  Fiche non disponible hors-ligne 📡
                </h4>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Vous n'avez pas encore téléchargé cette fiche sur votre appareil. Connectez-vous à Internet pour la télécharger et pouvoir la consulter à tout moment, même sans connexion !
                </p>
              </div>
              <button
                onClick={() => setActiveSheet(null)}
                className="px-5 py-2.5 bg-[#3c2518] hover:bg-[#2b1a11] text-amber-400 font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
              >
                Retour aux fiches
              </button>
            </div>
          ) : (
            <div className="p-5 flex-1 space-y-6">
            
            {/* FOCUS MODE AND POMODORO TIMER PANEL */}
            {localFocusActive ? (
              <div className="bg-stone-900 text-stone-100 p-5 rounded-3xl space-y-4 shadow-xl border border-stone-800/80 transition-all duration-300 relative overflow-hidden">
                {/* Background decorative pulsing blur */}
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl animate-pulse" />
                
                <div className="flex justify-between items-center relative z-10">
                  <div className="flex items-center gap-2">
                    <span className="flex h-2.5 w-2.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                    </span>
                    <div>
                      <h4 className="text-xs font-display font-black uppercase tracking-wider text-stone-200">Mode Focus Actif</h4>
                      <p className="text-[10px] text-stone-400 font-medium font-sans">Notifications désactivées • Concentration max</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setLocalFocusActive(false);
                      setPomoRunning(false);
                    }}
                    className="text-[10px] bg-stone-800 hover:bg-stone-700 px-2.5 py-1 rounded-lg font-bold text-stone-300 transition-all border border-stone-700/60"
                  >
                    Quitter
                  </button>
                </div>

                {/* Pomodoro presets selection bar */}
                <div className="grid grid-cols-3 gap-1 bg-stone-950 p-1 rounded-xl text-[10px] relative z-10">
                  <button
                    onClick={() => handleSetPomoMode('work')}
                    className={`py-1.5 rounded-lg font-extrabold transition-all ${
                      pomoMode === 'work'
                        ? 'bg-orange-600 text-white shadow-xs'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Travail (25m)
                  </button>
                  <button
                    onClick={() => handleSetPomoMode('shortBreak')}
                    className={`py-1.5 rounded-lg font-extrabold transition-all ${
                      pomoMode === 'shortBreak'
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Pause (5m)
                  </button>
                  <button
                    onClick={() => handleSetPomoMode('longBreak')}
                    className={`py-1.5 rounded-lg font-extrabold transition-all ${
                      pomoMode === 'longBreak'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-stone-400 hover:text-stone-200'
                    }`}
                  >
                    Repos (15m)
                  </button>
                </div>

                {/* Main countdown block & adjustment controls */}
                <div className="flex flex-col items-center justify-center py-2 relative z-10">
                  <div className="flex items-center gap-6">
                    {/* Decrease Time */}
                    <button
                      onClick={() => adjustMinutes(-1)}
                      className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 border border-stone-700 flex items-center justify-center text-stone-300 font-bold text-sm transition-all"
                      title="Diminuer d'une minute"
                      disabled={pomoRunning}
                    >
                      -
                    </button>

                    {/* Numeric Display */}
                    <div className="text-4xl font-mono font-black tracking-widest text-white drop-shadow-sm flex items-center">
                      <span>{String(pomoMinutes).padStart(2, '0')}</span>
                      <span className="animate-pulse mx-1">:</span>
                      <span>{String(pomoSeconds).padStart(2, '0')}</span>
                    </div>

                    {/* Increase Time */}
                    <button
                      onClick={() => adjustMinutes(1)}
                      className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 border border-stone-700 flex items-center justify-center text-stone-300 font-bold text-sm transition-all"
                      title="Augmenter d'une minute"
                      disabled={pomoRunning}
                    >
                      +
                    </button>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full max-w-[200px] h-1.5 bg-stone-800 rounded-full mt-4 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-1000 ${
                        pomoMode === 'work' ? 'bg-orange-500' : pomoMode === 'shortBreak' ? 'bg-teal-500' : 'bg-blue-500'
                      }`}
                      style={{
                        width: `${
                          ((pomoMinutes * 60 + pomoSeconds) /
                            ((pomoMode === 'work' ? 25 : pomoMode === 'shortBreak' ? 5 : 15) * 60)) *
                          100
                        }%`,
                      }}
                    />
                  </div>
                </div>

                {/* Control Actions (Start, Pause, Reset) */}
                <div className="flex justify-center gap-2 relative z-10">
                  <button
                    onClick={() => setPomoRunning(!pomoRunning)}
                    className={`flex items-center gap-1.5 px-6 py-2 rounded-xl text-xs font-black transition-all ${
                      pomoRunning
                        ? 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                        : 'bg-white hover:bg-stone-100 text-stone-950'
                    }`}
                  >
                    {pomoRunning ? (
                      <>
                        <Pause className="w-3.5 h-3.5 fill-current" />
                        <span>Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Démarrer</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setPomoRunning(false);
                      setPomoSeconds(0);
                      if (pomoMode === 'work') setPomoMinutes(25);
                      else if (pomoMode === 'shortBreak') setPomoMinutes(5);
                      else if (pomoMode === 'longBreak') setPomoMinutes(15);
                    }}
                    className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 flex items-center justify-center text-stone-300 transition-all"
                    title="Réinitialiser"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Cycle completed & distraction-free callout */}
                <div className="bg-stone-950/50 border border-stone-800 p-3 rounded-2xl flex items-center gap-2.5 text-[10px] text-stone-400 relative z-10">
                  <BellOff className="w-4 h-4 text-orange-500 shrink-0" />
                  <div className="flex-1 leading-tight font-sans">
                    <strong className="text-stone-200 block font-bold">Concentration active : sans distractions</strong>
                    <span>Les bulletins scolaires et alertes sont coupés. {pomoCompletedCount > 0 && `Sessions complétées : ${pomoCompletedCount}`}</span>
                  </div>
                  {pomoCompletedCount > 0 && !bonusClaimed && (
                    <button
                      onClick={() => {
                        setBonusClaimed(true);
                        alert("Félicitations ! Vous gagnez +100 XP de concentration ! 🧠🚀");
                      }}
                      className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-lg transition-all shrink-0 font-sans"
                    >
                      +100 XP
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Non-active state focus callout */
              <div className="bg-gradient-to-r from-stone-900 to-stone-800 text-white p-4 rounded-3xl flex items-center justify-between shadow-md border border-stone-700/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-orange-600/10 border border-orange-500/20 flex items-center justify-center text-orange-400 animate-pulse">
                    <Brain className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-display font-black tracking-tight text-stone-100">Prêt pour une session de révision ?</h4>
                    <span className="text-[10px] text-stone-400 block mt-0.5 font-sans">Activez le Mode Focus avec minuteur Pomodoro</span>
                  </div>
                </div>
                <button
                  onClick={() => setLocalFocusActive(true)}
                  className="px-3.5 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-black text-[11px] rounded-xl transition-all shadow-xs shrink-0 flex items-center gap-1 font-sans"
                >
                  <Timer className="w-3.5 h-3.5" />
                  <span>Concentration</span>
                </button>
              </div>
            )}
            
            {/* Subject/Chapters/Time details */}
            <div className="flex items-center gap-4 text-xs text-stone-500 bg-stone-100 p-3 rounded-2xl">
              <div className="flex items-center gap-1.5 font-medium">
                <Layers className="w-3.5 h-3.5 text-amber-600" />
                <span>Chapitre: <strong className="text-stone-700">{activeSheet.chapter}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <Clock className="w-3.5 h-3.5 text-orange-600" />
                <span>Lecture : <strong className="text-stone-700">8 mins</strong></span>
              </div>
              {completedSheets.includes(activeSheet.id) && (
                <div className="ml-auto flex items-center gap-1 text-emerald-600 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Révisé</span>
                </div>
              )}
            </div>

            {/* Résumé Callout Box */}
            <div className="bg-amber-50/70 border border-amber-200/50 p-4 rounded-2xl relative shadow-sm">
              <h4 className="text-xs uppercase font-bold tracking-wider text-amber-800 mb-1 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                En bref (Résumé)
              </h4>
              <p className="text-stone-700 text-xs leading-relaxed italic">
                "{activeSheet.summary}"
              </p>
            </div>

            {/* AI Generated watermark */}
            {activeSheet.isAIGenerated && (
              <div className="bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-200/40 p-3 rounded-2xl flex items-center gap-2.5 text-xs text-stone-800 shadow-sm">
                <Sparkles className="w-5 h-5 text-orange-600 animate-pulse" />
                <div>
                  <strong className="text-orange-950 font-bold block">Fiche numérisée par l'IA Sankofa</strong>
                  <span className="text-[10px] text-stone-500">Générée dynamiquement par reconnaissance optique (OCR)</span>
                </div>
              </div>
            )}

            {/* Detailed Content */}
            <div className="prose prose-stone max-w-none text-stone-800 font-sans">
              {renderFormattedContent(activeSheet.content)}
            </div>

            {/* Formulas Box */}
            {activeSheet.formulas && activeSheet.formulas.length > 0 && (
              <div className="border border-orange-500/20 bg-orange-500/[0.02] p-4 rounded-2xl space-y-2">
                <h4 className="text-xs uppercase font-bold tracking-wider text-orange-800 flex items-center gap-2">
                  <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                  Formules clés à retenir
                </h4>
                <div className="space-y-1.5">
                  {activeSheet.formulas.map((formula, idx) => (
                    <div key={idx} className="bg-white/80 border border-stone-200/50 p-2.5 rounded-xl text-xs font-mono text-stone-800 shadow-sm">
                      {formula}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Vocabulary & Definitions list */}
            {activeSheet.definitions && activeSheet.definitions.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs uppercase font-bold tracking-wider text-stone-500">
                  Définitions et Vocabulaire important
                </h4>
                <div className="grid gap-2.5">
                  {activeSheet.definitions.map((def, idx) => (
                    <div key={idx} className="bg-white border border-stone-200/50 p-3.5 rounded-2xl shadow-sm hover:shadow transition-all">
                      <span className="text-xs font-bold text-amber-700 bg-amber-500/10 px-2 py-0.5 rounded-md inline-block mb-1.5">
                        {def.term}
                      </span>
                      <p className="text-stone-700 text-xs leading-relaxed">
                        {def.definition}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* YouTube Helper section */}
            {activeSheet.youtubeKeywords && (
              <div className="bg-red-500/[0.02] border border-red-500/10 p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="space-y-1">
                  <h4 className="text-xs uppercase font-bold tracking-wider text-red-700 flex items-center gap-1.5">
                    <Play className="w-4 h-4 text-red-600 fill-current" />
                    Vidéos explicatives
                  </h4>
                  <p className="text-[11px] text-stone-500 leading-tight">
                    Visionner un enseignant ivoirien résoudre des exercices similaires.
                  </p>
                </div>
                <button
                  onClick={() => onLaunchVideoSearch(activeSheet.youtubeKeywords!)}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-red-500/10 transition-all cursor-pointer shrink-0"
                >
                  <Search className="w-3.5 h-3.5" />
                  Regarder sur YouTube
                </button>
              </div>
            )}

            {/* Big Quiz Launcher */}
            <div className="pt-4 border-t border-stone-100 flex flex-col gap-3">
              {(() => {
                const quiz = quizzes.find((q) => q.sheetId === activeSheet.id);
                if (quiz) {
                  return (
                    <button
                      onClick={() => onLaunchQuiz(quiz.id)}
                      className="w-full py-4 bg-gradient-to-r from-orange-600 to-amber-500 text-white font-bold rounded-2xl shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 flex items-center justify-center gap-2 text-sm transition-all cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 animate-bounce" />
                      Lancer le quiz d'évaluation ({quiz.questions.length} questions)
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  );
                } else {
                  return (
                    <p className="text-xs text-stone-400 text-center italic py-2">
                      Aucun quiz de validation disponible pour cette leçon actuellement.
                    </p>
                  );
                }
              })()}



              <button
                onClick={() => {
                  onMarkAsRead(activeSheet.id);
                  setActiveSheet(null);
                }}
                className="w-full py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-2xl text-xs transition-all text-center"
              >
                J'ai terminé ma révision de cette fiche
              </button>
            </div>
          </div>
        )}

          </div>
        ) : (
        /* --- VIEW 2 : DIRECTORY HOME --- */
        <div className="flex flex-col h-full">
          
          {/* Main search and filters bar */}
          <div className="p-4 bg-white border-b border-stone-200/50 space-y-3 shadow-xs">
            
            {/* Search Input */}
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="Rechercher une fiche, un chapitre, une formule..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 text-xs focus:outline-none focus:border-orange-500 focus:bg-white transition-all font-sans"
              />
            </div>

            {/* Exam selections header tabs */}
            <div className="flex gap-2">
              {(['BEPC', 'BAC', 'Concours'] as ExamType[]).map((exam) => (
                <button
                  key={exam}
                  onClick={() => handleExamChange(exam)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    selectedExam === exam
                      ? 'bg-[#3c2518] text-amber-400 shadow-sm'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200/70'
                  }`}
                >
                  {exam}
                </button>
              ))}
            </div>

            {/* Series selection sub-selector */}
            {selectedExam === 'BAC' ? (
              <div className="flex items-center gap-2 bg-stone-100 p-1.5 rounded-xl text-[11px] justify-between">
                <span className="font-bold text-stone-500 pl-1.5 flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-orange-600" />
                  Série BAC :
                </span>
                <div className="flex gap-1">
                  {['A', 'C', 'D'].map((s) => (
                    <button
                      key={s}
                      onClick={() => {
                        setSelectedSeries(s);
                        if (onChangeSeries) onChangeSeries(s);
                      }}
                      className={`px-3 py-1 rounded-lg font-black transition-all ${
                        selectedSeries === s
                          ? 'bg-amber-500 text-stone-950 shadow-xs'
                          : 'bg-white/60 hover:bg-white text-stone-600'
                      }`}
                    >
                      Série {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-stone-100/60 px-3 py-1.5 rounded-xl text-[10px] text-stone-500 font-bold self-start">
                <Layers className="w-3.5 h-3.5 text-stone-400" />
                Série : <span className="text-stone-700 font-extrabold uppercase">Enseignement Général</span>
              </div>
            )}

            {/* Horizontal scrollable subjects filter bar */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {availableSubjects.map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubject(sub)}
                  className={`px-3.5 py-1.5 rounded-full text-[11px] font-bold whitespace-nowrap border transition-all shrink-0 ${
                    selectedSubject === sub
                      ? 'bg-amber-500/10 text-amber-700 border-amber-500/20 shadow-xs'
                      : 'bg-stone-50 text-stone-500 border-stone-200'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>

            {/* Multi-toggle option controls (Favorites / Offline downloads only) */}
            <div className="flex gap-3 pt-1 border-t border-stone-100 justify-start">
              <button
                onClick={() => setFilterFavorites(!filterFavorites)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all ${
                  filterFavorites
                    ? 'bg-amber-500 text-stone-950 border-transparent shadow-xs'
                    : 'bg-stone-50 text-stone-500 border-stone-200'
                }`}
              >
                <Star className="w-3.5 h-3.5" />
                Mes Favoris
              </button>
              <button
                onClick={() => setFilterOffline(!filterOffline)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-all ${
                  filterOffline
                    ? 'bg-orange-600 text-white border-transparent shadow-xs'
                    : 'bg-stone-50 text-stone-500 border-stone-200'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                Téléchargées ({downloads.length})
              </button>
            </div>
          </div>

          {/* Fiches list container */}
          <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3">
            {filteredSheets.length > 0 ? (
              filteredSheets.map((sheet) => {
                const isSheetFavorite = favorites.includes(sheet.id);
                const isSheetDownloaded = downloads.includes(sheet.id);
                const isSheetCompleted = completedSheets.includes(sheet.id);
                
                return (
                  <div
                    key={sheet.id}
                    className="bg-white border border-stone-200/60 rounded-2xl shadow-xs overflow-hidden hover:shadow-md transition-all flex flex-col"
                  >
                    {/* Header banner area */}
                    <div className="flex p-4 gap-3.5">
                      
                      {/* Left side micro picture */}
                      <div className="w-14 h-14 bg-stone-100 rounded-xl overflow-hidden shrink-0 relative">
                        <img
                          src={sheet.illustrationUrl || 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'}
                          alt={sheet.title}
                          className="w-full h-full object-cover"
                        />
                        {sheet.isAIGenerated && (
                          <div className="absolute top-0.5 right-0.5 bg-orange-600 text-white p-0.5 rounded-full shadow-md">
                            <Sparkles className="w-2.5 h-2.5 animate-pulse" />
                          </div>
                        )}
                      </div>

                      {/* Middle description section */}
                      <div className="flex-1 space-y-0.5 min-w-0">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-700 uppercase tracking-wider">
                          <span>{sheet.subject}</span>
                          <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
                          <span className="text-stone-500 font-medium normal-case">{sheet.chapter}</span>
                        </div>
                        <h4
                          onClick={() => setActiveSheet(sheet)}
                          className="text-stone-900 font-display font-bold text-xs hover:text-orange-600 transition-all cursor-pointer line-clamp-1 min-w-0"
                        >
                          {sheet.title}
                        </h4>
                        <p className="text-[11px] text-stone-500 line-clamp-2 leading-relaxed">
                          {sheet.summary}
                        </p>
                      </div>

                    </div>

                    {/* Bottom controls action strip */}
                    <div className="bg-stone-50 border-t border-stone-100 px-4 py-2.5 flex justify-between items-center text-xs">
                      <div className="flex items-center gap-3">
                        {/* Favorite button */}
                        <button
                          onClick={() => onToggleFavorite(sheet.id)}
                          className={`text-stone-400 hover:text-amber-500 transition-all ${
                            isSheetFavorite ? 'text-amber-500' : ''
                          }`}
                        >
                          <Star className={`w-4 h-4 ${isSheetFavorite ? 'fill-current' : ''}`} />
                        </button>
                        
                        {/* Download button */}
                        <button
                          onClick={() => onToggleDownload(sheet.id)}
                          className={`text-stone-400 hover:text-orange-500 transition-all ${
                            isSheetDownloaded ? 'text-orange-500' : ''
                          }`}
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* Reading indicator */}
                        {isSheetCompleted && (
                          <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold uppercase tracking-wider">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Révisée
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => setActiveSheet(sheet)}
                        className="text-stone-800 hover:text-orange-600 font-bold text-[11px] flex items-center gap-1 group transition-all"
                      >
                        Ouvrir la fiche
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-all" />
                      </button>
                    </div>

                  </div>
                );
              })
            ) : (
              <div className="text-center py-12 space-y-3 bg-white border border-stone-200/50 rounded-2xl p-6">
                <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center mx-auto text-stone-400">
                  <Search className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-display font-bold text-stone-800">Aucune fiche trouvée</h4>
                  <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                    Ajustez vos filtres ou effectuez une nouvelle recherche. Vous pouvez également scanner vos propres cours avec le bouton scanner !
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
