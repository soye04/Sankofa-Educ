/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface SankofaLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  lightText?: boolean;
}

export default function SankofaLogo({ className = '', size, showText = true, lightText = false }: SankofaLogoProps) {
  const style = size ? { width: size, height: size } : {};

  return (
    <div className={`flex flex-col items-center justify-center ${className}`} style={style}>
      <svg
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto max-w-full"
      >
        <defs>
          {/* Main orange-yellow-green gradient for the circular arc */}
          <linearGradient id="sankofa-arc-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f97316" /> {/* Orange */}
            <stop offset="50%" stopColor="#eab308" /> {/* Yellow */}
            <stop offset="100%" stopColor="#15803d" /> {/* Green */}
          </linearGradient>

          {/* Wing Feather Gradients */}
          <linearGradient id="feather-red-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="100%" stopColor="#b91c1c" />
          </linearGradient>
          <linearGradient id="feather-orange-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#f97316" />
            <stop offset="100%" stopColor="#c2410c" />
          </linearGradient>
          <linearGradient id="feather-yellow-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#facc15" />
            <stop offset="100%" stopColor="#a16207" />
          </linearGradient>
          <linearGradient id="feather-green-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22c55e" />
            <stop offset="100%" stopColor="#15803d" />
          </linearGradient>
        </defs>

        {/* 1. OUTER CIRCULAR ARC GRADIENT */}
        <path
          d="M 290,65 A 175,175 0 1,0 350,250"
          stroke="url(#sankofa-arc-grad)"
          strokeWidth="11"
          strokeLinecap="round"
          fill="none"
        />

        {/* 2. SANKOFA BIRD */}
        {/* Main Body (S-curve looking backward) */}
        <path
          d="M 245,295 
             C 175,310 120,240 135,170 
             C 145,120 185,75 240,100 
             C 285,120 295,160 255,190
             C 230,210 200,195 210,235
             C 220,270 195,290 170,295
             C 135,300 120,250 122,210"
          stroke="#23150d"
          strokeWidth="24"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Solid fill for head area to make it clean */}
        <path
          d="M 220,105 C 240,105 275,115 275,135 C 275,165 240,175 220,165 C 205,155 200,125 220,105 Z"
          fill="#23150d"
        />
        {/* Eye */}
        <circle cx="250" cy="128" r="8" fill="#ffffff" />
        <circle cx="250" cy="128" r="3.5" fill="#23150d" />

        {/* Beak */}
        <path
          d="M 240,150 L 225,180 L 248,162 Z"
          fill="#23150d"
          stroke="#23150d"
          strokeWidth="2"
          strokeLinejoin="round"
        />

        {/* Bird Wing (4 Stylized colorful feathers) */}
        <g id="wing-feathers">
          {/* Feather 1 (Red) */}
          <path
            d="M 130,170 C 122,185 130,205 155,210 C 180,215 200,190 195,175 C 180,165 150,160 130,170 Z"
            fill="url(#feather-red-grad)"
          />
          {/* Feather 2 (Orange) */}
          <path
            d="M 133,195 C 125,212 135,230 162,232 C 188,234 205,208 200,192 C 185,182 155,182 133,195 Z"
            fill="url(#feather-orange-grad)"
          />
          {/* Feather 3 (Yellow) */}
          <path
            d="M 140,220 C 132,238 142,254 170,255 C 196,256 210,230 205,212 C 188,202 160,202 140,220 Z"
            fill="url(#feather-yellow-grad)"
          />
          {/* Feather 4 (Green) */}
          <path
            d="M 152,242 C 146,258 158,272 182,272 C 206,272 216,248 210,232 C 195,224 172,224 152,242 Z"
            fill="url(#feather-green-grad)"
          />
        </g>

        {/* 3. GRADUATION CAP & BOOK */}
        <g id="education-symbols">
          {/* Open Book Pages */}
          {/* Cover/Base (Orange shadow) */}
          <path
            d="M 220,325 Q 285,335 295,295 Q 305,335 370,325 Q 295,355 220,325 Z"
            fill="#d97706"
          />
          {/* Left Page and Right Page */}
          <path
            d="M 222,318 Q 285,325 295,290 Q 305,325 368,318 L 360,278 Q 305,285 295,255 Q 285,285 228,278 Z"
            fill="#fffdeb"
            stroke="#23150d"
            strokeWidth="5"
            strokeLinejoin="round"
          />
          {/* Book Spine line */}
          <path
            d="M 295,255 L 295,290"
            stroke="#23150d"
            strokeWidth="4"
          />

          {/* Graduation Cap */}
          {/* Diamond cap top */}
          <path
            d="M 295,175 L 360,205 L 295,235 L 230,205 Z"
            fill="#23150d"
            stroke="#23150d"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          {/* Cap Skull/Base */}
          <path
            d="M 258,218 L 258,232 C 258,245 332,245 332,232 L 332,218 C 310,226 280,226 258,218 Z"
            fill="#23150d"
          />
          {/* Cap Tassel */}
          <path
            d="M 295,205 L 342,226 L 342,260"
            stroke="#23150d"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Tassel fringe */}
          <path
            d="M 338,258 L 346,258 L 346,275 L 338,275 Z"
            fill="#eab308"
            stroke="#23150d"
            strokeWidth="2"
          />
        </g>
      </svg>

      {/* 4. TYPOGRAPHY AND SLOGAN */}
      {showText && (
        <div className="flex flex-col items-center mt-3 text-center w-full">
          {/* Sankofa Educ Name */}
          <div className="flex items-baseline font-sans font-black tracking-tight text-4xl">
            <span className={lightText ? 'text-white' : 'text-[#23150d]'}>Sankofa</span>
            <span className="text-[#eab308] ml-2">Educ</span>
          </div>

          {/* Framing colored lines */}
          <div className="flex items-center gap-4 w-full max-w-[280px] my-3">
            <div className="h-1 flex-1 bg-[#15803d] rounded-full" /> {/* National Green */}
            <div className="h-1 flex-1 bg-[#f97316] rounded-full" /> {/* National Orange */}
          </div>

          {/* Slogan */}
          <div className={`text-[10px] font-extrabold tracking-[0.16em] uppercase ${lightText ? 'text-stone-300' : 'text-stone-600'}`}>
            APPRENDRE <span className="text-[#f97316]">●</span> COMPRENDRE <span className="text-[#15803d]">●</span> RÉUSSIR
          </div>
        </div>
      )}
    </div>
  );
}
