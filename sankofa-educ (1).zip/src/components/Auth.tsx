/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, Lock, User, GraduationCap, ChevronRight, AlertCircle, Sparkles, Loader2, Shield } from 'lucide-react';
import { ExamType } from '../types';
import SankofaLogo from './SankofaLogo';
import { signInWithGoogle } from '../lib/firebase';

interface AuthProps {
  onSuccess: (user: { name: string; email: string; phone: string; targetExam: ExamType; series: string }) => void;
  onAdminClick?: () => void;
}

type AuthMethod = 'email' | 'phone';
type AuthMode = 'login' | 'register';

export default function Auth({ onSuccess, onAdminClick }: AuthProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [method, setMethod] = useState<AuthMethod>('email');
  
  // Forms states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [targetExam, setTargetExam] = useState<ExamType>('BAC');
  const [bepcSeries, setBepcSeries] = useState('Général');
  const [bacSeries, setBacSeries] = useState('D'); // D, C, A
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [serverMessage, setServerMessage] = useState('');
  
  // OTP states
  const [showOtpScreen, setShowOtpScreen] = useState(false);
  const [otpCode, setOtpCode] = useState(['', '', '', '']);
  const [expectedOtp, setExpectedOtp] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const handleGoogleSignIn = async () => {
    setError('');
    try {
      const fbUser = await signInWithGoogle();
      if (fbUser) {
        onSuccess({
          name: fbUser.displayName || 'Élève',
          email: fbUser.email || '',
          phone: fbUser.phoneNumber || 'Non renseigné',
          targetExam: targetExam,
          series: targetExam === 'BAC' ? bacSeries : 'Général'
        });
      }
    } catch (err: any) {
      setError(err.message || 'La connexion avec Google a échoué.');
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setServerMessage('');

    // Email validation
    if (!email.includes('@') || email.length < 5) {
      setError('Veuillez entrer une adresse email valide.');
      return;
    }

    if (password.length < 6 && mode === 'register') {
      setError('Le mot de passe doit contenir au moins 6 caractères.');
      return;
    }

    if (mode === 'register' && !name.trim()) {
      setError('Veuillez saisir votre nom complet.');
      return;
    }

    setIsLoading(true);
    try {
      const selectedSeries = targetExam === 'BAC' ? bacSeries : 'Général';
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phone,
          email,
          method,
          mode,
          password,
          name,
          targetExam,
          series: selectedSeries
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        if (data.code) {
          setExpectedOtp(data.code);
        }
        if (data.message) {
          setServerMessage(data.message);
        }
        setShowOtpScreen(true);
      } else {
        setError(data.error || "Une erreur s'est produite lors de l'envoi du code OTP.");
      }
    } catch (err) {
      console.error('Failed to send OTP:', err);
      setError("Impossible de contacter le serveur pour envoyer le code OTP. Vérifiez votre connexion.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const enteredOtp = otpCode.join('');

    if (enteredOtp.length < 4) {
      setError('Veuillez saisir le code complet à 4 chiffres.');
      return;
    }

    setIsLoading(true);
    try {
      const selectedSeries = targetExam === 'BAC' ? bacSeries : 'Général';
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phone,
          email,
          method,
          code: enteredOtp,
          mode,
          password,
          name,
          targetExam,
          series: selectedSeries
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        const returnedUser = data.user || {
          name: name || email.split('@')[0],
          email: email,
          phone: phone || 'Non renseigné',
          targetExam,
          series: selectedSeries
        };
        onSuccess(returnedUser);
      } else {
        setError(data.error || 'Code de vérification incorrect. Veuillez réessayer.');
      }
    } catch (err) {
      console.error('Failed to verify OTP:', err);
      setError("Impossible de vérifier le code auprès du serveur.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setError('');
    setServerMessage('');
    setIsLoading(true);
    try {
      const selectedSeries = targetExam === 'BAC' ? bacSeries : 'Général';
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phone,
          email,
          method,
          mode,
          password,
          name,
          targetExam,
          series: selectedSeries
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        if (data.code) {
          setExpectedOtp(data.code);
        }
        if (data.message) {
          setServerMessage(data.message);
        }
        setOtpCode(['', '', '', '']); // Clear input digits
      } else {
        setError(data.error || "Une erreur s'est produite lors de l'envoi du code OTP.");
      }
    } catch (err) {
      console.error('Failed to resend OTP:', err);
      setError("Impossible de contacter le serveur pour renvoyer le code.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackToAuth = () => {
    setShowOtpScreen(false);
    setOtpCode(['', '', '', '']);
    setError('');
    setServerMessage('');
  };

  const handleOtpInput = (val: string, index: number) => {
    if (!/^\d*$/.test(val)) return; // Only numbers
    const newOtp = [...otpCode];
    newOtp[index] = val.slice(-1);
    setOtpCode(newOtp);

    // Auto focus next
    if (val && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7] px-6 py-6 overflow-y-auto no-scrollbar font-sans text-stone-900 justify-between">
      
      {/* Top Header */}
      <div className="flex flex-col items-center text-center mt-4">
        <SankofaLogo size={120} showText={true} />
        <p className="text-xs text-stone-500 mt-2">La meilleure plateforme de révision en Côte d'Ivoire</p>
      </div>

      <AnimatePresence mode="wait">
        {!showOtpScreen && !showForgotPassword && (
          <motion.div
            key="auth-forms"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="flex-1 flex flex-col justify-center my-6"
          >
            {/* Toggle tabs for Login / Register */}
            <div className="grid grid-cols-2 bg-stone-200/60 p-1 rounded-xl mb-6">
              <button
                onClick={() => { setMode('login'); setError(''); }}
                className={`py-2 text-sm font-semibold rounded-lg transition-all ${
                  mode === 'login' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-500'
                }`}
              >
                Connexion
              </button>
              <button
                onClick={() => { setMode('register'); setError(''); }}
                className={`py-2 text-sm font-semibold rounded-lg transition-all ${
                  mode === 'register' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-500'
                }`}
              >
                Créer un compte
              </button>
            </div>

            {/* Connexion par Email uniquement */}

            {/* Error message */}
            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 flex items-start gap-2 text-xs leading-relaxed">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSendOtp} className="space-y-4">
              
              {/* Name Field (Only on Registration) */}
              {mode === 'register' && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">Nom complet</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                      <User className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="Koffi Armand"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>
              )}

              {/* Email Field */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">Adresse Email</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    required
                    placeholder="koffi.armand@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition-all"
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">Mot de passe</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => { setShowForgotPassword(true); setError(''); }}
                      className="text-xs text-orange-600 font-medium hover:underline"
                    >
                      Mot de passe oublié ?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-stone-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500 focus:bg-white transition-all"
                  />
                </div>
              </div>

              {/* Target Exam Selection (Only on Registration) */}
              {mode === 'register' && (
                <div className="space-y-2 pt-2">
                  <label className="text-xs font-bold text-stone-600 uppercase tracking-wider block">Examen ou Concours ciblé</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['BEPC', 'BAC', 'Concours'] as ExamType[]).map((exam) => (
                      <button
                        type="button"
                        key={exam}
                        onClick={() => setTargetExam(exam)}
                        className={`py-2 px-1 rounded-xl text-center border text-xs font-bold transition-all ${
                          targetExam === exam
                            ? 'bg-[#3c2518] text-white border-transparent shadow-md'
                            : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        {exam}
                      </button>
                    ))}
                  </div>

                  {/* Subchoices based on selection */}
                  {targetExam === 'BAC' && (
                    <div className="flex items-center gap-3 bg-stone-100 p-2.5 rounded-xl text-xs">
                      <span className="font-semibold text-stone-600">Série BAC :</span>
                      {['A', 'C', 'D'].map((s) => (
                        <button
                          type="button"
                          key={s}
                          onClick={() => setBacSeries(s)}
                          className={`px-3 py-1 rounded-lg font-bold transition-all ${
                            bacSeries === s ? 'bg-amber-500 text-stone-950 shadow-sm' : 'bg-white/60 text-stone-600'
                          }`}
                        >
                          Série {s}
                        </button>
                      ))}
                    </div>
                  )}

                  {targetExam === 'BEPC' && (
                    <div className="flex items-center gap-3 bg-stone-100 p-2.5 rounded-xl text-xs">
                      <span className="font-semibold text-stone-600">Série BEPC :</span>
                      <span className="bg-amber-500 text-stone-950 px-2.5 py-1 rounded-lg font-bold shadow-sm">
                        Enseignement Général
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Action Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold rounded-xl shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 flex items-center justify-center gap-2 mt-6 transition-all text-sm cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Envoi en cours...</span>
                  </>
                ) : (
                  <>
                    {mode === 'login' ? 'Se connecter' : 'Créer mon compte'}
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>

            </form>

            {/* Divider and Google Sign-In */}
            <div className="relative my-4 flex items-center justify-center">
              <div className="border-t border-stone-200/80 w-full absolute"></div>
              <span className="bg-[#fcfbf7] px-3.5 text-[11px] text-stone-400 font-bold uppercase tracking-wider relative z-10">Ou continuer avec</span>
            </div>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="w-full py-3 bg-white hover:bg-stone-50 text-stone-700 font-bold rounded-xl border border-stone-200 flex items-center justify-center gap-2.5 shadow-sm hover:shadow transition-all text-sm cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#EA4335" d="M12 5.04c1.66 0 3.2.57 4.38 1.69l3.27-3.27C17.68 1.54 14.98 1 12 1 7.35 1 3.37 3.67 1.39 7.56l3.89 3.02C6.21 7.55 8.9 5.04 12 5.04z"/>
                <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.43c-.28 1.44-1.1 2.67-2.33 3.5l3.61 2.8c2.11-1.95 3.78-4.82 3.78-8.45z"/>
                <path fill="#FBBC05" d="M5.28 14.48c-.24-.73-.38-1.5-.38-2.3s.14-1.57.38-2.3L1.39 6.86C.5 8.61 0 10.56 0 12.62s.5 4.01 1.39 5.76l3.89-3z"/>
                <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.91l-3.61-2.8c-1.01.68-2.3 1.09-3.79 1.09-3.1 0-5.79-2.51-6.72-5.54l-3.89 3C3.37 20.33 7.35 23 12 23z"/>
              </svg>
              Google
            </button>

            {onAdminClick && (
              <div className="mt-4 pt-4 border-t border-stone-100 flex flex-col items-center">
                <span className="text-[10px] text-stone-400 font-bold uppercase tracking-wider mb-2">Vous êtes enseignant ?</span>
                <button
                  type="button"
                  onClick={onAdminClick}
                  className="w-full py-3 bg-[#3c2518] hover:bg-[#2c1b11] text-amber-400 font-bold rounded-xl flex items-center justify-center gap-2 border border-[#4d3221] shadow-sm transition-all text-xs cursor-pointer"
                >
                  <Shield className="w-4 h-4 text-amber-500 animate-pulse" />
                  Accéder au Portail Admin (Enseignants)
                </button>
              </div>
            )}
          </motion.div>
        )}

        {showOtpScreen && (
          <motion.div
            key="otp-verification"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col justify-center my-6"
          >
            <div className="text-center mb-6">
              <h3 className="text-lg font-display font-bold text-stone-900">Vérification de sécurité</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                Un code d'authentification OTP a été envoyé par Email à <strong className="text-stone-800">{email}</strong>.
              </p>
            </div>

            {/* OTP status banner */}
            {serverMessage && (
              <div className="mb-6 p-3 bg-amber-50 border border-amber-200/50 rounded-xl text-stone-800 flex flex-col gap-1 text-xs font-sans shadow-sm">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-semibold text-stone-700">Système OTP :</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed mt-0.5">{serverMessage}</p>
              </div>
            )}

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleVerifyOtp} className="space-y-6">
              <div className="flex justify-center gap-3">
                {otpCode.map((digit, index) => (
                  <input
                    key={index}
                    id={`otp-${index}`}
                    type="text"
                    pattern="\d*"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpInput(e.target.value, index)}
                    onKeyDown={(e) => {
                      if (e.key === 'Backspace' && !digit && index > 0) {
                        const prevInput = document.getElementById(`otp-${index - 1}`);
                        prevInput?.focus();
                      }
                    }}
                    className="w-14 h-14 text-center font-mono text-2xl font-black bg-stone-50 border border-stone-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent focus:bg-white text-stone-800 shadow-sm"
                  />
                ))}
              </div>

              <div className="text-center">
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={handleResendOtp}
                  className="text-xs text-orange-600 font-bold hover:underline disabled:opacity-50"
                >
                  {isLoading ? 'Envoi en cours...' : 'Renvoyer le code OTP'}
                </button>
              </div>

              <div className="space-y-3 pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 bg-[#3c2518] hover:bg-[#2c1b11] text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 transition-all text-sm disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                      <span>Vérification...</span>
                    </>
                  ) : (
                    'Valider le code'
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleBackToAuth}
                  disabled={isLoading}
                  className="w-full py-3 border border-stone-200 text-stone-600 font-semibold rounded-xl text-xs hover:bg-stone-50 transition-all disabled:opacity-50"
                >
                  Retour
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {showForgotPassword && (
          <motion.div
            key="forgot-password"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex-1 flex flex-col justify-center my-6"
          >
            <div className="text-center mb-6">
              <h3 className="text-lg font-display font-bold text-stone-900">Mot de passe oublié</h3>
              <p className="text-xs text-stone-500 mt-1">
                Saisissez votre adresse email pour recevoir un lien de réinitialisation.
              </p>
            </div>

            {forgotSent ? (
              <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl text-stone-800 text-xs leading-relaxed space-y-3 shadow-sm mb-6">
                <p className="text-emerald-700 font-bold">Lien envoyé ! ✨</p>
                <p>Nous avons simulé l'envoi d'un email contenant les instructions de réinitialisation de votre mot de passe à l'adresse <strong>{forgotEmail}</strong>.</p>
                <button
                  onClick={() => { setShowForgotPassword(false); setForgotSent(false); }}
                  className="w-full py-2 bg-emerald-600 text-white font-bold rounded-xl text-center text-xs block"
                >
                  Retourner à la connexion
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!forgotEmail.includes('@')) {
                    setError('Veuillez entrer une adresse email valide.');
                    return;
                  }
                  setForgotSent(true);
                }}
                className="space-y-4"
              >
                <div className="space-y-1">
                  <label className="text-xs font-bold text-stone-600 block">Adresse Email</label>
                  <input
                    type="email"
                    required
                    placeholder="koffi.armand@gmail.com"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-sm focus:outline-none focus:border-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#3c2518] text-white font-bold rounded-xl text-sm shadow-md"
                >
                  Envoyer le lien
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForgotPassword(false); setError(''); }}
                  className="w-full py-2.5 text-stone-500 font-semibold text-xs hover:bg-stone-50 rounded-xl text-center block"
                >
                  Annuler
                </button>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer credits / regulatory compliance */}
      <div className="text-center text-[10px] text-stone-400 font-sans border-t border-stone-100 pt-3">
        Sankofa Educ Côte d'Ivoire. Tous droits réservés. En vous connectant, vous acceptez nos CGU et conditions de confidentialité.
      </div>

    </div>
  );
}
