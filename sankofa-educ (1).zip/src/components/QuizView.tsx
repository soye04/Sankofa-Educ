/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Check, X, AlertCircle, Award, RefreshCw, BookOpen, BarChart2, Star, ChevronRight } from 'lucide-react';
import { Quiz, QuizQuestion } from '../types';

interface QuizViewProps {
  quiz: Quiz;
  onComplete: (score: number, total: number) => void;
  onClose: () => void;
}

export default function QuizView({ quiz, onComplete, onClose }: QuizViewProps) {
  const [gameState, setGameState] = useState<'intro' | 'playing' | 'feedback' | 'summary'>('intro');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [textAnswer, setTextAnswer] = useState('');
  const [answersHistory, setAnswersHistory] = useState<{ questionId: string; userAns: string; isCorrect: boolean }[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(45); // 45s timer per question
  
  const currentQuestion = quiz.questions[currentIdx];

  // Timer logic during playing
  useEffect(() => {
    if (gameState !== 'playing') return;
    
    setTimeLeft(45); // Reset
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Auto submit blank
          handleAnswerSubmit('');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState, currentIdx]);

  const handleStartQuiz = () => {
    setGameState('playing');
    setCurrentIdx(0);
    setScore(0);
    setAnswersHistory([]);
    setSelectedAnswer(null);
    setTextAnswer('');
  };

  const handleAnswerSubmit = (ans: string) => {
    const isCorrect = ans.trim().toLowerCase() === currentQuestion.correctAnswer.trim().toLowerCase();
    
    if (isCorrect) {
      setScore((s) => s + 1);
    }

    setAnswersHistory((prev) => [
      ...prev,
      {
        questionId: currentQuestion.id,
        userAns: ans,
        isCorrect
      }
    ]);

    setSelectedAnswer(ans);
    setGameState('feedback');
  };

  const handleNextQuestion = () => {
    if (currentIdx < quiz.questions.length - 1) {
      setCurrentIdx((idx) => idx + 1);
      setSelectedAnswer(null);
      setTextAnswer('');
      setGameState('playing');
    } else {
      // Completed!
      onComplete(score, quiz.questions.length);
      setGameState('summary');
    }
  };

  // Score description helper
  const getScoreSummary = () => {
    const ratio = score / quiz.questions.length;
    if (ratio === 1) return { title: 'Excellent ! 🎉', desc: 'Tu as maîtrisé parfaitement cette leçon. Continue comme ça pour le jour J !' };
    if (ratio >= 0.6) return { title: 'Très bien ! 👍', desc: 'Bon travail, la leçon est bien comprise. Révise les explications pour le sans-faute.' };
    return { title: 'À revoir ! 📚', desc: 'Relis attentivement la fiche de révision et réessaie. Tu vas t\'améliorer !' };
  };

  const currentCorrection = answersHistory.find((h) => h.questionId === currentQuestion?.id);

  return (
    <div className="flex flex-col h-full bg-[#fcfbf7] font-sans text-stone-900 justify-between">
      
      {/* HEADER SECTION */}
      <div className="p-4 bg-white border-b border-stone-200/50 flex justify-between items-center shrink-0 shadow-xs">
        <div className="flex flex-col">
          <span className="text-[9px] font-black uppercase tracking-widest text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full inline-block self-start">
            {quiz.exam} • {quiz.subject}
          </span>
          <h3 className="text-xs font-bold text-stone-800 font-display mt-0.5 line-clamp-1">{quiz.title}</h3>
        </div>
        <button
          onClick={onClose}
          className="text-stone-400 hover:text-stone-700 font-bold text-xs bg-stone-100 px-2.5 py-1.5 rounded-xl"
        >
          Fermer
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 py-6">
        <AnimatePresence mode="wait">
          
          {/* --- INTRO STATE --- */}
          {gameState === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col items-center justify-center h-full text-center py-6 space-y-6"
            >
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center">
                <Award className="w-10 h-10 text-amber-600" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-display font-black text-stone-900">Prêt pour le test ?</h3>
                <p className="text-xs text-stone-500 leading-relaxed max-w-xs mx-auto">
                  Ce quiz comporte <strong className="text-stone-700">{quiz.questions.length} questions</strong> rédigées par nos experts scolaires pour valider tes connaissances.
                </p>
              </div>

              <div className="bg-stone-100 p-4 rounded-2xl w-full max-w-xs space-y-3.5 text-xs text-left">
                <div className="flex items-center gap-3">
                  <BarChart2 className="w-4 h-4 text-orange-600" />
                  <div>
                    <span className="text-stone-500 block">Difficulté</span>
                    <strong className="text-stone-800 font-bold">{quiz.difficulty}</strong>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <div>
                    <span className="text-stone-500 block">Temps limite</span>
                    <strong className="text-stone-800 font-bold">45 secondes par question</strong>
                  </div>
                </div>
              </div>

              <button
                onClick={handleStartQuiz}
                className="w-full max-w-xs py-4 bg-[#3c2518] hover:bg-[#2c1b11] text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
              >
                Démarrer le quiz
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* --- PLAYING STATE --- */}
          {gameState === 'playing' && (
            <motion.div
              key="playing"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Progress & timer row */}
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-stone-500">
                  Question {currentIdx + 1} sur {quiz.questions.length}
                </span>
                
                {/* Timer pill */}
                <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 text-amber-700 border border-amber-500/20 rounded-full font-bold">
                  <Clock className="w-3.5 h-3.5 text-amber-600 animate-spin" style={{ animationDuration: '6s' }} />
                  <span className="font-mono">{timeLeft}s</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-stone-100 rounded-full overflow-hidden shadow-inner">
                <div
                  className="h-full bg-gradient-to-r from-orange-500 to-amber-500 transition-all duration-300"
                  style={{ width: `${((currentIdx) / quiz.questions.length) * 100}%` }}
                ></div>
              </div>

              {/* Question Text */}
              <div className="bg-white border border-stone-200/50 p-5 rounded-2xl shadow-xs">
                <p className="text-stone-900 font-bold text-sm leading-relaxed">
                  {currentQuestion.question}
                </p>
              </div>

              {/* Answers Selections based on Type */}
              <div className="space-y-3">
                {currentQuestion.type === 'QCM' && currentQuestion.options && (
                  <div className="grid gap-2.5">
                    {currentQuestion.options.map((option, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleAnswerSubmit(option)}
                        className="w-full text-left p-4 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-2xl text-xs font-medium text-stone-800 transition-all active:scale-[0.98] shadow-xs cursor-pointer flex items-center justify-between"
                      >
                        <span className="pr-3">{option}</span>
                        <div className="w-5 h-5 rounded-full border border-stone-300 flex items-center justify-center shrink-0">
                          <span className="text-[9px] font-bold text-stone-400">{String.fromCharCode(65 + idx)}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {currentQuestion.type === 'VraiFaux' && (
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => handleAnswerSubmit('Vrai')}
                      className="py-6 bg-emerald-500/[0.04] hover:bg-emerald-500/[0.08] border border-emerald-500/20 text-emerald-800 font-bold rounded-2xl text-sm flex flex-col items-center justify-center gap-1.5 active:scale-[0.98] transition-all cursor-pointer"
                    >
                      <Check className="w-6 h-6 text-emerald-600" />
                      VRAI
                    </button>
                    <button
                      onClick={() => handleAnswerSubmit('Faux')}
                      className="py-6 bg-red-500/[0.04] hover:bg-red-500/[0.08] border border-red-500/20 text-red-800 font-bold rounded-2xl text-sm flex flex-col items-center justify-center gap-1.5 active:scale-[0.98] transition-all cursor-pointer"
                    >
                      <X className="w-6 h-6 text-red-600" />
                      FAUX
                    </button>
                  </div>
                )}

                {currentQuestion.type === 'Libre' && (
                  <div className="space-y-4">
                    <input
                      type="text"
                      placeholder="Saisissez votre réponse courte ici..."
                      value={textAnswer}
                      onChange={(e) => setTextAnswer(e.target.value)}
                      className="w-full p-4 bg-white border border-stone-200 rounded-2xl text-sm text-stone-800 focus:outline-none focus:border-orange-500 font-semibold"
                    />
                    <button
                      onClick={() => handleAnswerSubmit(textAnswer.trim())}
                      disabled={!textAnswer.trim()}
                      className={`w-full py-3.5 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all ${
                        textAnswer.trim()
                          ? 'bg-[#3c2518] hover:bg-[#2c1b11] shadow-md cursor-pointer'
                          : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      }`}
                    >
                      Soumettre ma réponse
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* --- DETAILED FEEDBACK STATE --- */}
          {gameState === 'feedback' && currentCorrection && (
            <motion.div
              key="feedback"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="space-y-5"
            >
              {/* Question card */}
              <div className="p-4 bg-white border border-stone-100 rounded-2xl shadow-xs">
                <span className="text-[9px] uppercase font-black text-stone-400">La Question</span>
                <p className="text-stone-800 font-semibold text-xs mt-1 leading-relaxed">
                  {currentQuestion.question}
                </p>
              </div>

              {/* Answer result card */}
              {currentCorrection.isCorrect ? (
                <div className="bg-emerald-500/10 border border-emerald-500/20 p-5 rounded-2xl flex gap-3 text-emerald-950 items-start">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                    <Check className="w-5 h-5 stroke-[3]" />
                  </div>
                  <div className="space-y-1">
                    <strong className="text-emerald-800 font-bold text-sm block">Réponse Correcte ! 🎉</strong>
                    <p className="text-xs leading-relaxed">
                      Tu as choisi : <span className="font-bold">"{currentCorrection.userAns || 'Pas de réponse'}"</span>
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-red-500/10 border border-red-500/20 p-5 rounded-2xl flex gap-3 text-red-950 items-start">
                  <div className="w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
                    <X className="w-5 h-5 stroke-[3]" />
                  </div>
                  <div className="space-y-1">
                    <strong className="text-red-800 font-bold text-sm block">Oups, incorrect !</strong>
                    <p className="text-xs leading-relaxed">
                      Tu as choisi : <span className="font-semibold italic">"{currentCorrection.userAns || 'Temps écoulé'}"</span>. 
                      La réponse correcte était : <strong className="font-bold">{currentQuestion.correctAnswer}</strong>.
                    </p>
                  </div>
                </div>
              )}

              {/* Explanations block */}
              <div className="bg-amber-500/[0.04] border border-amber-500/20 p-5 rounded-2xl space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-amber-700" />
                  Explication pédagogique
                </h4>
                <p className="text-stone-700 text-xs leading-relaxed">
                  {currentQuestion.explanation}
                </p>
              </div>

              <button
                onClick={handleNextQuestion}
                className="w-full py-3.5 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
              >
                Continuer
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* --- FINAL SUMMARY STATE --- */}
          {gameState === 'summary' && (
            <motion.div
              key="summary"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="flex flex-col items-center text-center space-y-6"
            >
              {/* Circular score widget */}
              <div className="relative w-32 h-32 flex items-center justify-center bg-white rounded-full border border-stone-200 shadow-lg">
                <svg className="absolute w-28 h-28 transform -rotate-90">
                  <circle
                    cx="56"
                    cy="56"
                    r="48"
                    stroke="#f3f4f6"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="56"
                    cy="56"
                    r="48"
                    stroke="#f97316"
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 48}
                    strokeDashoffset={2 * Math.PI * 48 * (1 - score / quiz.questions.length)}
                    strokeLinecap="round"
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="flex flex-col items-center">
                  <span className="text-3xl font-black text-stone-900 font-display">{score}</span>
                  <span className="text-xs text-stone-400">sur {quiz.questions.length}</span>
                </div>
              </div>

              {/* Assessment Message */}
              <div className="space-y-1.5 px-4">
                <h3 className="text-lg font-display font-black text-stone-900">{getScoreSummary().title}</h3>
                <p className="text-xs text-stone-500 leading-relaxed">
                  {getScoreSummary().desc}
                </p>
              </div>

              {/* Gain statistics badges */}
              <div className="grid grid-cols-2 gap-3 w-full max-w-xs text-left">
                <div className="bg-orange-500/[0.04] border border-orange-500/10 p-3.5 rounded-2xl flex gap-2.5 items-center">
                  <Clock className="w-5 h-5 text-orange-600 shrink-0" />
                  <div className="leading-tight">
                    <span className="text-[9px] text-stone-400 block uppercase font-bold">Temps d'étude</span>
                    <strong className="text-xs text-stone-800 font-black">+15 Min</strong>
                  </div>
                </div>
                <div className="bg-emerald-500/[0.04] border border-emerald-500/10 p-3.5 rounded-2xl flex gap-2.5 items-center">
                  <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="leading-tight">
                    <span className="text-[9px] text-stone-400 block uppercase font-bold">Progression</span>
                    <strong className="text-xs text-stone-800 font-black">Validée ✔</strong>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="w-full max-w-xs space-y-3 pt-3">
                <button
                  onClick={handleStartQuiz}
                  className="w-full py-3.5 bg-[#3c2518] hover:bg-[#2c1b11] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Recommencer le test
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-3 border border-stone-200 text-stone-600 font-bold rounded-xl text-xs hover:bg-stone-50 transition-all text-center"
                >
                  Retourner aux cours
                </button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>

      {/* FOOTER MOTIVATION CHROME */}
      <div className="p-4 bg-stone-50 border-t border-stone-100 text-center text-[10px] text-stone-400 font-mono shrink-0 uppercase tracking-widest">
        Sankofa Educ • Évaluation Continue
      </div>

    </div>
  );
}
