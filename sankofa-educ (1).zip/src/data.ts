/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RevisionSheet, Quiz } from './types';

export const INITIAL_SHEETS: RevisionSheet[] = [
  // --- BEPC ---
  {
    id: 'bepc-maths-thales',
    title: 'Théorème de Thalès et réciproque',
    exam: 'BEPC',
    subject: 'Mathématiques',
    chapter: 'Géométrie',
    summary: 'Le théorème de Thalès permet de calculer des longueurs de segments dans des triangles formés par deux droites parallèles coupées par deux sécantes. Sa réciproque sert à prouver que deux droites sont parallèles.',
    content: `### 1. Énoncé du Théorème de Thalès

Soient deux droites (d) et (d') sécantes en un point A.
B et M sont deux points de (d), distincts de A.
C et N sont deux points de (d'), distincts de A.
Si les droites (BC) et (MN) sont parallèles, alors les rapports des longueurs sont égaux :
$$\\frac{AM}{AB} = \\frac{AN}{AC} = \\frac{MN}{BC}$$

### 2. Utilité du théorème
Ce théorème sert essentiellement à **calculer des longueurs de segments** lorsqu'on est en présence de droites parallèles.

### 3. La réciproque du Théorème de Thalès
Soient (d) et (d') deux droites sécantes en A.
B et M sont sur (d) et C et N sont sur (d').
Si les points A, M, B d'une part et A, N, C d'autre part sont **alignés dans le même ordre** et si :
$$\\frac{AM}{AB} = \\frac{AN}{AC}$$
Alors, les droites (MN) et (BC) sont **parallèles**.

### 4. Exemple d'application
Dans un triangle ABC, un point M est sur [AB] et N est sur [AC] tels que (MN) // (BC).
On donne AB = 8 cm, AC = 10 cm, AM = 2 cm. Calculons AN :
$$\\frac{AM}{AB} = \\frac{AN}{AC} \\Rightarrow \\frac{2}{8} = \\frac{AN}{10} \\Rightarrow AN = \\frac{2 \\times 10}{8} = 2.5\\text{ cm}$$`,
    formulas: [
      'Rapport Thalès : AM / AB = AN / AC = MN / BC',
      'Condition de parallélisme : AM / AB = AN / AC (avec points alignés dans le même ordre)'
    ],
    definitions: [
      { term: 'Sécantes', definition: 'Deux droites qui se coupent en un point unique.' },
      { term: 'Rapport', definition: 'Quotient de deux longueurs, exprimé sans unité.' },
      { term: 'Colinéarité', definition: 'Caractère de droites parallèles ou de vecteurs de même direction.' }
    ],
    youtubeKeywords: 'Theoreme de Thales classe de troisieme',
    isDownloaded: true,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'bepc-pc-acides-bases',
    title: 'Solutions acides, basiques et neutres',
    exam: 'BEPC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie des solutions',
    summary: 'Cette leçon définit la notion de pH et permet de classifier les solutions aqueuses courantes en trois groupes (acides, basiques, neutres) à l’aide du papier pH ou d’un pH-mètre.',
    content: `### 1. La notion de pH
Le **pH** (potentiel Hydrogène) est un nombre sans unité compris entre **0 et 14** qui mesure l'acidité ou la basicité d'une solution aqueuse.

* **Solution Acide** : pH inférieur à 7. Elle contient plus d'ions hydrogène H⁺ que d'ions hydroxyde OH⁻.
* **Solution Neutre** : pH égal à 7 (eau pure). Elle contient autant d'ions H⁺ que d'ions OH⁻.
* **Solution Basique** : pH supérieur à 7. Elle contient moins d'ions H⁺ que d'ions OH⁻.

### 2. Mesure du pH
On peut mesurer le pH de deux façons :
* Avec du **papier pH** : On dépose une goutte de solution sur un morceau de papier. La couleur obtenue est comparée au nuancier pour obtenir une valeur entière approximative.
* Avec un **pH-mètre** : Cet appareil électronique donne une mesure rapide et très précise (à un ou deux chiffres après la virgule).

### 3. Danger des solutions concentrées
Les acides concentrés (comme l'acide chlorhydrique) et les bases concentrées (comme la soude) sont **corrosifs**. Ils provoquent de graves brûlures sur la peau et les yeux.

**Consignes de sécurité :**
* Porter une blouse, des lunettes de protection et des gants.
* En cas de dilution, **verser toujours l'acide dans l'eau**, jamais l'eau dans l'acide pour éviter les projections dues à la chaleur dégagée.`,
    formulas: [
      'Échelle de pH : 0 -----[ACIDE]----- 7(Neutre) -----[BASIQUE]----- 14',
      'Ions caractéristiques : Acides (riches en H⁺), Basiques (riches en OH⁻)'
    ],
    definitions: [
      { term: 'pH', definition: 'Potentiel Hydrogène, grandeur mesurant l\'acidité ou l\'alcalinité d\'une solution.' },
      { term: 'Corrosif', definition: 'Substance chimique qui détruit ou altère les tissus vivants et les matériaux par contact.' },
      { term: 'Dilution', definition: 'Procédé consistant à ajouter du solvant (l\'eau) pour diminuer la concentration de la solution.' }
    ],
    youtubeKeywords: 'Solutions acides et basiques classe de 3eme',
    isDownloaded: false,
    isFavorite: true,
    illustrationUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=600&auto=format&fit=crop&q=80'
  },

  // --- BAC ---
  {
    id: 'bac-maths-logarithme',
    title: 'La fonction Logarithme Népérien (ln)',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Analyse',
    summary: 'La fonction logarithme népérien, notée ln, est la bijection réciproque de la fonction exponentielle. Elle est définie sur ]0; +inf[, s’annule en 1 et transforme les produits en sommes.',
    content: `### 1. Définition et propriétés fondamentales
La fonction logarithme népérien, notée **ln**, est la fonction définie sur l'intervalle $]0; +\\infty[$ dont la dérivée est la fonction inverse :
$$\\ln'(x) = \\frac{1}{x}$$
Et qui s'annule en 1 : $\\ln(1) = 0$.

### 2. Propriétés algébriques remarquables
Pour tous réels $a > 0$ et $b > 0$ :
* **Produit** : $\\ln(a \\times b) = \\ln(a) + \\ln(b)$
* **Quotient** : $\\ln\\left(\\frac{a}{b}\\right) = \\ln(a) - \\ln(b)$
* **Inverse** : $\\ln\\left(\\frac{1}{a}\\right) = -\\ln(a)$
* **Puissance** : $\\ln(a^r) = r \\ln(a)$ (pour tout rationnel $r$)
* **Racine carrée** : $\\ln(\\sqrt{a}) = \\frac{1}{2}\\ln(a)$

### 3. Limites aux bornes et Croissances comparées
* $\\lim_{x \\to 0^+} \\ln(x) = -\\infty$ (la courbe admet l'axe des ordonnées comme asymptote verticale)
* $\\lim_{x \\to +\\infty} \\ln(x) = +\\infty$
* **Croissances comparées** :
  * $\\lim_{x \\to +\\infty} \\frac{\\ln(x)}{x} = 0$
  * $\\lim_{x \\to 0^+} x \\ln(x) = 0$

### 4. Variations et Courbe représentative
La dérivée de ln étant positive sur $]0; +\\infty[$, la fonction est **strictement croissante** sur cet intervalle.
La constante d'Euler $e \\approx 2.718$ est l'unique nombre réel tel que $\\ln(e) = 1$.`,
    formulas: [
      'ln(ab) = ln(a) + ln(b)',
      'ln(a/b) = ln(a) - ln(b)',
      'Dérivée : (ln(u))\' = u\' / u',
      'e ≈ 2.71828 tel que ln(e) = 1'
    ],
    definitions: [
      { term: 'Bijection réciproque', definition: 'Fonction qui associe de manière unique chaque élément d\'un ensemble d\'arrivée à un seul élément de départ.' },
      { term: 'Asymptote', definition: 'Droite vers laquelle une courbe se rapproche indéfiniment sans jamais la toucher.' },
      { term: 'Constante e', definition: 'Base des logarithmes népériens, nombre irrationnel valant environ 2,71828.' }
    ],
    youtubeKeywords: 'fonction logarithme neperien cours terminale d',
    isDownloaded: true,
    isFavorite: true,
    illustrationUrl: 'https://images.unsplash.com/photo-1453733190148-c44698c265a8?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'bac-pc-cinetique',
    title: 'Cinétique Chimique et Facteurs Cinétiques',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie organique et générale',
    summary: 'La cinétique chimique est l’étude de la vitesse de déroulement des réactions chimiques. Cette leçon examine la vitesse volumique de réaction, le temps de demi-réaction et l’impact de la température et de la concentration.',
    content: `### 1. Classification des réactions selon leur durée
* **Réactions instantanées** : Se produisent en un temps trop court pour être suivi à l'œil nu (ex : précipitations, explosions).
* **Réactions lentes** : Durent de quelques secondes à plusieurs heures, permettant de suivre l'évolution des concentrations au cours du temps.

### 2. Facteurs cinétiques
Un facteur cinétique est un paramètre qui influe sur la vitesse d'une réaction chimique :
* **La concentration des réactifs** : Plus elle est élevée, plus les collisions entre molécules sont fréquentes, et plus la réaction est rapide.
* **La température** : L'élévation de température augmente l'agitation thermique et accélère la réaction.
* **Le catalyseur** : Substance qui augmente la vitesse d'une réaction sans être consommée par celle-ci.

### 3. Vitesse volumique d'une réaction
La vitesse volumique d'apparition d'un produit $P$ à un instant $t$ est la dérivée de sa concentration par rapport au temps :
$$v(P) = \\frac{d[P]}{dt}$$
Elle correspond au coefficient directeur de la tangente à la courbe de concentration $[P] = f(t)$ à l'instant choisi. La vitesse diminue généralement au cours du temps car les réactifs s'épuisent.

### 4. Temps de demi-réaction ($t_{1/2}$)
Le temps de demi-réaction est la durée nécessaire pour que l'avancement de la réaction atteigne la moitié de sa valeur finale. C'est un indicateur important pour caractériser la rapidité d'une transformation.`,
    formulas: [
      'Vitesse d\'apparition : v_app = d[Produit] / dt',
      'Vitesse de disparition : v_disp = - d[Réactif] / dt',
      'Temps de demi-réaction : x(t_1/2) = x_max / 2'
    ],
    definitions: [
      { term: 'Catalyseur', definition: 'Substance qui accélère une réaction chimique sans participer à son bilan réactionnel.' },
      { term: 'Cinétique', definition: 'Branche de la chimie qui s\'intéresse à l\'évolution temporelle des systèmes chimiques.' },
      { term: 'Facteur cinétique', definition: 'Paramètre physique ou chimique capable de modifier la vitesse d\'évolution d\'un système.' }
    ],
    youtubeKeywords: 'cinetique chimique terminale d cote d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?w=600&auto=format&fit=crop&q=80'
  },

  // --- CONCOURS ---
  {
    id: 'concours-cg-institutions',
    title: 'Les Institutions de la 3ème République de Côte d\'Ivoire',
    exam: 'Concours',
    subject: 'Culture Générale',
    chapter: 'Éducation Civique & Politique',
    summary: 'Présentation exhaustive des institutions politiques, constitutionnelles et consultatives de la République de Côte d’Ivoire issues de la Constitution du 8 novembre 2016.',
    content: `### Introduction
La Constitution du 8 novembre 2016 a instauré la **Troisième République** en Côte d'Ivoire. Les institutions ivoiriennes s'organisent autour de l'exécutif, du législatif, du judiciaire et d'organes de régulation ou consultatifs.

### 1. Le Pouvoir Exécutif
* **Le Président de la République** : Chef de l'État, il incarne l'unité nationale, définit la politique de la nation et nomme le Premier Ministre. Élu au suffrage universel direct pour un mandat de 5 ans.
* **Le Vice-Président de la République** : Nommé par le Président en accord avec le Parlement. Il assiste le Président et lui succède en cas de vacance du pouvoir.
* **Le Gouvernement** : Composé du Premier Ministre (Chef du Gouvernement) et des ministres.

### 2. Le Pouvoir Législatif (Le Parlement)
Le Parlement ivoirien est désormais **bicaméral** (deux chambres) :
* **L'Assemblée Nationale** : Composée de députés élus au suffrage universel direct.
* **Le Sénat** : Représente les collectivités territoriales. Deux tiers des sénateurs sont élus au suffrage universel indirect, et un tiers est nommé par le Président de la République.

### 3. Les Institutions Constitutionnelles et Judiciaires
* **Le Conseil Constitutionnel** : Juge de la constitutionnalité des lois, il valide les candidatures présidentielles et proclame les résultats définitifs de l'élection présidentielle.
* **La Cour Suprême** : Coiffe l'ordre judiciaire, composée de la Cour de Cassation, du Conseil d'État et de la Cour des Comptes.
* **La Haute Cour de Justice** : Juge le Président de la République et les membres du gouvernement en cas de haute trahison ou de crimes commis dans l'exercice de leurs fonctions.

### 4. Organes Consultatifs d'Importance
* **Le Conseil Économique, Social, Environnemental et Culturel (CESEC)** : Donne des avis sur les projets de loi à caractère économique ou social.
* **Le Médiateur de la République** : Organe indépendant chargé de régler à l'amiable les litiges entre les citoyens et l'administration publique.`,
    formulas: [
      'Mandat présidentiel : 5 ans (renouvelable une fois constitutionnellement)',
      'Parlement = Assemblée Nationale (Députés) + Sénat (Sénateurs)'
    ],
    definitions: [
      { term: 'Bicamérisme', definition: 'Système parlementaire à deux chambres législatives.' },
      { term: 'Constitution', definition: 'Loi fondamentale qui organise les pouvoirs publics et garantit les droits fondamentaux des citoyens.' },
      { term: 'Promulgation', definition: 'Acte par lequel le Chef de l\'État constate officiellement l\'existence d\'une loi et la rend exécutoire.' }
    ],
    youtubeKeywords: 'les institutions de la republique de cote d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 1. BEPC Maths - Pythagore ---
  {
    id: 'bepc-maths-pythagore',
    title: 'Propriété de Pythagore dans le triangle rectangle',
    exam: 'BEPC',
    subject: 'Mathématiques',
    chapter: 'Géométrie',
    summary: 'Le théorème de Pythagore relie les longueurs des côtés d\'un triangle rectangle. Sa réciproque permet de vérifier si un triangle est rectangle.',
    content: `### 1. Théorème de Pythagore
Dans un triangle rectangle, le carré de la longueur de l'hypoténuse est égal à la somme des carrés des longueurs des deux autres côtés.
Si un triangle ABC est rectangle en A, alors :
$$BC^2 = AB^2 + AC^2$$

### 2. Réciproque du théorème
Si dans un triangle ABC, le plus grand côté [BC] vérifie la relation :
$$BC^2 = AB^2 + AC^2$$
Alors le triangle ABC est rectangle en A.

### 3. Exemple de calcul
Soit un triangle ABC rectangle en A tel que AB = 3 cm et AC = 4 cm. Calculons BC :
$$BC^2 = AB^2 + AC^2 = 3^2 + 4^2 = 9 + 16 = 25 \\Rightarrow BC = \\sqrt{25} = 5\\text{ cm}$$`,
    formulas: [
      'Hypoténuse au carré : BC² = AB² + AC²',
      'Réciproque : Si BC² = AB² + AC² alors rectangle en A'
    ],
    definitions: [
      { term: 'Hypoténuse', definition: 'Le côté le plus long d\'un triangle rectangle, opposé à l\'angle droit.' },
      { term: 'Triangle rectangle', definition: 'Triangle possédant un angle droit (90 degrés).' }
    ],
    youtubeKeywords: 'Theoreme de Pythagore classe de troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  // --- 2. BEPC Maths - Equations ---
  {
    id: 'bepc-maths-equations',
    title: 'Équations et Inéquations du 1er degré',
    exam: 'BEPC',
    subject: 'Mathématiques',
    chapter: 'Algèbre',
    summary: 'Règles et méthodes systématiques pour résoudre des équations et des inéquations du premier degré à une inconnue réelle.',
    content: `### 1. Résolution d'équations
Une équation du premier degré se ramène à la forme :
$$ax + b = 0$$
Si $a \\neq 0$, la solution unique est :
$$x = -\\frac{b}{a}$$

### 2. Équations-Produits
Une équation-produit est de la forme $(ax + b)(cx + d) = 0$. Un produit de facteurs est nul si et seulement si l'un au moins des facteurs est nul :
$$ax + b = 0 \\quad \\text{ou} \\quad cx + d = 0$$

### 3. Résolution d'inéquations
Pour résoudre $ax + b \\leq 0$ :
* Si $a > 0$, alors $x \\leq -\\frac{b}{a}$
* Si $a < 0$, on change le sens de l'inégalité en divisant : $x \\geq -\\frac{b}{a}$`,
    formulas: [
      'Solution de ax+b = 0 : x = -b/a',
      'Règle du produit nul : A × B = 0 ⇔ A = 0 ou B = 0'
    ],
    definitions: [
      { term: 'Inconnue', definition: 'Variable (généralement notée x) dont on cherche la valeur.' },
      { term: 'Inéquation', definition: 'Inégalité mathématique comportant une ou plusieurs inconnues.' }
    ],
    youtubeKeywords: 'Equations inequation premier degre troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1453733190148-c44698c265a8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 3. BEPC PC - Poids et Masse ---
  {
    id: 'bepc-pc-poids-masse',
    title: 'Poids et Masse d\'un corps',
    exam: 'BEPC',
    subject: 'Physique-Chimie',
    chapter: 'Mécanique',
    summary: 'Cette fiche distingue clairement la masse d\'un objet (quantité de matière, invariable) de son poids (force de gravité, variable).',
    content: `### 1. La Masse (m)
* **Définition** : Quantité de matière contenue dans un corps. Elle ne dépend pas du lieu où l'on se trouve.
* **Appareil de mesure** : Balance.
* **Unité légale** : Kilogramme (kg).

### 2. Le Poids (P)
* **Définition** : Force d'attraction gravitationnelle exercée par la Terre (ou un autre astre) sur un corps. Il varie selon le lieu (altitude, latitude).
* **Appareil de mesure** : Dynamomètre.
* **Unité légale** : Newton (N).

### 3. Relation fondamentale
Le poids et la masse sont proportionnels :
$$P = m \\times g$$
Où $g$ est l'intensité de la pesanteur en Newtons par kilogramme (N/kg). En Côte d'Ivoire, sa valeur moyenne est d'environ $g \\approx 9.8\\text{ N/kg}$ (ou $10\\text{ N/kg}$ pour simplifier les calculs).`,
    formulas: [
      'P = m × g',
      'm = P / g',
      'g = P / m'
    ],
    definitions: [
      { term: 'Pesanteur (g)', definition: 'Accélération d\'un corps en chute libre sous l\'effet de la force gravitationnelle.' },
      { term: 'Dynamomètre', definition: 'Instrument de mesure d\'une force, composé d\'un ressort calibré.' }
    ],
    youtubeKeywords: 'Poids et masse physique chimie classe de troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=600&auto=format&fit=crop&q=80'
  },
  // --- 4. BEPC PC - Courant alternatif ---
  {
    id: 'bepc-pc-courant',
    title: 'Intensité et Tension alternatives sinusoïdales',
    exam: 'BEPC',
    subject: 'Physique-Chimie',
    chapter: 'Électricité',
    summary: 'Comprendre le fonctionnement et les caractéristiques d\'un courant électrique alternatif à l\'aide de l\'oscilloscope.',
    content: `### 1. Qu\'est-ce qu\'une tension alternative ?
C'est une tension dont la valeur varie au cours du temps, alternativement positive et négative. Si sa courbe est une sinusoïde, elle est dite alternative sinusoïdale.

### 2. Caractéristiques fondamentales
* **Tension maximale ($U_{max}$)** : Valeur de la tension au sommet de la courbe (mesurée sur l'oscilloscope).
* **Tension efficace ($U_{eff}$)** : Valeur mesurée par un voltmètre en mode alternatif (AC).
* **Relation** :
$$U_{max} = U_{eff} \\times \\sqrt{2} \\approx U_{eff} \\times 1.414$$

### 3. Période (T) et Fréquence (f)
* **La Période (T)** : Durée du motif élémentaire qui se répète (en secondes).
* **La Fréquence (f)** : Nombre de périodes par seconde (en Hertz, Hz) :
$$f = \\frac{1}{T}$$`,
    formulas: [
      'U_max = U_eff × √2',
      'f = 1 / T (T en secondes, f en Hertz)'
    ],
    definitions: [
      { term: 'Oscilloscope', definition: 'Appareil de mesure électronique permettant de visualiser les variations d\'une tension en fonction du temps.' },
      { term: 'Fréquence', definition: 'Nombre de fois qu\'un phénomène périodique se reproduit par unité de temps.' }
    ],
    youtubeKeywords: 'tension alternative sinusoidale troisieme physique',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1517420712368-bf3a9437ff29?w=600&auto=format&fit=crop&q=80'
  },
  // --- 5. BEPC SVT - Digestion ---
  {
    id: 'bepc-svt-digestion',
    title: 'Digestion et Absorption intestinale chez l\'Homme',
    exam: 'BEPC',
    subject: 'SVT',
    chapter: 'Nutrition humaine',
    summary: 'Étude du trajet des aliments, de leurs transformations chimiques par les enzymes, et de leur passage dans la circulation générale.',
    content: `### 1. Les étapes de la digestion
La digestion comporte deux aspects :
* **La digestion mécanique** : Mastication dans la bouche, brassage dans l'estomac.
* **La digestion chimique** : Action des sucs digestifs contenant des enzymes qui découpent les macromolécules complexes en molécules simples appelées **nutriments**.

### 2. Rôle des Enzymes digestives
* **Salive (bouche)** : Amylase transforme l'amidon en maltose.
* **Suc gastrique (estomac)** : Protéases transforment les protéines en peptides.
* **Sucs pancréatique et intestinal (intestin grêle)** : Terminent la digestion en glucose, acides aminés, acides gras et glycérol.

### 3. L\'absorption intestinale
Les nutriments traversent la paroi de l'intestin grêle pour passer dans le sang et la lymphe. Cette paroi est optimisée grâce à des replis appelés **villosités intestinales**, qui offrent une surface d'échange gigantesque.`,
    formulas: [
      'Amidon + Amylase ➔ Maltose',
      'Protéines + Protéase ➔ Peptides ➔ Acides Aminés'
    ],
    definitions: [
      { term: 'Enzyme', definition: 'Catalyseur biologique (protéine) qui accélère les réactions chimiques de l\'organisme.' },
      { term: 'Nutriment', definition: 'Molécule simple issue de la digestion, directement assimilable par l\'organisme.' }
    ],
    youtubeKeywords: 'digestion et absorption intestinale svt troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=600&auto=format&fit=crop&q=80'
  },
  // --- 6. BEPC SVT - Reproduction ---
  {
    id: 'bepc-svt-reproduction',
    title: 'Puberté, Fécondation et Contraception',
    exam: 'BEPC',
    subject: 'SVT',
    chapter: 'Reproduction humaine',
    summary: 'Comprendre la puberté, le cycle menstruel, la fécondation, et les principales méthodes de planification familiale (contraception).',
    content: `### 1. La Puberté
Période de transition de l'enfance à l'adolescence caractérisée par l'apparition de caractères sexuels secondaires (voix, pilosité, développement des seins ou des testicules) et le démarrage de la fertilité (règles, premières éjaculations).

### 2. Le cycle menstruel et la Fécondation
* **Cycle menstruel** : Dure en moyenne 28 jours. L'ovulation se produit généralement au 14ème jour.
* **Fécondation** : Union d'un spermatozoïde et d'un ovule dans les trompes de Fallope, formant une cellule-œuf (zygote).

### 3. La Contraception
Ensemble des méthodes visant à éviter une grossesse non désirée :
* **Méthodes barrières** : Préservatifs (masculin/féminin, protègent aussi des IST/SIDA).
* **Méthodes hormonales** : Pilule contraceptive, implants, injectables.
* **Méthodes mécaniques** : Stérilet (DIU).`,
    formulas: [
      'Date Ovulation théorique = Durée du cycle - 14 jours',
      'Cellule-œuf = Spermatozoïde (n) + Ovule (n)'
    ],
    definitions: [
      { term: 'IST', definition: 'Infections Sexuellement Transmissibles (ex: VIH, hépatite B, syphilis).' },
      { term: 'Fécondation', definition: 'Fusion des noyaux de deux gamètes mâle et femelle pour donner une cellule unique.' }
    ],
    youtubeKeywords: 'reproduction humaine et contraception svt troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?w=600&auto=format&fit=crop&q=80'
  },
  // --- 7. BEPC Francais - Participe passé ---
  {
    id: 'bepc-francais-accords',
    title: 'L\'accord du participe passé',
    exam: 'BEPC',
    subject: 'Français',
    chapter: 'Grammaire et Orthographe',
    summary: 'Cette fiche présente les règles fondamentales d\'accord du participe passé selon l\'auxiliaire utilisé ou en l\'absence d\'auxiliaire.',
    content: `### 1. Participe passé employé sans auxiliaire
Employé comme un adjectif qualificatif, il s'accorde en genre et en nombre avec le nom auquel il se rapporte.
* *Exemple* : Des fleurs **fanées** (féminin pluriel).

### 2. Participe passé employé avec l'auxiliaire "ÊTRE"
Il s'accorde en genre et en nombre avec le sujet du verbe.
* *Exemple* : Elles sont **arrivées** hier soir (féminin pluriel).

### 3. Participe passé employé avec l'auxiliaire "AVOIR"
Il ne s'accorde **jamais** avec le sujet. Il s'accorde en genre et en nombre avec le **Complément d'Objet Direct (COD)** si et seulement si celui-ci est **placé avant** le verbe.
* *Exemple (pas d'accord)* : Nous avons **mangé** des pommes (le COD "des pommes" est après).
* *Exemple (accord)* : Les pommes que nous avons **mangées** (le COD "que", mis pour "les pommes", est placé avant).`,
    formulas: [
      'Avec Être : Accord avec le SUJET',
      'Avec Avoir : Accord avec le COD si placé AVANT le verbe'
    ],
    definitions: [
      { term: 'COD', definition: 'Complément d\'Objet Direct, répond à la question "qui ?" ou "quoi ?" posée après le verbe.' },
      { term: 'Auxiliaire', definition: 'Verbe (être ou avoir) servant à conjuguer les temps composés.' }
    ],
    youtubeKeywords: 'regles accord participe passe francais troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 8. BAC Maths - Suites ---
  {
    id: 'bac-maths-suites',
    title: 'Suites Arithmétiques et Géométriques',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Analyse',
    summary: 'Synthèse des définitions, formules générales de calcul et méthodes pour déterminer la limite d\'une suite numérique.',
    series: ['A', 'C', 'D'],
    content: `### 1. Les Suites Arithmétiques
Une suite $(u_n)$ est arithmétique s'il existe un réel $r$ (raison) tel que pour tout entier $n$ :
$$u_{n+1} = u_n + r$$
* **Terme général** : $u_n = u_0 + n \\times r$
* **Somme des termes** :
$$S = \\frac{(n+1)(u_0 + u_n)}{2}$$

### 2. Les Suites Géométriques
Une suite $(v_n)$ est géométrique s'il existe un réel $q$ (raison) tel que pour tout entier $n$ :
$$v_{n+1} = q \\times v_n$$
* **Terme général** : $v_n = v_0 \\times q^n$
* **Somme des termes** ($q \\neq 1$) :
$$S = v_0 \\times \\frac{1 - q^{n+1}}{1 - q}$$

### 3. Convergence des suites géométriques ($v_n = q^n$)
* Si $q > 1$, $\\lim_{n \\to +\\infty} q^n = +\\infty$ (Divergente)
* Si $-1 < q < 1$, $\\lim_{n \\to +\\infty} q^n = 0$ (Convergente)
* Si $q \\leq -1$, la suite n'a pas de limite.`,
    formulas: [
      'Arithmétique : u_n = u_p + (n-p)r',
      'Géométrique : v_n = v_p × q^(n-p)',
      'Somme géométrique : S = PremierTerme × (1 - q^NbrTermes)/(1 - q)'
    ],
    definitions: [
      { term: 'Suite numérique', definition: 'Fonction définie de l\'ensemble des entiers naturels N vers l\'ensemble des réels R.' },
      { term: 'Convergence', definition: 'Propriété d\'une suite d\'admettre une limite réelle finie lorsque n tend vers l\'infini.' }
    ],
    youtubeKeywords: 'suites numeriques terminale d cours',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80'
  },
  // --- 9. BAC Maths - Nombres Complexes ---
  {
    id: 'bac-maths-complexes',
    title: 'Nombres Complexes : Forme algébrique et trigonométrique',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Algèbre',
    summary: 'Découverte de l\'ensemble ℂ, écriture cartésienne, conjugué, module, argument et passage à la forme trigonométrique.',
    series: ['C', 'D'],
    content: `### 1. Forme Algébrique (Cartésienne)
Tout nombre complexe $z$ s'écrit de manière unique sous la forme :
$$z = x + iy$$
Où $x = \\text{Re}(z)$ est la partie réelle, $y = \\text{Im}(z)$ est la partie imaginaire, et $i$ est l'unité imaginaire vérifiant $i^2 = -1$.
* **Conjugué** : $\\bar{z} = x - iy$
* **Module** : $|z| = \\sqrt{x^2 + y^2}$

### 2. Forme Trigonométrique
Pour tout complexe non nul $z$ de module $r = |z|$ et d'argument $\\theta = \\arg(z) \\pmod{2\\pi}$ :
$$z = r(\\cos\\theta + i\\sin\\theta)$$
Avec :
$$\\cos\\theta = \\frac{x}{r} \\quad \\text{et} \\quad \\sin\\theta = \\frac{y}{r}$$

### 3. Écriture Exponentielle
Grâce à la formule d'Euler $e^{i\\theta} = \\cos\\theta + i\\sin\\theta$, on écrit plus simplement :
$$z = r e^{i\\theta}$$`,
    formulas: [
      'Module : |z| = √(x² + y²)',
      'Formule de Moivre : (cos θ + i sin θ)^n = cos(nθ) + i sin(nθ)',
      'Exponentielle : z × z\' = r r\' e^(i(θ + θ\'))'
    ],
    definitions: [
      { term: 'Nombre imaginaire pur', definition: 'Nombre complexe dont la partie réelle est nulle (z = iy).' },
      { term: 'Module', definition: 'Distance géométrique entre l\'origine du repère et le point image du complexe dans le plan complexe.' }
    ],
    youtubeKeywords: 'nombres complexes cours terminale d d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  // --- 10. BAC Maths - Probabilites ---
  {
    id: 'bac-maths-probabilites',
    title: 'Dénombrement et Probabilités conditionnelles',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Probabilités',
    summary: 'Rappels de combinatoire (combinaisons, arrangements) et formules fondamentales des probabilités totales et conditionnelles.',
    series: ['C', 'D'],
    content: `### 1. Analyse Combinatoire (Dénombrement)
Dans un ensemble à $n$ éléments :
* **Permutation** de $n$ éléments : $n! = n \\times (n-1) \\times \\dots \\times 1$
* **Arrangement** de $p$ éléments parmi $n$ :
$$A_n^p = \\frac{n!}{(n-p)!}$$
* **Combinaison** (sans ordre) de $p$ éléments parmi $n$ :
$$C_n^p = \\binom{n}{p} = \\frac{n!}{p!(n-p)!}$$

### 2. Probabilité Conditionnelle
La probabilité de l'événement $B$ sachant $A$ (avec $P(A) > 0$) est :
$$P_A(B) = P(B|A) = \\frac{P(A \\cap B)}{P(A)}$$

### 3. Formule des Probabilités Totales
Si $A_1, A_2, \\dots, A_k$ forment une partition de l'univers $\\Omega$ :
$$P(B) = \\sum_{i=1}^k P(B \\cap A_i) = \\sum_{i=1}^k P(A_i) \\times P(B|A_i)$$`,
    formulas: [
      'Combinaison : C(n,p) = n! / (p!(n-p)!)',
      'Indépendance : P(A ∩ B) = P(A) × P(B)',
      'Théorème de Bayes : P(A|B) = [P(B|A) × P(A)] / P(B)'
    ],
    definitions: [
      { term: 'Partition', definition: 'Ensemble de sous-événements disjoints deux à deux et dont la réunion forme l\'univers tout entier.' },
      { term: 'Dénombrement', definition: 'Technique mathématique consistant à compter le nombre d\'éléments dans un ensemble fini.' }
    ],
    youtubeKeywords: 'denombrement et probabilites cours terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80'
  },
  // --- 11. BAC PC - Dipole RC ---
  {
    id: 'bac-pc-condensateur',
    title: 'Étude du Dipôle RC : Charge et Décharge',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Électricité',
    summary: 'Comportement d\'un condensateur en série avec une résistance, équations différentielles de charge et de décharge, et constante de temps.',
    series: ['C', 'D'],
    content: `### 1. Le Condensateur
Composant électrique constitué de deux armatures conductrices séparées par un isolant (diélectrique). Il stocke des charges électriques :
$$q = C \\times u_C$$
Où $q$ est la charge (Coulombs), $C$ la capacité (Farads) et $u_C$ la tension (Volts). L'intensité s'exprime par :
$$i(t) = \\frac{dq}{dt} = C \\frac{du_C}{dt}$$

### 2. Équation différentielle lors de la Charge
En appliquant la loi des mailles à un circuit série comprenant un générateur de tension constante $E$, une résistance $R$ et un condensateur $C$ :
$$u_R + u_C = E \\Rightarrow R i + u_C = E \\Rightarrow RC \\frac{du_C}{dt} + u_C = E$$

### 3. Solution de l\'équation
La solution sous condition initiale $u_C(0) = 0$ est :
$$u_C(t) = E \\left(1 - e^{-\\frac{t}{\\tau}}\\right)$$
Où $\\tau = RC$ est la **constante de temps** du circuit (en secondes).
* Au bout de $t = \\tau$, le condensateur est chargé à **63%**.
* Au bout de $t = 5\\tau$, il est considéré comme entièrement chargé (**99%**).`,
    formulas: [
      'Relation charge-tension : q = C × u_C',
      'Constante de temps : τ = RC',
      'Solution décharge : u_C(t) = E × e^(-t/τ)'
    ],
    definitions: [
      { term: 'Diélectrique', definition: 'Matériau isolant placé entre les armatures d\'un condensateur pour augmenter sa capacité.' },
      { term: 'Loi des mailles', definition: 'Règle physique stipulant que la somme algébrique des tensions dans une maille fermée est nulle.' }
    ],
    youtubeKeywords: 'dipole rc physique terminale d d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1517420712368-bf3a9437ff29?w=600&auto=format&fit=crop&q=80'
  },
  // --- 12. BAC PC - Alcools ---
  {
    id: 'bac-pc-alcools',
    title: 'Les Alcools et leur Oxydation ménagée',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie Organique',
    summary: 'Structure des alcools, classification en trois groupes distincts et réactions chimiques d\'oxydation douce.',
    series: ['C', 'D'],
    content: `### 1. Structure et Nomenclature
Les alcools possèdent le groupe caractéristique **hydroxyle -OH** lié à un atome de carbone saturé. Formule brute générale des alcools saturés acycliques :
$$C_nH_{2n+2}O \\quad \\text{ou} \\quad R-OH$$

### 2. Classes d'alcools
La classe dépend du nombre d'atomes de carbone liés au carbone fonctionnel (portant le groupe -OH) :
* **Alcool Primaire** : Lié à 1 ou 0 carbone. Formule : $R-CH_2-OH$.
* **Alcool Secondaire** : Lié à 2 carbones. Formule : $R-CH(OH)-R'$.
* **Alcool Tertiaire** : Lié à 3 carbones. Formule : $R-C(OH)(R')-R''$.

### 3. Oxydation ménagée (douce)
L'oxydation n'altère pas la chaîne carbonée de départ. Elle s'effectue avec un oxydant comme les ions permanganate $MnO_4^-$ ou dichromate $Cr_2O_7^{2-}$.
* **Alcool primaire** ➔ Aldéhyde (test positif au réactif de Schiff / liqueur de Fehling) ➔ Acide carboxylique (pH < 7).
* **Alcool secondaire** ➔ Cétone (test positif à la DNPH, négatif à la liqueur de Fehling).
* **Alcool tertiaire** ➔ Pas d'oxydation ménagée possible (impossible sans casser la chaîne de carbone).`,
    formulas: [
      'Alcool Primaire ➔ Aldéhyde ➔ Acide Carboxylique',
      'Alcool Secondaire ➔ Cétone',
      'Alcool Tertiaire ➔ Pas de réaction d\'oxydation douce'
    ],
    definitions: [
      { term: 'Carbone fonctionnel', definition: 'Atome de carbone qui porte directement le groupe caractéristique fonctionnel (ici -OH).' },
      { term: 'Oxydation ménagée', definition: 'Réaction chimique d\'oxydation modérée respectant l\'intégrité du squelette carboné.' }
    ],
    youtubeKeywords: 'les alcools chimie terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?w=600&auto=format&fit=crop&q=80'
  },
  // --- 13. BAC PC - Newton Projectile ---
  {
    id: 'bac-pc-newton',
    title: 'Lois de Newton et Mouvement d\'un projectile',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Mécanique',
    summary: 'Application rigoureuse de la deuxième loi de Newton pour modéliser la trajectoire parabolique d\'un projectile lancé dans un champ uniforme.',
    series: ['C'],
    content: `### 1. La deuxième loi de Newton (Principe Fondamental)
Dans un référentiel galiléen, la somme des forces extérieures appliquées à un système est égale au produit de sa masse par le vecteur accélération :
$$\\sum \\vec{F}_{ext} = m \\vec{a}$$

### 2. Équations du mouvement d'un Projectile
Soit un projectile de masse $m$ lancé de l'origine avec une vitesse initiale $\\vec{v}_0$ faisant un angle $\\alpha$ avec l'horizontale. Soumis à son seul poids (chute libre), on a $\\sum \\vec{F} = \\vec{P} = m\\vec{g}$.
Par conséquent :
$$\\vec{a} = \\vec{g}$$

En projetant sur les axes d'un repère orthonormé $(Ox, Oy)$ vertical montant :
* **Accélération** : $a_x = 0$ et $a_y = -g$
* **Vitesse** : $v_x(t) = v_0 \\cos\\alpha$ et $v_y(t) = -gt + v_0 \\sin\\alpha$
* **Position** : $x(t) = (v_0 \\cos\\alpha)t$ et $y(t) = -\\frac{1}{2}gt^2 + (v_0 \\sin\\alpha)t$

### 3. Équation de la trajectoire
En éliminant le paramètre de temps $t$ dans les équations horaires, on obtient la parabole :
$$y(x) = -\\frac{g}{2 v_0^2 \\cos^2\\alpha} x^2 + (\\tan\\alpha) x$$`,
    formulas: [
      'Deuxième loi : ∑F_ext = m.a',
      'Équation horaire horizontale : x(t) = v_0.cos(α).t',
      'Portée : Distance x_p où le projectile retombe au sol (y = 0)'
    ],
    definitions: [
      { term: 'Référentiel galiléen', definition: 'Référentiel dans lequel le principe d\'inertie est vérifié.' },
      { term: 'Flèche', definition: 'Altitude maximale atteinte par le projectile au sommet de sa trajectoire.' }
    ],
    youtubeKeywords: 'mouvement d\'un projectile terminale c physique',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 14. BAC SVT - Reflexe Myotatique ---
  {
    id: 'bac-svt-reflexe',
    title: 'Le Réflexe Myotatique et la Transmission Synaptique',
    exam: 'BAC',
    subject: 'SVT',
    chapter: 'Neurophysiologie',
    summary: 'Analyse du mécanisme nerveux involontaire maintenant la posture du corps et l\'étude de la synapse chimique.',
    series: ['D'],
    content: `### 1. Définition
Le réflexe myotatique est la contraction involontaire d'un muscle en réponse à son propre étirement. C'est un réflexe inné, stéréotypé et monosynaptique.

### 2. L\'arc réflexe (Composants)
* **Récepteur** : Fuseau neuromusculaire (sensible à l'étirement du muscle).
* **Voie afférente** : Neurone sensoriel (en T ou de Ranvier) dont le corps cellulaire est dans le ganglion rachidien de la racine postérieure.
* **Centre nerveux** : Moelle épinière (substance grise).
* **Voie efférente** : Motoneurone de la corne antérieure.
* **Effecteur** : Plaques motrices sur le muscle.

### 3. Fonctionnement de la Synapse Neuromusculaire
C'est le point de contact chimique entre l'extrémité du motoneurone et la fibre musculaire :
1. Arrivée du Potentiel d'Action (PA) à la membrane pré-synaptique.
2. Entrée d'ions $Ca^{2+}$ déclenchant la libération de l'**Acétylcholine** (neurotransmetteur) par exocytose.
3. Fixation du neurotransmetteur sur des récepteurs spécifiques de la membrane post-synaptique.
4. Naissance d'un potentiel d'action musculaire conduisant à la contraction du muscle.`,
    formulas: [
      'Arc réflexe : Récepteur ➔ Voie Afférente ➔ Centre Moelle ➔ Voie Efférente ➔ Effecteur',
      'Neurotransmetteur clé : Acétylcholine'
    ],
    definitions: [
      { term: 'Exocytose', definition: 'Processus de libération de molécules chimiques à travers la membrane cellulaire d\'une vésicule.' },
      { term: 'Monosynaptique', definition: 'Circuit nerveux ne comprenant qu\'une seule synapse de jonction entre neurone sensoriel et neurone moteur.' }
    ],
    youtubeKeywords: 'le reflexe myotatique terminale d svt',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=600&auto=format&fit=crop&q=80'
  },
  // --- 15. BAC SVT - Genetique Humaine ---
  {
    id: 'bac-svt-genetique',
    title: 'Génétique Humaine et Hérédité',
    exam: 'BAC',
    subject: 'SVT',
    chapter: 'Génétique',
    summary: 'Méthodes d\'étude de la transmission des maladies génétiques héréditaires au sein des familles par l\'analyse des pedigrees.',
    series: ['D'],
    content: `### 1. Analyse d\'un arbre généalogique (Pédigree)
L'étude repose sur des symboles conventionnels (carrés pour les hommes, ronds pour les femmes, colorés pour les malades). Les questions fondamentales à se poser :
* **La maladie est-elle dominante ou récessive ?**
  * *Récessive* : Des parents sains ont des enfants malades (la maladie saute des générations).
  * *Dominante* : Chaque personne malade a au moins un de ses parents malade.
* **La maladie est-elle gonosomale (liée au sexe) ou autosomale (non liée) ?**
  * *Liée au chromosome Y* : Ne touche que les garçons, de père en fils sans exception.
  * *Récessive liée à X* : Touche majoritairement les garçons, nés de mères porteuses saines. Une fille malade a impérativement son père malade.

### 2. Échiquier de croisement et Probabilités
On utilise un tableau de croisement pour répertorier l'ensemble des gamètes possibles des deux parents et déterminer les risques pour les enfants à naître d'être porteurs sains, malades ou sains non porteurs.`,
    formulas: [
      'Allèle malade récessif : Noté "m" (dominant sain noté "S" ou "N")',
      'Chromosomes sexuels : Homme (XY), Femme (XX)'
    ],
    definitions: [
      { term: 'Autosome', definition: 'Tout chromosome non sexuel (22 paires chez l\'homme).' },
      { term: 'Génotype', definition: 'La constitution génétique précise d\'un individu pour un ou plusieurs gènes donnés.' },
      { term: 'Hétérozygote', definition: 'Individu possédant deux allèles différents pour un même gène (ex: N//m).' }
    ],
    youtubeKeywords: 'genetique humaine cours svt terminale d d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?w=600&auto=format&fit=crop&q=80'
  },
  // --- 16. BAC Philo - Conscience ---
  {
    id: 'bac-philo-conscience',
    title: 'La Conscience et l\'Inconscient',
    exam: 'BAC',
    subject: 'Philosophie',
    chapter: 'Le Sujet',
    summary: 'Étude critique de la subjectivité de l\'Homme à travers le doute cartésien, la perception morale et la révolution psychanalytique de Freud.',
    series: ['A', 'C', 'D'],
    content: `### 1. La Conscience : Définition et Soubassements
La conscience est la faculté de l'esprit humain à percevoir sa propre existence ainsi que le monde extérieur.
* **René Descartes et le Cogito** : Par l'expérience du doute méthodique, Descartes affirme la primauté de la conscience de soi comme fondement de la vérité :
> *"Je pense, donc je suis"* (Cogito ergo sum).
* **Emmanuel Kant** : Il montre que la conscience permet l'unité de nos représentations et fonde le sujet moral autonome.

### 2. Les limites de la Conscience : La découverte de l'Inconscient
La conscience n'est pas maîtresse absolue de l'esprit humain.
* **Spinoza** : L'homme est souvent ignorant des causes réelles qui le déterminent à agir :
> *"Les hommes se croient libres parce qu'ils sont conscients de leurs désirs mais ignorants des causes qui les déterminent."*
* **Sigmund Freud et la Psychanalyse** : Freud introduit la théorie de la personnalité psychique scindée en trois instances :
  * **Le Ça** : Le siège des pulsions refoulées inconscientes.
  * **Le Surmoi** : L'intériorisation des interdits moraux et sociaux.
  * **Le Moi** : Médiateur conscient essayant d'équilibrer les exigences du Ça et du Surmoi.`,
    formulas: [
      'Cogito cartésien : Doute systématique ➔ Certitude de la pensée ➔ Preuve de l\'existence',
      'Première topique freudienne : Conscient / Préconscient / Inconscient'
    ],
    definitions: [
      { term: 'Refoulement', definition: 'Mécanisme de défense inconscient écartant de la conscience les désirs ou souvenirs jugés inacceptables par le Surmoi.' },
      { term: 'Subjectivité', definition: 'Caractère de ce qui appartient en propre au sujet pensant, par opposition à l\'objectivité du monde physique.' }
    ],
    youtubeKeywords: 'la conscience et l inconscient philosophie terminale',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 17. BAC HG - Economie CI ---
  {
    id: 'bac-hg-economie-ci',
    title: 'L\'Économie de la Côte d\'Ivoire depuis 1960',
    exam: 'BAC',
    subject: 'Histoire-Géographie',
    chapter: 'Géographie Économique',
    summary: 'Analyse des forces, faiblesses et mutations structurelles de l\'économie ivoirienne, du "miracle" agricole aux défis industriels actuels.',
    series: ['A', 'C', 'D'],
    content: `### 1. Le "Miracle Ivoirien" (1960-1980)
Fondé sur le développement spectaculaire du secteur agricole sous l'impulsion du président Félix Houphouët-Boigny :
* La Côte d'Ivoire devient le **premier producteur mondial de cacao** et l'un des premiers producteurs de café.
* Politique d'ouverture aux capitaux étrangers et création d'infrastructures majeures (port autonome d'Abidjan, barrage de Kossou).

### 2. La crise des années 1980-1990
* **Causes** : Effondrement des cours mondiaux des matières premières agricoles, surendettement de l'État, dévaluation du Franc CFA en 1994.
* **Conséquences** : Programmes d'Ajustement Structurel (PAS) imposés par la Banque Mondiale et le FMI entraînant une réduction des dépenses publiques de santé et d'éducation.

### 3. L'économie ivoirienne contemporaine
Depuis 2012, la Côte d'Ivoire connaît une forte croissance de son PIB (environ 7 à 8% par an en moyenne) grâce à :
* De grands chantiers publics d'infrastructures (ponts, routes, électrification rurale).
* La recherche de la transformation locale du cacao (valorisation industrielle).
* Les défis majeurs : la réduction de la pauvreté, la création d'emplois durables pour les jeunes et la lutte contre l'économie informelle.`,
    formulas: [
      'Piliers économiques : Secteur Primaire (Agriculture d\'exportation) + Services (Hub bancaire d\'Abidjan)',
      'Défi majeur : Passer de l\'exportation brute de fèves de cacao à leur transformation en chocolat local'
    ],
    definitions: [
      { term: 'PIB', definition: 'Produit Intérieur Brut, indicateur économique mesurant la richesse créée par un pays en une année.' },
      { term: 'Secteur informel', definition: 'Ensemble des activités économiques qui échappent au contrôle de l\'administration et à la fiscalité de l\'État.' }
    ],
    youtubeKeywords: 'economie de la cote d\'ivoire terminale histoire geo',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 18. Concours CG - Colonisation ---
  {
    id: 'concours-cg-colonisation',
    title: 'La colonisation et la marche vers l\'indépendance de la Côte d\'Ivoire',
    exam: 'Concours',
    subject: 'Culture Générale',
    chapter: 'Histoire',
    summary: 'Les repères historiques majeurs de l\'établissement du protectorat français jusqu\'à la proclamation de l\'indépendance le 7 août 1960.',
    content: `### 1. La pénétration coloniale
* **1843** : Traités signés par la France avec les rois de Grand-Bassam et d'Assinie, marquant les débuts des comptoirs commerciaux.
* **10 mars 1893** : Décret créant officiellement la colonie de Côte d'Ivoire, avec pour première capitale **Grand-Bassam**.
* **Résistances armées** : Résistance opiniâtre de l'empereur Samory Touré dans le nord et révoltes des peuples Abbey et Baoulé (pacification menée par le gouverneur Angoulvant).

### 2. Évolutions administratives et politiques
* **1900** : Transfert de la capitale à Bingerville (suite à une épidémie de fièvre jaune à Grand-Bassam).
* **1934** : Abidjan devient la troisième capitale officielle du pays.
* **1944** : Fondation du Syndicat Agricole Africain (SAA) par Félix Houphouët-Boigny pour lutter contre le travail forcé et l'exploitation coloniale.
* **1946** : Création du Parti Démocratique de Côte d'Ivoire (PDCI-RDA).

### 3. L'accession à la souveraineté nationale
* **1956** : Promulgation de la Loi-cadre Defferre accordant l'autonomie interne.
* **7 août 1960** : Proclamation solennelle de l'indépendance nationale par Félix Houphouët-Boigny, qui devient le premier Président de la République.`,
    formulas: [
      'Création Colonie : 10 mars 1893 (Capitale Grand-Bassam)',
      'Indépendance : 7 août 1960 (Félix Houphouët-Boigny)'
    ],
    definitions: [
      { term: 'Travail forcé', definition: 'Système d\'exploitation colonial réquisitionnant de la main-d\'œuvre locale non rémunérée pour des chantiers d\'intérêt public.' },
      { term: 'Loi-cadre', definition: 'Réforme juridique française de 1956 transférant d\'importants pouvoirs exécutifs aux territoires d\'outre-mer.' }
    ],
    youtubeKeywords: 'histoire coloniale et independance de la cote d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 19. Concours CG - Organisation judiciaire ---
  {
    id: 'concours-cg-justice',
    title: 'L\'organisation du système judiciaire ivoirien',
    exam: 'Concours',
    subject: 'Culture Générale',
    chapter: 'Institutions et Droit',
    summary: 'Présentation de la hiérarchie des tribunaux et des cours de justice en Côte d\'Ivoire, ainsi que des principes fondamentaux du droit ivoirien.',
    content: `### 1. Les Principes Directeurs de la Justice
La justice en Côte d'Ivoire repose sur plusieurs grands principes constitutionnels :
* **La gratuité de la justice** (les juges sont payés par l'État, les plaideurs ne paient pas le tribunal).
* **Le double degré de juridiction** (droit de faire appel d'une décision de première instance).
* **La collégialité** (les affaires importantes sont jugées par un collège de magistrats).
* **La séparation des pouvoirs** (indépendance du pouvoir judiciaire vis-à-vis des pouvoirs exécutif et législatif).

### 2. La structure des juridictions
L'organisation est pyramidale et se divise en deux ordres majeurs depuis la réforme :
* **Juridictions du premier degré** :
  * Les Tribunaux de Première Instance (TPI) et leurs sections détachées (gèrent les litiges civils, correctionnels et commerciaux de base).
  * Les tribunaux du travail.
* **Juridictions du second degré** :
  * Les Cours d'Appel (réexaminent les décisions des tribunaux de première instance contestées par un appel).
* **Les Juridictions Supérieures (Cour Suprême)** :
  * **La Cour de Cassation** : Vérifie la bonne application de la loi par les cours d'appel (juge le droit, pas les faits).
  * **Le Conseil d'État** : Juge suprême des recours administratifs (litiges citoyens/État).
  * **La Cour des Comptes** : Contrôle la gestion des finances publiques de la nation.`,
    formulas: [
      'Juridiction Premier Degré (TPI) ➔ Second Degré (Cour d\'Appel) ➔ Cour Suprême (Cassation)',
      'Arbitre suprême des lois : Conseil Constitutionnel'
    ],
    definitions: [
      { term: 'Magistrat du siège', definition: 'Juge indépendant chargé de trancher les litiges et de prononcer les sentences, assis au tribunal.' },
      { term: 'Ministère Public', definition: 'Magistrats debout (procureurs) chargés de défendre l\'intérêt général et l\'ordre public lors des procès.' }
    ],
    youtubeKeywords: 'organisation judiciaire en cote d\'ivoire',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80'
  },
  // --- 20. Concours CG - CEDEAO ---
  {
    id: 'concours-cg-cedeao',
    title: 'La CEDEAO : Objectifs, Institutions et Intégration',
    exam: 'Concours',
    subject: 'Culture Générale',
    chapter: 'Géopolitique',
    summary: 'Synthèse géopolitique sur la Communauté Économique des États de l\'Afrique de l\'Ouest, son histoire, ses réussites et ses crises actuelles.',
    content: `### 1. Historique et Création
La **CEDEAO** (Communauté Économique des États de l'Afrique de l'Ouest) a été créée le **28 mai 1975** par la signature du Traité de Lagos (Nigeria). Son siège exécutif est situé à **Abuja** (Nigeria). Elle regroupe initialement 15 pays de la sous-région ouest-africaine.

### 2. Objectifs fondamentaux
L'objectif principal est de promouvoir l'intégration économique, sociale, culturelle et politique des États membres :
* Création d'un marché commun régional (union douanière, abolition progressive des barrières douanières).
* Libre circulation des personnes (suppression des visas pour les ressortissants de la zone), des biens et des capitaux.
* Coopération sécuritaire : Mise en place d'une force de maintien de la paix (ECOMOG) intervenant dans les conflits régionaux (Liberia, Sierra Leone, etc.).

### 3. Organes et Institutions clés
* **La Conférence des Chefs d\'État et de Gouvernement** : Organe décisionnel suprême, dirigé par un président en exercice élu chaque année.
* **La Commission de la CEDEAO** : Organe exécutif chargé de la gestion quotidienne de l'organisation.
* **Le Parlement de la CEDEAO** et **La Cour de Justice de la Communauté**.

### 4. Défis contemporains
* **Sécurité** : Lutte contre le terrorisme et le grand banditisme transfrontalier dans le Sahel.
* **Monnaie** : Le projet de monnaie unique régionale, l\'**Eco**, régulièrement repoussé.
* **Stabilité politique** : Crises liées aux changements inconstitutionnels de régime (coups d'État militaires) ayant conduit à la suspension temporaire ou aux velléités de retrait de certains pays membres (Mali, Burkina Faso, Niger).`,
    formulas: [
      'Création : 28 mai 1975 (Traité de Lagos)',
      'Siège : Abuja, Nigeria',
      'Principe clé : Libre circulation des personnes et des biens (Passeport CEDEAO)'
    ],
    definitions: [
      { term: 'Intégration régionale', definition: 'Processus par lequel plusieurs pays conviennent d\'harmoniser leurs politiques douanières, économiques ou sociales.' },
      { term: 'ECOMOG', definition: 'Brigade de surveillance et de maintien de la paix créée par la CEDEAO en 1990.' }
    ],
    youtubeKeywords: 'la cedeao geopolitique afrique de l\'ouest',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 21. BEPC Trigonometrie ---
  {
    id: 'bepc-maths-trigo',
    title: 'Trigonométrie dans le triangle rectangle',
    exam: 'BEPC',
    subject: 'Mathématiques',
    chapter: 'Géométrie',
    summary: 'Rapports trigonométriques (cosinus, sinus, tangente) dans un triangle rectangle pour calculer des angles et des longueurs.',
    content: `### 1. Définition des rapports trigonométriques
Dans un triangle rectangle, pour un angle aigu $\\widehat{A}$ :
* **Cosinus** : $\\cos(\\widehat{A}) = \\frac{\\text{Côté adjacent}}{\\text{Hypoténuse}}$
* **Sinus** : $\\sin(\\widehat{A}) = \\frac{\\text{Côté opposé}}{\\text{Hypoténuse}}$
* **Tangente** : $\\tan(\\widehat{A}) = \\frac{\\text{Côté opposé}}{\\text{Côté adjacent}}$

### 2. Relations fondamentales
Pour tout angle aigu $x$ :
$$\\cos^2(x) + \\sin^2(x) = 1$$
$$\\tan(x) = \\frac{\\sin(x)}{\\cos(x)}$$`,
    formulas: [
      'SOH-CAH-TOA : Sin=Opp/Hyp, Cos=Adj/Hyp, Tan=Opp/Adj',
      'cos²(x) + sin²(x) = 1'
    ],
    definitions: [
      { term: 'Adjacent', definition: 'Côté du triangle qui touche l\'angle étudié mais n\'est pas l\'hypoténuse.' },
      { term: 'Opposé', definition: 'Côté du triangle qui fait face à l\'angle étudié.' }
    ],
    youtubeKeywords: 'Trigonometrie classe de troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  // --- 22. BEPC Fonctions ---
  {
    id: 'bepc-maths-fonctions',
    title: 'Applications affines et linéaires',
    exam: 'BEPC',
    subject: 'Mathématiques',
    chapter: 'Algèbre',
    summary: 'Définitions, représentations graphiques et caractéristiques des applications linéaires et affines.',
    content: `### 1. Application linéaire
Une application linéaire est de la forme $f(x) = ax$. Elle modélise une situation de **proportionnalité**. Sa représentation graphique est une droite passant par l'origine.

### 2. Application affine
Une application affine est de la forme $f(x) = ax + b$, où $a$ est le coefficient directeur et $b$ l'ordonnée à l'origine. Sa représentation graphique est une droite.`,
    formulas: [
      'Linéaire : f(x) = ax',
      'Affine : f(x) = ax + b',
      'Coefficient directeur : a = (f(x2) - f(x1)) / (x2 - x1)'
    ],
    definitions: [
      { term: 'Ordonnée à l\'origine', definition: 'Point d\'intersection de la droite représentative avec l\'axe des ordonnées (valeur b).' },
      { term: 'Proportionnalité', definition: 'Rapport constant entre deux grandeurs.' }
    ],
    youtubeKeywords: 'fonctions affines et lineaires troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1453733190148-c44698c265a8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 23. BEPC Hydrocarbures ---
  {
    id: 'bepc-pc-hydrocarbures',
    title: 'Les alcanes et alcènes : Combustion du butane',
    exam: 'BEPC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie Organique',
    summary: 'Formules chimiques des hydrocarbures simples et réactions de combustion complète et incomplète.',
    content: `### 1. Alcanes et Alcènes
* **Alcanes** : Hydrocarbures saturés de formule générale $C_nH_{2n+2}$ (Méthane $CH_4$, Éthane $C_2H_6$, Propane $C_3H_8$, Butane $C_4H_{10}$).
* **Alcènes** : Hydrocarbures insaturés contenant une double liaison de formule générale $C_nH_{2n}$ (Éthylène $C_2H_4$).

### 2. Combustion complète du butane
En présence d'un excès de dioxygène, le butane brûle avec une flamme bleue en produisant du dioxyde de carbone et de l'eau :
$$2C_4H_{10} + 13O_2 \\rightarrow 8CO_2 + 10H_2O$$`,
    formulas: [
      'Alcane : C_n H_2n+2',
      'Alcène : C_n H_2n',
      'Combustion : Hydrocarbure + O₂ ➔ CO₂ + H₂O'
    ],
    definitions: [
      { term: 'Hydrocarbure', definition: 'Composé organique constitué uniquement d\'atomes de carbone et d\'hydrogène.' },
      { term: 'Combustion complète', definition: 'Réaction avec excès d\'oxygène produisant CO2 et H2O sans résidu de carbone.' }
    ],
    youtubeKeywords: 'combustion des hydrocarbures physique chimie troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=600&auto=format&fit=crop&q=80'
  },
  // --- 24. BEPC Optique ---
  {
    id: 'bepc-pc-optique',
    title: 'Lentilles convergentes et formation d\'images',
    exam: 'BEPC',
    subject: 'Physique-Chimie',
    chapter: 'Optique',
    summary: 'Caractéristiques des lentilles minces convergentes, foyers, distance focale et construction géométrique d\'une image.',
    content: `### 1. Lentille convergente
Une lentille convergente est plus épaisse au centre qu'aux bords. Elle dévie les rayons parallèles vers un point unique appelé **foyer principal image F\'**.

### 2. Caractéristiques
* **Centre optique O** : Les rayons passant par O ne sont pas déviés.
* **Distance focale f** : Distance entre le centre optique et le foyer image : $f = OF\'$.
* **Vergence C** : Aptitude à faire converger les rayons :
$$C = \\frac{1}{f} \\quad \\text{(en Dioptries } \\delta\\text{)}$$`,
    formulas: [
      'Vergence : C = 1 / f (f en mètres, C en dioptries)',
      'Grandissement : γ = OA\' / OA = A\'B\' / AB'
    ],
    definitions: [
      { term: 'Foyer', definition: 'Point où convergent les rayons de lumière après avoir traversé la lentille.' },
      { term: 'Dioptrie', definition: 'Unité de mesure de la vergence d\'un système optique.' }
    ],
    youtubeKeywords: 'lentilles convergentes physique classe de troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1517420712368-bf3a9437ff29?w=600&auto=format&fit=crop&q=80'
  },
  // --- 25. BEPC SVT Milieux ---
  {
    id: 'bepc-svt-milieux',
    title: 'Écosystèmes et protection de la biodiversité',
    exam: 'BEPC',
    subject: 'SVT',
    chapter: 'Écologie',
    summary: 'Étude des relations trophiques au sein d\'un écosystème et des actions de sauvegarde environnementale en Côte d\'Ivoire.',
    content: `### 1. Composants d'un Écosystème
Un écosystème associe la **biocénose** (êtres vivants) et le **biotope** (milieu physique).
* **Producteurs** : Végétaux chlorophylliens (autotrophes).
* **Consommateurs** : Animaux herbivores et carnivores (hétérotrophes).
* **Décomposeurs** : Champignons et bactéries recyclant la matière organique.

### 2. Chaînes et réseaux trophiques
Relations alimentaires liant les espèces d'un écosystème. La rupture d'un maillon menace la survie de tout le réseau.`,
    formulas: [
      'Écosystème = Biotope + Biocénose',
      'Chaîne trophique : Producteur ➔ Consommateur I ➔ Consommateur II'
    ],
    definitions: [
      { term: 'Biocénose', definition: 'Ensemble des êtres vivants cohabitant dans un espace écologique défini.' },
      { term: 'Biotope', definition: 'Milieu de vie caractérisé par des conditions physiques et chimiques constantes.' }
    ],
    youtubeKeywords: 'ecosysteme et protection de la nature troisieme svt',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=600&auto=format&fit=crop&q=80'
  },
  // --- 26. BEPC SVT Immunologie ---
  {
    id: 'bepc-svt-immuno',
    title: 'Le système immunitaire et la réponse humorale',
    exam: 'BEPC',
    subject: 'SVT',
    chapter: 'Immunologie',
    summary: 'Comprendre comment le corps se défend contre les infections par la production d\'anticorps spécifiques.',
    content: `### 1. Barrières naturelles et Infection
La peau et les muqueuses bloquent l'intrusion des microbes. En cas de blessure, la réaction inflammatoire locale se met en place (rougeur, chaleur, gonflement).

### 2. Réponse Immunitaire Spécifique Humorale
Fait intervenir les **lymphocytes B** qui reconnaissent un antigène spécifique et se multiplient pour sécréter des **anticorps**. Les anticorps se lient aux antigènes pour former un complexe immun, neutralisant ainsi le pathogène.`,
    formulas: [
      'Complexe Immun = Antigène + Anticorps Spécifique',
      'Acteurs : Lymphocytes B ➔ Plasmocytes ➔ Anticorps'
    ],
    definitions: [
      { term: 'Antigène', definition: 'Substance étrangère à l\'organisme capable de déclencher une réponse immunitaire.' },
      { term: 'Anticorps', definition: 'Protéine hautement spécifique sécrétée par les plasmocytes pour neutraliser un antigène.' }
    ],
    youtubeKeywords: 'le systeme immunitaire svt troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?w=600&auto=format&fit=crop&q=80'
  },
  // --- 27. BEPC Figures de Style ---
  {
    id: 'bepc-francais-figures',
    title: 'Les figures de style indispensables',
    exam: 'BEPC',
    subject: 'Français',
    chapter: 'Grammaire et Orthographe',
    summary: 'Savoir repérer et analyser les principales figures d\'analogie, d\'insistance et d\'atténuation pour les rédactions littéraires.',
    content: `### 1. Figures d'analogie
* **Comparaison** : Rapproche deux éléments à l'aide d'un outil de comparaison (comme, tel que, semblable à).
* **Métaphore** : Comparaison directe sans mot-outil.
* **Personnification** : Attribuer des traits humains à un objet ou un animal.

### 2. Figures d'insistance et d'atténuation
* **Hyperbole** : Exagération forte pour frapper l'esprit.
* **Euphémisme** : Atténuation d'une réalité brutale ou triste (ex : "Il nous a quittés" au lieu de "Il est mort").`,
    formulas: [
      'Comparaison = Comparé + Comparant + Outil de comparaison',
      'Métaphore = Comparaison sans outil de comparaison'
    ],
    definitions: [
      { term: 'Métaphore', definition: 'Procédé stylistique consistant à assimiler une idée à une image sans terme comparatif.' },
      { term: 'Hyperbole', definition: 'Figure consistant à employer des termes excessifs pour amplifier une idée.' }
    ],
    youtubeKeywords: 'les figures de style cours de troisieme',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 28. BEPC Anglais ---
  {
    id: 'bepc-anglais-tenses',
    title: 'Present Perfect vs Past Simple',
    exam: 'BEPC',
    subject: 'Anglais',
    chapter: 'Grammar',
    summary: 'Mastering the difference between actions connected to the present and fully completed past events.',
    content: `### 1. The Present Perfect
Used for actions that started in the past and continue in the present, or past actions with a visible result in the present.
* **Structure** : Have/Has + Past Participle
* **Keywords** : Since, for, already, yet, never, ever.
* *Example* : I **have lived** in Abidjan for 5 years. (I still live there).

### 2. The Past Simple
Used for completed actions at a specific time in the past.
* **Structure** : Regular verb + ed / Irregular form
* **Keywords** : Yesterday, ago, last week, in 1960.
* *Example* : I **visited** Yamoussoukro last year. (Completed past action).`,
    formulas: [
      'Present Perfect = Subject + Have/Has + Verb (V3)',
      'Past Simple = Subject + Verb-ed (or Irregular V2)'
    ],
    definitions: [
      { term: 'Unspecified time', definition: 'Time that is not clearly stated, associated with the Present Perfect.' },
      { term: 'Irregular Verb', definition: 'A verb that does not follow the standard -ed pattern in the past tense.' }
    ],
    youtubeKeywords: 'present perfect versus simple past grammar english',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 29. BAC Maths Exponentielle ---
  {
    id: 'bac-maths-expo',
    title: 'La fonction Exponentielle',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Analyse',
    summary: 'Définition, limites, dérivée, et propriétés de la fonction exponentielle de base e.',
    series: ['A', 'C', 'D'],
    content: `### 1. Définition de la fonction exponentielle
La fonction exponentielle, notée $\\exp$ ou $e^x$, est la bijection réciproque de la fonction logarithme népérien $\\ln$. Elle est strictement positive sur $\\mathbb{R}$.
$$\\ln(e^x) = x \\quad \\text{et} \\quad e^{\\ln(y)} = y \\text{ pour } y > 0$$

### 2. Propriétés algébriques
Pour tous réels $a$ et $b$ :
* $e^{a+b} = e^a \\times e^b$
* $e^{-a} = \\frac{1}{e^a}$
* $e^{a-b} = \\frac{e^a}{e^b}$
* $(e^a)^n = e^{na}$

### 3. Limites de référence et dérivabilité
* $\\lim_{x \\to -\\infty} e^x = 0$ (asymptote horizontale)
* $\\lim_{x \\to +\\infty} e^x = +\\infty$
* **Dérivée** : $(e^x)' = e^x$. De manière générale, $(e^{u})' = u' e^u$.`,
    formulas: [
      'e^(a+b) = e^a × e^b',
      'Dérivée : (e^u)\' = u\' × e^u',
      'Limites : lim (x->+∞) e^x/x = +∞'
    ],
    definitions: [
      { term: 'Réciproque', definition: 'Fonction inversant les rôles des variables de départ et d\'arrivée.' },
      { term: 'Asymptote horizontale', definition: 'Droite d\'équation y = L vers laquelle la courbe tend aux infinis.' }
    ],
    youtubeKeywords: 'fonction exponentielle terminale d cours',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80'
  },
  // --- 30. BAC Maths Probabilites Variables ---
  {
    id: 'bac-maths-variables',
    title: 'Variables aléatoires et loi binomiale',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Probabilités',
    summary: 'Définir une loi de probabilité pour une variable aléatoire, calculer l\'espérance, et appliquer la loi binomiale.',
    series: ['C', 'D'],
    content: `### 1. Variable Aléatoire Réelle
Une variable aléatoire $X$ est une fonction qui associe un réel à chaque issue de l'univers $\\Omega$.
* **Espérance mathématique** : Moyenne théorique pondérée :
$$E(X) = \\sum x_i P(X = x_i)$$
* **Variance** : Mesure de la dispersion :
$$V(X) = E(X^2) - [E(X)]^2$$

### 2. Loi Binomiale $\\mathcal{B}(n, p)$
Modélise la répétition de $n$ épreuves de Bernoulli identiques et indépendantes n'ayant que deux issues possibles (Succès avec probabilité $p$, Échec avec $q = 1-p$).
$$P(X = k) = \\binom{n}{k} p^k (1-p)^{n-k}$$`,
    formulas: [
      'Espérance Binomiale : E(X) = n × p',
      'Variance Binomiale : V(X) = n × p × (1-p)',
      'Loi Binomiale : P(X = k) = C(n,k) × p^k × (1-p)^(n-k)'
    ],
    definitions: [
      { term: 'Épreuve de Bernoulli', definition: 'Expérience aléatoire comportant exactement deux issues possibles.' },
      { term: 'Espérance', definition: 'Moyenne arithmétique à long terme des résultats de la variable aléatoire.' }
    ],
    youtubeKeywords: 'loi binomiale et variable aleatoire terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80'
  },
  // --- 31. BAC Maths Espace ---
  {
    id: 'bac-maths-espace',
    title: 'Géométrie dans l\'espace : Produit vectoriel',
    exam: 'BAC',
    subject: 'Mathématiques',
    chapter: 'Géométrie',
    summary: 'Calcul du produit vectoriel de deux vecteurs, propriétés, et obtention d\'une équation de plan dans l\'espace.',
    series: ['C'],
    content: `### 1. Produit vectoriel dans l'espace
Le produit vectoriel de deux vecteurs $\\vec{u}$ et $\\vec{v}$, noté $\\vec{u} \\wedge \\vec{v}$, est un vecteur orthogonal à $\\vec{u}$ et $\\vec{v}$ formant un repère direct.
* **Coordonnées** : Si $\\vec{u}(x, y, z)$ et $\\vec{v}(x', y', z')$ :
$$\\vec{u} \\wedge \\vec{v} = \\begin{pmatrix} yz' - zy' \\\\ zx' - xz' \\\\ xy' - yx' \\end{pmatrix}$$

### 2. Équation cartésienne de Plan
Un plan de vecteur normal $\\vec{n}(a, b, c)$ passant par $A(x_A, y_A, z_A)$ a pour équation :
$$a(x-x_A) + b(y-y_A) + c(z-z_A) = 0 \\Rightarrow ax + by + cz + d = 0$$`,
    formulas: [
      'Produit vectoriel orthogonal à u et v',
      'Équation de plan : ax + by + cz + d = 0 avec n(a,b,c)'
    ],
    definitions: [
      { term: 'Orthogonal', definition: 'Vecteurs ou droites perpendiculaires dans l\'espace tri-dimensionnel.' },
      { term: 'Vecteur normal', definition: 'Vecteur non nul perpendiculaire à tous les vecteurs directeurs d\'un plan.' }
    ],
    youtubeKeywords: 'produit vectoriel equation de plan terminale c',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
  },
  // --- 32. BAC PC Acides Faibles ---
  {
    id: 'bac-pc-acides-faibles',
    title: 'Acides forts/faibles et pH des solutions',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie des solutions',
    summary: 'Distinguer les acides forts des acides faibles, définir la constante d\'acidité Ka et calculer le pH d\'une solution aqueuse.',
    series: ['C', 'D'],
    content: `### 1. Acide Fort vs Acide Faible
* **Acide Fort** : Se dissocie totalement dans l'eau (ex : Acide chlorhydrique $HCl$). Sa réaction est irreversible.
* **Acide Faible** : Se dissocie partiellement dans l'eau (ex : Acide éthanoïque $CH_3COOH$). Sa réaction est un équilibre réversible.

### 2. Constante d'acidité $K_a$ et $pK_a$
Pour un couple acide/base $AH / A^-$ :
$$K_a = \\frac{[A^-]_{eq} \\cdot [H_3O^+]_{eq}}{[AH]_{eq}}$$
$$pK_a = -\\log(K_a)$$

### 3. Formules de calcul du pH
* Acide fort : $pH = -\\log(C)$
* Acide faible : $pH = \\frac{1}{2}(pK_a - \\log(C))$`,
    formulas: [
      'pH Acide Fort = -log(C)',
      'pH Acide Faible = 1/2 (pKa - log(C))',
      'Relation Henderson : pH = pKa + log([A⁻]/[AH])'
    ],
    definitions: [
      { term: 'Dissociation', definition: 'Processus de séparation des ions ou molécules d\'un composé lors de sa dissolution.' },
      { term: 'Équilibre chimique', definition: 'État d\'un système réactionnel où les réactions directe et inverse se produisent à vitesse égale.' }
    ],
    youtubeKeywords: 'acides bases et constantes d acidite terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=600&auto=format&fit=crop&q=80'
  },
  // --- 33. BAC PC Kepler ---
  {
    id: 'bac-pc-satellites',
    title: 'Mouvement des satellites et lois de Kepler',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Mécanique',
    summary: 'Application de la loi de gravitation de Newton aux orbites circulaires, vitesses orbitales et démonstration des trois lois de Kepler.',
    series: ['C'],
    content: `### 1. Les trois lois de Kepler
* **1ère Loi (Loi des orbites)** : Les orbites des planètes sont des ellipses dont le Soleil occupe l'un des foyers.
* **2ème Loi (Loi des aires)** : Le rayon Soleil-Planète balaie des aires égales en des temps égaux.
* **3ème Loi (Loi des périodes)** : Le carré de la période de révolution $T^2$ est proportionnel au cube du demi-grand axe $a^3$ :
$$\\frac{T^2}{a^3} = \\text{constante}$$

### 2. Vitesse orbitale d'un satellite circulaire
En égalant la force d'attraction gravitationnelle de Newton et la force centripète d'un mouvement circulaire uniforme :
$$v = \\sqrt{\\frac{G \\cdot M_{Terre}}{r}}$$`,
    formulas: [
      'Troisième loi : T² / r³ = 4π² / (G.M)',
      'Vitesse orbitale : v = √(G.M / r)'
    ],
    definitions: [
      { term: 'Force centripète', definition: 'Force contraignant un corps à suivre une trajectoire courbe ou circulaire.' },
      { term: 'Satellite géostationnaire', definition: 'Satellite restant fixe au-dessus d\'un point de l\'équateur (période T = 24h).' }
    ],
    youtubeKeywords: 'lois de kepler et mouvement des satellites physique terminale',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 34. BAC PC Esters ---
  {
    id: 'bac-pc-esters',
    title: 'Estérification et Hydrolyse des esters',
    exam: 'BAC',
    subject: 'Physique-Chimie',
    chapter: 'Chimie Organique',
    summary: 'Mécanisme de formation des esters à partir d\'un acide carboxylique et d\'un alcool, et réaction inverse d\'hydrolyse.',
    series: ['C', 'D'],
    content: `### 1. La réaction d'estérification
La réaction entre un acide carboxylique et un alcool produit un **ester** et de l'**eau** :
$$\\text{Acide} + \\text{Alcool} \\rightleftharpoons \\text{Ester} + \\text{Eau}$$
* **Caractéristiques** : Réaction lente, athermique et limitée par la réaction inverse de l'hydrolyse.

### 2. Rendement d'estérification
Le rendement dépend de la classe de l'alcool utilisé dans le mélange équimolaire :
* Alcool primaire : Rendement d'environ **67%**.
* Alcool secondaire : Rendement d'environ **60%**.
* Alcool tertiaire : Rendement d'environ **5% à 10%**.`,
    formulas: [
      'Acide + Alcool ⇌ Ester + Eau',
      'Rendement η = n_obtenu / n_theorique × 100'
    ],
    definitions: [
      { term: 'Ester', definition: 'Composé organique odorant possédant le groupe fonctionnel -COO-.' },
      { term: 'Athermique', definition: 'Réaction qui ne dégage ni ne consomme d\'énergie thermique.' }
    ],
    youtubeKeywords: 'esterification et hydrolyse terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?w=600&auto=format&fit=crop&q=80'
  },
  // --- 35. BAC SVT Glycemie ---
  {
    id: 'bac-svt-glycemie',
    title: 'Régulation de la glycémie et diabètes',
    exam: 'BAC',
    subject: 'SVT',
    chapter: 'Physiologie humaine',
    summary: 'Mécanisme de maintien du taux de glucose sanguin par le pancréas endocrine et étude des pathologies diabétiques (Type 1 & 2).',
    series: ['D'],
    content: `### 1. La glycémie
La glycémie est la concentration de glucose dans le plasma sanguin (norme biologique : environ **1 g/L**).

### 2. Le rôle du Pancréas Endocrine
Il contient les îlots de Langerhans qui sécrètent des hormones antagonistes :
* **Cellules alpha (α)** ➔ Sécrètent le **Glucagon** (hormone hyperglycémiante, stimule la glycogénolyse dans le foie).
* **Cellules bêta (β)** ➔ Sécrètent l'**Insuline** (seule hormone hypoglycémiante du corps, favorise l'entrée de glucose dans les cellules).

### 3. Les dysfonctionnements : Les Diabètes
* **Diabète de Type 1 (DID)** : Maladie auto-immune détruisant les cellules β. Traitement par injections d'insuline.
* **Diabète de Type 2 (DNID)** : Insulinorésistance liée à l'obésité et à la sédentarité.`,
    formulas: [
      'Taux normal de glucose ≈ 1 g/L (ou 5.5 mmol/L)',
      'Hormone hypoglycémiante : Insuline (uniquement)'
    ],
    definitions: [
      { term: 'Glycogénolyse', definition: 'Hydrolyse du glycogène hépatique libérant du glucose dans le sang.' },
      { term: 'Endocrine', definition: 'Glande libérant ses hormones directement dans la circulation sanguine.' }
    ],
    youtubeKeywords: 'regulation de la glycemie terminale d svt',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=600&auto=format&fit=crop&q=80'
  },
  // --- 36. BAC SVT VIH ---
  {
    id: 'bac-svt-vih',
    title: 'Le SIDA et l\'infection par le VIH',
    exam: 'BAC',
    subject: 'SVT',
    chapter: 'Immunologie',
    summary: 'Structure du virus VIH, cycle de réplication dans les lymphocytes T4, et effondrement des défenses immunitaires.',
    series: ['D'],
    content: `### 1. Structure du VIH
Le VIH (Virus de l'Immunodéficience Humaine) est un **rétrovirus** (virus à ARN) enveloppé possédant une enzyme spécifique : la **transcriptase inverse**.

### 2. Infection des Lymphocytes T4 (LT4)
Les LT4 sont les pivots de la réponse immunitaire. Le VIH pénètre dans ces cellules en se fixant sur le récepteur CD4. Le virus intègre son patrimoine génétique et détruit progressivement la cellule hôte lors du bourgeonnement.
* La baisse drastique des LT4 empêche l'activation des lymphocytes B et T8, conduisant à la phase de SIDA déclaré où surviennent des **maladies opportunistes** (tuberculose, sarcome de Kaposi).`,
    formulas: [
      'Rétrovirus : ARN viral ➔ Transcriptase Inverse ➔ ADN viral ➔ Intégration',
      'Pivot immunitaire : Lymphocytes T4'
    ],
    definitions: [
      { term: 'Maladie opportuniste', definition: 'Infection profitant de l\'affaiblissement extrême des défenses de l\'organisme pour s\'installer.' },
      { term: 'Rétrovirus', definition: 'Virus transmettant son information génétique sous forme d\'ARN et devant la transcrire en ADN pour se répliquer.' }
    ],
    youtubeKeywords: 'le vih et le sida cours terminale d svt',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1516062423079-7ca13cdc7f5a?w=600&auto=format&fit=crop&q=80'
  },
  // --- 37. BAC Philo Etat ---
  {
    id: 'bac-philo-etat',
    title: 'L\'État, la Justice et la Liberté',
    exam: 'BAC',
    subject: 'Philosophie',
    chapter: 'La politique',
    summary: 'Examen de l\'utilité de l\'État comme garant des libertés individuelles et des lois de justice à travers Hobbes, Locke et Rousseau.',
    series: ['A', 'C', 'D'],
    content: `### 1. L'État de Nature et le Contrat Social
Avant l'apparition de l'État, les hommes vivent à l'état de nature.
* **Thomas Hobbes (Le Léviathan)** : L'état de nature est une "guerre de tous contre tous" motivée par la peur. Les hommes cèdent leur liberté à un souverain absolu en échange de la **sécurité**.
* **Jean-Jacques Rousseau (Du Contrat Social)** : L'État doit exprimer la **Volonté Générale**. Le citoyen ne perd pas sa liberté mais acquiert une liberté civile guidée par la loi.

### 2. Le rôle moral de l'État : Justice et Droit
L'État doit encadrer la violence naturelle par des lois équitables. Cependant, l'obéissance aveugle peut mener à la tyrannie.
> *"La liberté est le droit de faire tout ce que les lois permettent."* — Montesquieu`,
    formulas: [
      'Hobbes : État de nature (guerre) ➔ Contrat ➔ État souverain absolu (sécurité)',
      'Rousseau : Souveraineté du Peuple ➔ Volonté Générale ➔ Liberté démocratique'
    ],
    definitions: [
      { term: 'État de droit', definition: 'Système où les pouvoirs publics sont soumis au respect des règles juridiques établies.' },
      { term: 'Volonté Générale', definition: 'Intérêt collectif supérieur à la somme des intérêts égoïstes particuliers.' }
    ],
    youtubeKeywords: 'l etat philosophie cours de terminale d a',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  },
  // --- 38. BAC HG Demographie ---
  {
    id: 'bac-hg-population',
    title: 'Démographie de la Côte d\'Ivoire',
    exam: 'BAC',
    subject: 'Histoire-Géographie',
    chapter: 'Géographie humaine',
    summary: 'La dynamique démographique ivoirienne : forte fécondité, jeunesse de la population, urbanisation rapide et défis scolaires/médicaux.',
    series: ['A', 'C', 'D'],
    content: `### 1. Une croissance démographique vigoureuse
La population ivoirienne connaît un taux d'accroissement naturel élevé lié à :
* Une fécondité soutenue (environ 4.5 enfants par femme).
* Une baisse de la mortalité infantile grâce à de meilleures campagnes de vaccination.

### 2. Une population extrêmement jeune
Plus de 40% de la population a moins de 15 ans.
* **Atout** : Main-d'œuvre abondante et dynamique pour le futur.
* **Défi** : Investissements colossaux requis pour l'éducation (construction de lycées), l'insertion professionnelle et la santé.

### 3. L'explosion urbaine
La ville d'Abidjan concentre près d'un cinquième de la population nationale, provoquant d'immenses défis de transport, de logement et d'assainissement.`,
    formulas: [
      'Accroissement naturel = Taux de natalité - Taux de mortalité',
      'Indice de fécondité : Nombre moyen d\'enfants par femme en âge de procréer'
    ],
    definitions: [
      { term: 'Transition démographique', definition: 'Passage d\'un régime démographique traditionnel (forte mortalité et natalité) à un régime moderne (faible mortalité et natalité).' },
      { term: 'Exode rural', definition: 'Migration définitive des populations rurales vers les grandes agglomérations urbaines.' }
    ],
    youtubeKeywords: 'la population de la cote d\'ivoire cours terminale',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 39. BAC HG USA ---
  {
    id: 'bac-hg-usa',
    title: 'La puissance économique des USA',
    exam: 'BAC',
    subject: 'Histoire-Géographie',
    chapter: 'Géographie des puissances',
    summary: 'Les fondements, piliers majeurs et limites de la domination économique américaine dans la mondialisation.',
    series: ['A', 'C', 'D'],
    content: `### 1. Les fondements de la puissance américaine
* **Ressources naturelles** : Territoire immense, sols fertiles, richesses énergétiques (gaz de schiste, pétrole).
* **Population** : Plus de 330 millions d'habitants, dynamisme entrepreneurial renforcé par l'immigration qualifiée ("Brain Drain").
* **Modèle capitaliste** : Primauté du libre marché et de l'innovation (Silicon Valley).

### 2. Les grands piliers sectoriels
* **Agriculture** : La "Food Power", premier exportateur mondial de produits agricoles.
* **Industrie** : Haute technologie, aéronautique, géants du web (GAFAM).
* **Finance** : Domination mondiale du Dollar US et des bourses de New York (Wall Street).`,
    formulas: [
      'PIB américain : Premier PIB mondial nominal',
      'Secteurs clés : GAFAM (Google, Apple, Facebook, Amazon, Microsoft)'
    ],
    definitions: [
      { term: 'Brain Drain', definition: 'Attraction des chercheurs, ingénieurs et cerveaux qualifiés du monde entier vers les USA.' },
      { term: 'Mondialisation', definition: 'Interdépendance croissante des économies, cultures et populations mondiales.' }
    ],
    youtubeKeywords: 'la puissance economique des etats unis terminale d',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=600&auto=format&fit=crop&q=80'
  },
  // --- 40. BAC Anglais Passive ---
  {
    id: 'bac-anglais-passive',
    title: 'The Passive Voice in Formal Writing',
    exam: 'BAC',
    subject: 'Anglais',
    chapter: 'Grammar',
    summary: 'How to use and formulate the passive voice in formal essays and literary descriptions.',
    series: ['A'],
    content: `### 1. When to use the Passive Voice
We use the passive voice when the focus is on the action or the object of the action, rather than who or what is performing the action.
* *Formal context* : It sounds more objective and academic.

### 2. General Formula
The passive sentence is formed by putting the object of the active sentence at the beginning, followed by the verb **to be** conjugated in the correct tense, plus the **past participle** of the main verb.
* *Active* : The government built a new university in Abidjan.
* *Passive* : A new university in Abidjan **was built** by the government.`,
    formulas: [
      'Active : Subject + Verb + Object',
      'Passive : Object + TO BE (conjugated) + Past Participle (+ BY Subject)'
    ],
    definitions: [
      { term: 'Agent', definition: 'The person or thing performing the action in a passive sentence, introduced by "by".' },
      { term: 'Past Participle', definition: 'The verb form used with auxiliary verbs to form passive voice and perfect tenses.' }
    ],
    youtubeKeywords: 'passive voice lesson terminale',
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz-thales',
    title: 'Quiz de Géométrie : Théorème de Thalès',
    sheetId: 'bepc-maths-thales',
    subject: 'Mathématiques',
    exam: 'BEPC',
    difficulty: 'Facile',
    questions: [
      {
        id: 'q1-thales',
        type: 'QCM',
        question: 'Quelle est la condition essentielle sur les droites pour appliquer le théorème de Thalès dans un triangle ?',
        options: [
          'Les droites doivent être perpendiculaires',
          'Deux des droites doivent être strictement parallèles',
          'Le triangle doit être rectangle',
          'Les droites doivent être confondues'
        ],
        correctAnswer: 'Deux des droites doivent être strictement parallèles',
        explanation: 'Le théorème de Thalès nécessite la présence de deux droites parallèles coupant deux droites sécantes.'
      },
      {
        id: 'q2-thales',
        type: 'VraiFaux',
        question: 'La réciproque du théorème de Thalès permet d\'affirmer que deux droites sont perpendiculaires.',
        correctAnswer: 'Faux',
        explanation: 'La réciproque de Thalès permet d\'affirmer que deux droites sont parallèles, non pas perpendiculaires (c\'est le rôle de la réciproque de Pythagore d\'affirmer qu\'un triangle est rectangle).'
      },
      {
        id: 'q3-thales',
        type: 'Libre',
        question: 'Si AM/AB = 3/9 et AN/AC = x/15, quelle doit être la valeur de x (en chiffre) pour que les droites soient parallèles ?',
        correctAnswer: '5',
        explanation: 'Pour que les droites soient parallèles, il faut que AM/AB = AN/AC. Soit 3/9 = x/15, ce qui équivaut à 1/3 = x/15. On en déduit x = 15/3 = 5.'
      }
    ]
  },
  {
    id: 'quiz-acides-bases',
    title: 'Quiz pH : Solutions acides et basiques',
    sheetId: 'bepc-pc-acides-bases',
    subject: 'Physique-Chimie',
    difficulty: 'Moyen',
    exam: 'BEPC',
    questions: [
      {
        id: 'q1-ph',
        type: 'QCM',
        question: 'Une solution de pH = 2.5 est qualifiée de :',
        options: [
          'Solution neutre',
          'Solution très acide',
          'Solution légèrement acide',
          'Solution basique'
        ],
        correctAnswer: 'Solution très acide',
        explanation: 'Le pH est inférieur à 7, donc la solution est acide. Plus le pH est proche de 0, plus l\'acidité est forte.'
      },
      {
        id: 'q2-ph',
        type: 'VraiFaux',
        question: 'Pour diluer un acide concentré de manière sécurisée, on doit verser de l\'eau directement dans la bouteille d\'acide.',
        correctAnswer: 'Faux',
        explanation: 'C\'est l\'inverse ! On doit toujours verser l\'acide lentement dans l\'eau pour absorber la chaleur dégagée et éviter des projections d\'acide brûlantes.'
      },
      {
        id: 'q3-ph',
        type: 'QCM',
        question: 'Quel ion est responsable de l\'acidité d\'une solution aqueuse ?',
        options: [
          'L\'ion chlorure Cl⁻',
          'L\'ion hydroxyde OH⁻',
          'L\'ion hydrogène H⁺ (ou hydronium H₃O⁺)',
          'L\'ion sodium Na⁺'
        ],
        correctAnswer: 'L\'ion hydrogène H⁺ (ou hydronium H₃O⁺)',
        explanation: 'Les ions hydrogène H⁺ sont responsables du caractère acide d\'une solution, tandis que les ions hydroxyde OH⁻ sont responsables de la basicité.'
      }
    ]
  },
  {
    id: 'quiz-logarithme',
    title: 'Quiz d\'Analyse : Logarithme Népérien',
    sheetId: 'bac-maths-logarithme',
    subject: 'Mathématiques',
    difficulty: 'Difficile',
    exam: 'BAC',
    questions: [
      {
        id: 'q1-ln',
        type: 'QCM',
        question: 'Quel est l\'ensemble de définition de la fonction logarithme népérien ?',
        options: [
          'R tout entier',
          '[0; +infini[',
          ']0; +infini[',
          ']-infini; 0['
        ],
        correctAnswer: ']0; +infini[',
        explanation: 'La fonction ln est strictement définie pour des valeurs de x strictement positives.'
      },
      {
        id: 'q2-ln',
        type: 'VraiFaux',
        question: 'La dérivée de la fonction x ↦ ln(3x + 1) sur son domaine de définition est x ↦ 1 / (3x + 1).',
        correctAnswer: 'Faux',
        explanation: 'La formule de dérivation est (ln(u))\' = u\'/u. Pour u(x) = 3x + 1, u\'(x) = 3. La dérivée est donc 3 / (3x + 1).'
      },
      {
        id: 'q3-ln',
        type: 'Libre',
        question: 'Quelle est la valeur exacte de ln(e^4) (répondre en chiffre) ?',
        correctAnswer: '4',
        explanation: 'Puisque la fonction ln est la bijection réciproque de l\'exponentielle, ln(e^y) = y pour tout réel y. Donc ln(e^4) = 4.'
      }
    ]
  },
  {
    id: 'quiz-cinetique',
    title: 'Quiz de Cinétique : Vitesses et Facteurs',
    sheetId: 'bac-pc-cinetique',
    subject: 'Physique-Chimie',
    difficulty: 'Moyen',
    exam: 'BAC',
    questions: [
      {
        id: 'q1-cine',
        type: 'QCM',
        question: 'Parmi les propositions suivantes, lequel n\'est PAS un facteur cinétique classique ?',
        options: [
          'La température du milieu réactionnel',
          'La pression atmosphérique (hors cas gazeux)',
          'La concentration initiale des réactifs',
          'La présence d\'un catalyseur'
        ],
        correctAnswer: 'La pression atmosphérique (hors cas gazeux)',
        explanation: 'La température, la concentration et le catalyseur sont les trois facteurs cinétiques de référence. La pression n\'influence que les réactions impliquant des gaz sous pression significative.'
      },
      {
        id: 'q2-cine',
        type: 'VraiFaux',
        question: 'Un catalyseur augmente la vitesse finale de la réaction et modifie la quantité totale de produit formée.',
        correctAnswer: 'Faux',
        explanation: 'Un catalyseur accélère le temps requis pour atteindre l\'état final, mais il ne change jamais la quantité maximale de produit théorique (l\'état final du système reste identique).'
      }
    ]
  },
  {
    id: 'quiz-cg-institutions',
    title: 'Quiz de Culture Générale : Institutions Ivoiriennes',
    sheetId: 'concours-cg-institutions',
    subject: 'Culture Générale',
    difficulty: 'Moyen',
    exam: 'Concours',
    questions: [
      {
        id: 'q1-inst',
        type: 'QCM',
        question: 'Quel changement majeur au niveau législatif a introduit la Constitution de la 3ème République en 2016 ?',
        options: [
          'La suppression de l\'Assemblée Nationale',
          'L\'introduction du Sénat créant un Parlement bicaméral',
          'L\'élection des députés pour 10 ans',
          'La fusion de toutes les municipalités'
        ],
        correctAnswer: 'L\'introduction du Sénat créant un Parlement bicaméral',
        explanation: 'La Constitution de 2016 a créé le Sénat, s\'ajoutant à l\'Assemblée Nationale, ce qui donne un pouvoir législatif bicaméral.'
      },
      {
        id: 'q2-inst',
        type: 'VraiFaux',
        question: 'Le Conseil Constitutionnel ivoirien est chargé de valider les candidatures présidentielles et de proclamer les résultats définitifs des scrutins présidentiels.',
        correctAnswer: 'Vrai',
        explanation: 'C\'est effectivement l\'une des prérogatives majeures du Conseil Constitutionnel en Côte d\'Ivoire.'
      },
      {
        id: 'q3-inst',
        type: 'Libre',
        question: 'Quel organe indépendant a pour but de régler à l\'amiable les différends entre les citoyens et l\'administration publique en Côte d\'Ivoire ?',
        correctAnswer: 'Le Médiateur de la République',
        explanation: 'Le Médiateur de la République est l\'institution de conciliation officielle entre l\'administration ivoirienne et les usagers/citoyens.'
      }
    ]
  },
  {
    id: 'quiz-trigo',
    title: 'Quiz de Trigonométrie : Triangle rectangle',
    sheetId: 'bepc-maths-trigo',
    subject: 'Mathématiques',
    difficulty: 'Facile',
    exam: 'BEPC',
    questions: [
      {
        id: 'q1-trigo',
        type: 'QCM',
        question: 'Comment définit-on le cosinus d\'un angle aigu dans un triangle rectangle ?',
        options: [
          'Côté opposé / Hypoténuse',
          'Côté adjacent / Hypoténuse',
          'Côté opposé / Côté adjacent',
          'Hypoténuse / Côté opposé'
        ],
        correctAnswer: 'Côté adjacent / Hypoténuse',
        explanation: 'Le cosinus d\'un angle aigu correspond au rapport de la longueur du côté adjacent à cet angle sur la longueur de l\'hypoténuse.'
      },
      {
        id: 'q2-trigo',
        type: 'VraiFaux',
        question: 'Pour tout angle aigu x, la relation suivante est correcte : cos²(x) + sin²(x) = 1.',
        correctAnswer: 'Vrai',
        explanation: 'C\'est l\'égalité fondamentale de la trigonométrie qui découle directement du théorème de Pythagore.'
      },
      {
        id: 'q3-trigo',
        type: 'Libre',
        question: 'Si le sinus d\'un angle est de 0.6 et son cosinus est de 0.8, quelle est sa tangente (en décimal, ex: 0.75) ?',
        correctAnswer: '0.75',
        explanation: 'Puisque tan(x) = sin(x)/cos(x), on obtient tan(x) = 0.6 / 0.8 = 6/8 = 0.75.'
      }
    ]
  },
  {
    id: 'quiz-expo',
    title: 'Quiz d\'Analyse : Fonction Exponentielle',
    sheetId: 'bac-maths-expo',
    subject: 'Mathématiques',
    difficulty: 'Moyen',
    exam: 'BAC',
    series: ['A', 'C', 'D'],
    questions: [
      {
        id: 'q1-expo',
        type: 'QCM',
        question: 'Quelle est l\'expression de la dérivée de la fonction f(x) = e^(3x) ?',
        options: [
          'e^(3x)',
          '3e^(3x)',
          '1/3 e^(3x)',
          '3x e^(3x-1)'
        ],
        correctAnswer: '3e^(3x)',
        explanation: 'La dérivée de e^u est u\'e^u. Ici u(x) = 3x, donc u\'(x) = 3. La dérivée est donc 3e^(3x).'
      },
      {
        id: 'q2-expo',
        type: 'VraiFaux',
        question: 'La fonction exponentielle e^x peut prendre des valeurs strictement négatives pour certaines valeurs de x réelles.',
        correctAnswer: 'Faux',
        explanation: 'La fonction exponentielle e^x est strictement positive (> 0) pour tout réel x.'
      }
    ]
  },
  {
    id: 'quiz-esters',
    title: 'Quiz de Chimie : Estérification et Hydrolyse',
    sheetId: 'bac-pc-esters',
    subject: 'Physique-Chimie',
    difficulty: 'Moyen',
    exam: 'BAC',
    series: ['C', 'D'],
    questions: [
      {
        id: 'q1-ester',
        type: 'QCM',
        question: 'Quels sont les deux réactifs nécessaires pour réaliser une estérification ?',
        options: [
          'Un aldéhyde et un alcool',
          'Un acide carboxylique et un alcool',
          'Un ester et de l\'eau',
          'Un alcane et de l\'eau'
        ],
        correctAnswer: 'Un acide carboxylique et un alcool',
        explanation: 'La réaction d\'estérification met en présence un acide carboxylique et un alcool pour former un ester et de l\'eau.'
      },
      {
        id: 'q2-ester',
        type: 'VraiFaux',
        question: 'L\'estérification est une réaction chimique athermique, rapide et totale.',
        correctAnswer: 'Faux',
        explanation: 'L\'estérification est athermique, mais elle est très lente et limitée par la réaction inverse (l\'hydrolyse), elle n\'est donc pas totale.'
      }
    ]
  }
];
