/**
 * Helper utility for PWA Service Worker registration and Push Notifications
 */

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if ('serviceWorker' in navigator) {
    try {
      const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
      console.log('Service Worker registered with scope:', reg.scope);
      return reg;
    } catch (err) {
      console.error('Service Worker registration failed:', err);
      return null;
    }
  }
  return null;
}

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    console.warn('This browser does not support desktop notifications');
    return 'denied';
  }

  const permission = await Notification.requestPermission();
  return permission;
}

export async function sendTestNotification(title?: string, body?: string) {
  if (!('Notification' in window)) return;

  if (Notification.permission === 'granted') {
    const reg = await navigator.serviceWorker.ready;
    if (reg && reg.active) {
      reg.active.postMessage({
        type: 'SHOW_TEST_NOTIFICATION',
        title: title || '📚 Rappel de Révision Sankofa Educ',
        body: body || 'N\'oublie pas de faire tes 15 minutes de révision aujourd\'hui !'
      });
    } else {
      new Notification(title || '📚 Rappel de Révision Sankofa Educ', {
        body: body || 'N\'oublie pas de faire tes 15 minutes de révision aujourd\'hui !',
        icon: '/pwa-icon.png'
      });
    }
  }
}

export interface ReminderSettings {
  enabled: boolean;
  time: string; // e.g. "18:00"
  days: string[]; // e.g. ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
}

const STORAGE_KEY = 'sankofa_reminder_settings';

export function getReminderSettings(): ReminderSettings {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error(e);
  }
  return {
    enabled: false,
    time: '18:00',
    days: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim']
  };
}

export function saveReminderSettings(settings: ReminderSettings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
}
