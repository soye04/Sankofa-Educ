import { getMessaging, getToken, onMessage, isSupported, Messaging } from 'firebase/messaging';
import { doc, setDoc } from 'firebase/firestore';
import { app, db, handleFirestoreError, OperationType, sanitizeId } from './firebase';

let messagingInstance: Messaging | null = null;

/**
 * Check if FCM is supported in current browser environment
 */
export async function checkFcmSupport(): Promise<boolean> {
  try {
    return await isSupported();
  } catch (e) {
    console.warn('FCM is not supported in this browser/environment:', e);
    return false;
  }
}

/**
 * Initialize Firebase Cloud Messaging and obtain user token
 */
export async function initializeFCM(userId?: string): Promise<string | null> {
  const supported = await checkFcmSupport();
  if (!supported) {
    console.log('[FCM] Cloud Messaging non supporté dans cet environnement.');
    return null;
  }

  try {
    if (!messagingInstance) {
      messagingInstance = getMessaging(app);
    }

    // Check / Request notification permission
    if ('Notification' in window && Notification.permission !== 'granted') {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        console.warn('[FCM] Permission de notification refusée par l\'utilisateur.');
        return null;
      }
    }

    // Register service worker if needed
    let swReg: ServiceWorkerRegistration | undefined = undefined;
    if ('serviceWorker' in navigator) {
      try {
        swReg = await navigator.serviceWorker.register('/firebase-messaging-sw.js', { scope: '/' });
        console.log('[FCM] Service Worker enregistré avec succès :', swReg.scope);
      } catch (swErr) {
        console.warn('[FCM] Erreur lors de l\'enregistrement du Service Worker :', swErr);
      }
    }

    // Retrieve FCM Registration Token
    const currentToken = await getToken(messagingInstance, {
      serviceWorkerRegistration: swReg
    });

    if (currentToken) {
      console.log('[FCM] Jeton FCM attribué avec succès :', currentToken);

      // Save token locally
      localStorage.setItem('sankofa_fcm_token', currentToken);

      // If user is logged in, register token in Firestore and server
      if (userId) {
        await registerFcmTokenOnServerAndDb(userId, currentToken);
      }

      return currentToken;
    } else {
      console.warn('[FCM] Aucun jeton d\'enregistrement disponible. Demandez la permission de générer un jeton.');
      return null;
    }
  } catch (error) {
    console.error('[FCM] Erreur d\'initialisation FCM :', error);
    return null;
  }
}

/**
 * Save FCM token to Firestore database and Express server
 */
export async function registerFcmTokenOnServerAndDb(userId: string, token: string) {
  const cleanUid = sanitizeId(userId);
  const cleanTokenId = sanitizeId(token.slice(-32)); // safe ID for Firestore path

  // 1. Save to Firestore under user profile subcollection
  try {
    const tokenRef = doc(db, 'users', cleanUid, 'fcmTokens', cleanTokenId);
    await setDoc(tokenRef, {
      token,
      userId: cleanUid,
      platform: 'web',
      userAgent: navigator.userAgent,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log('[FCM] Jeton enregistré dans Firestore pour l\'utilisateur', cleanUid);
  } catch (error) {
    console.warn('[FCM] Impossible d\'enregistrer le jeton dans Firestore:', error);
  }

  // 2. Save to Express server memory DB
  try {
    await fetch('/api/fcm/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, token })
    });
  } catch (e) {
    console.warn('[FCM] Impossible d\'envoyer le jeton FCM au serveur backend:', e);
  }
}

/**
 * Setup foreground message listener for FCM
 */
export function setupFcmForegroundListener(onNotificationReceived: (payload: any) => void) {
  checkFcmSupport().then((supported) => {
    if (!supported) return;
    try {
      if (!messagingInstance) {
        messagingInstance = getMessaging(app);
      }
      onMessage(messagingInstance, (payload) => {
        console.log('[FCM] Message reçu en premier plan :', payload);
        onNotificationReceived(payload);

        // Show browser notification if granted
        if ('Notification' in window && Notification.permission === 'granted') {
          const title = payload.notification?.title || payload.data?.title || '📚 Sankofa Educ FCM';
          const body = payload.notification?.body || payload.data?.body || 'Nouvelle alerte de révision !';
          new Notification(title, {
            body,
            icon: '/pwa-icon.png',
            badge: '/pwa-icon.png'
          });
        }
      });
    } catch (err) {
      console.warn('[FCM] Erreur écouteur premier plan :', err);
    }
  });
}
