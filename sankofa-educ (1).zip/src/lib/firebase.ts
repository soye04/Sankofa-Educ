import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  collection, 
  query, 
  getDocs, 
  onSnapshot, 
  deleteDoc,
  getDocFromServer
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize core Firebase Applet
export const app = initializeApp(firebaseConfig);

// Initialize Firestore with Database ID (Critical step)
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Authentication
export const auth = getAuth(app);

// --- FIRESTORE OPERATION AUDIT ENGINE & ERROR HANDLER ---
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Detailing: ', JSON.stringify(errInfo, null, 2));
  throw new Error(JSON.stringify(errInfo));
}

// Ensure database connection is validated (Liveness Probe)
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Firebase client is currently offline or unconfigured.");
    }
  }
}
testConnection();

// --- GOOGLE SIGN IN POPUP HELPER ---
export const provider = new GoogleAuthProvider();

export async function signInWithGoogle() {
  try {
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    console.error("Google Sign-In Failed:", error);
    throw error;
  }
}

export async function logOutUser() {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Google Sign-Out Failed:", error);
    throw error;
  }
}

// --- FIRESTORE SECURE SYNC HELPERS ---

// Helper to sanitize IDs to prevent path injection
export function sanitizeId(id: string): string {
  return id.replace(/[^a-zA-Z0-9_\-]/g, '_');
}

// 1. Sync User Profile
export async function dbSaveProfile(userId: string, profile: any) {
  const cleanUid = sanitizeId(userId);
  const userRef = doc(db, 'users', cleanUid);
  try {
    const payload = {
      userId: cleanUid,
      email: profile.email || '',
      name: profile.name || 'Élève',
      phone: profile.phone || 'Non renseigné',
      targetExam: profile.targetExam || 'BAC',
      series: profile.series || 'D',
      createdAt: profile.createdAt || new Date().toISOString()
    };
    await setDoc(userRef, payload, { merge: true });
    console.log('Profile synced with Firestore successfully');
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${cleanUid}`);
  }
}

// 2. Sync User Progress
export async function dbSaveProgress(userId: string, progress: any) {
  const cleanUid = sanitizeId(userId);
  const progressRef = doc(db, 'users', cleanUid, 'progress', 'metrics');
  try {
    const payload = {
      userId: cleanUid,
      quizCount: Number(progress.quizCount) || 0,
      studyTimeMinutes: Number(progress.studyTimeMinutes) || 0,
      streakDays: Number(progress.streakDays) || 0,
      completedQuizzes: progress.completedQuizzes || [],
      completedSheets: progress.completedSheets || [],
      favorites: progress.favorites || [],
      downloads: progress.downloads || [],
      updatedAt: new Date().toISOString()
    };
    await setDoc(progressRef, payload, { merge: true });
    console.log('Progress metrics synced with Firestore');
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${cleanUid}/progress/metrics`);
  }
}

// 3. Sync User Subscription Status
export async function dbSaveSubscription(userId: string, sub: any) {
  const cleanUid = sanitizeId(userId);
  const subRef = doc(db, 'users', cleanUid, 'subscription', 'status');
  try {
    const payload = {
      userId: cleanUid,
      isPremium: Boolean(sub.isPremium),
      trialEndsAt: sub.trialEndsAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      expiresAt: sub.expiresAt || null,
      paymentMethod: sub.paymentMethod || null,
      phoneNumber: sub.phoneNumber || null,
      history: sub.history || [],
      updatedAt: new Date().toISOString()
    };
    await setDoc(subRef, payload, { merge: true });
    console.log('Subscription state synced with Firestore');
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${cleanUid}/subscription/status`);
  }
}

// 4. Save/Update a single notification
export async function dbSaveNotification(userId: string, notif: any) {
  const cleanUid = sanitizeId(userId);
  const cleanNotifId = sanitizeId(notif.id);
  const notifRef = doc(db, 'users', cleanUid, 'notifications', cleanNotifId);
  try {
    const payload = {
      id: cleanNotifId,
      userId: cleanUid,
      title: notif.title || '',
      body: notif.body || '',
      read: Boolean(notif.read),
      type: notif.type || 'info',
      date: notif.date || new Date().toISOString()
    };
    await setDoc(notifRef, payload, { merge: true });
    console.log(`Notification ${cleanNotifId} synced with Firestore`);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${cleanUid}/notifications/${cleanNotifId}`);
  }
}

// 5. Delete a notification
export async function dbDeleteNotification(userId: string, notifId: string) {
  const cleanUid = sanitizeId(userId);
  const cleanNotifId = sanitizeId(notifId);
  const notifRef = doc(db, 'users', cleanUid, 'notifications', cleanNotifId);
  try {
    await deleteDoc(notifRef);
    console.log(`Notification ${cleanNotifId} deleted from Firestore`);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${cleanUid}/notifications/${cleanNotifId}`);
  }
}

// 6. Fetch all user data from Firestore
export async function dbLoadAllUserData(userId: string, defaultData: any) {
  const cleanUid = sanitizeId(userId);
  try {
    // Check if profile exists
    const userSnap = await getDoc(doc(db, 'users', cleanUid));
    if (!userSnap.exists()) {
      // User doesn't exist, bootstrap documents in Firestore!
      console.log('Bootstrapping Firestore documents for user:', cleanUid);
      await dbSaveProfile(cleanUid, defaultData.profile);
      await dbSaveProgress(cleanUid, defaultData.progress);
      await dbSaveSubscription(cleanUid, defaultData.subscription);
      for (const n of defaultData.notifications || []) {
        await dbSaveNotification(cleanUid, n);
      }
      return {
        profile: defaultData.profile,
        progress: defaultData.progress,
        subscription: defaultData.subscription,
        notifications: defaultData.notifications
      };
    }

    // Load progress
    const progressSnap = await getDoc(doc(db, 'users', cleanUid, 'progress', 'metrics'));
    const progress = progressSnap.exists() ? progressSnap.data() : {
      userId: cleanUid,
      quizCount: 0,
      studyTimeMinutes: 0,
      streakDays: 0,
      completedQuizzes: [],
      completedSheets: [],
      favorites: [],
      downloads: []
    };

    // Load subscription
    const subSnap = await getDoc(doc(db, 'users', cleanUid, 'subscription', 'status'));
    const subscription = subSnap.exists() ? subSnap.data() : {
      userId: cleanUid,
      isPremium: false,
      trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      history: []
    };

    // Load notifications
    const notifsColl = collection(db, 'users', cleanUid, 'notifications');
    const notifsSnap = await getDocs(notifsColl);
    const notifications = notifsSnap.docs.map(doc => doc.data() as any);

    return {
      profile: userSnap.data(),
      progress,
      subscription,
      notifications: notifications.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${cleanUid}`);
  }
}

