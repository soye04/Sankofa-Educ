/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import yts from 'yt-search';
import twilio from 'twilio';
import nodemailer from 'nodemailer';
import { INITIAL_SHEETS, INITIAL_QUIZZES } from './src/data';
import { RevisionSheet, Quiz, UserProgress, SubscriptionState, AppNotification, ExamType, VideoInfo, ForumQuestion, ForumAnswer } from './src/types';

// Load environment variables
dotenv.config();

async function sendRealEmailOtp(email: string, code: string): Promise<{ sent: boolean; message: string }> {
  const resendApiKey = process.env.RESEND_API_KEY;
  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpPort = Number(process.env.SMTP_PORT) || 587;
  const smtpFrom = process.env.SMTP_FROM || 'Sankofa Educ <noreply@sankofa-educ.ci>';

  const htmlContent = `
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 540px; margin: 0 auto; padding: 24px; background-color: #ffffff; border-radius: 16px; border: 1px solid #fed7aa;">
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #ea580c; margin: 0; font-size: 24px; font-weight: 800;">📚 Sankofa Educ</h1>
        <p style="color: #78716c; font-size: 13px; margin-top: 4px;">Révision Examens & Concours (BEPC, BAC, CI)</p>
      </div>
      <div style="background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%); padding: 20px; border-radius: 12px; border: 1px solid #ffedd5; text-align: center;">
        <p style="font-size: 14px; color: #44403c; margin: 0 0 12px 0;">Voici votre code de vérification OTP par email :</p>
        <div style="font-size: 36px; font-weight: 900; letter-spacing: 8px; color: #c2410c; background: #ffffff; padding: 12px 24px; border-radius: 12px; display: inline-block; border: 2px dashed #f97316; margin: 8px 0;">
          ${code}
        </div>
        <p style="font-size: 12px; color: #78716c; margin-top: 12px;">Ce code expire dans 10 minutes. Ne le partagez avec personne.</p>
      </div>
      <p style="font-size: 11px; color: #a8a29e; text-align: center; margin-top: 24px;">Si vous n'avez pas demandé ce code, vous pouvez ignorer cet email en toute sécurité.</p>
    </div>
  `;

  // 1. Try Resend HTTP API if key is set
  if (resendApiKey) {
    try {
      console.log(`[EMAIL OTP] Sending real email via Resend API to ${email}...`);
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: smtpFrom,
          to: email,
          subject: `Votre code OTP Sankofa Educ : ${code}`,
          html: htmlContent
        })
      });

      if (response.ok) {
        console.log(`[EMAIL OTP] Email sent successfully via Resend to ${email}`);
        return { sent: true, message: `Un vrai email de confirmation avec le code OTP a été envoyé à ${email} !` };
      } else {
        const errJson = await response.json();
        console.error('[EMAIL OTP] Resend API error response:', errJson);
      }
    } catch (err) {
      console.error('[EMAIL OTP] Resend API fetch error:', err);
    }
  }

  // 2. Try Nodemailer SMTP if credentials are set
  if (smtpHost && smtpUser && smtpPass) {
    try {
      console.log(`[EMAIL OTP] Sending real email via Nodemailer SMTP to ${email}...`);
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass
        }
      });

      await transporter.sendMail({
        from: smtpFrom,
        to: email,
        subject: `Votre code OTP Sankofa Educ : ${code}`,
        html: htmlContent,
        text: `Sankofa Educ - Votre code de confirmation OTP est : ${code}`
      });

      console.log(`[EMAIL OTP] Email sent successfully via SMTP to ${email}`);
      return { sent: true, message: `Un vrai email de confirmation avec le code OTP a été envoyé à ${email} !` };
    } catch (err: any) {
      console.error('[EMAIL OTP] Nodemailer SMTP send error:', err);
    }
  }

  console.log(`[EMAIL OTP] Real SMTP/Resend API key not configured. Code generated for ${email}: ${code}`);
  return {
    sent: false,
    message: `Module OTP par Email actif ! (Les clés SMTP/Resend peuvent être ajoutées dans les paramètres pour l'envoi direct). Code généré : ${code}`
  };
}

let twilioClient: any = null;

function getTwilioClient() {
  if (!twilioClient) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    if (accountSid && authToken) {
      if (typeof accountSid === 'string' && accountSid.trim().startsWith('AC')) {
        try {
          twilioClient = twilio(accountSid.trim(), authToken.trim());
          console.log('Twilio client initialized successfully.');
        } catch (err) {
          console.error('Failed to initialize Twilio client:', err);
          twilioClient = null;
        }
      } else {
        console.warn('Twilio Account SID is invalid (does not start with "AC"). Falling back to simulation.');
        twilioClient = null;
      }
    }
  }
  return twilioClient;
}

async function sendSmsViaInfobipMcp(to: string, message: string): Promise<boolean> {
  const mcpUrl = process.env.INFOBIP_SMS_URL || "https://mcp.infobip.com/sms";
  const authHeader = process.env.INFOBIP_SMS_AUTHORIZATION || "App 244412c3b63b47b11c98cd3a1fbb6615-7faeac39-25a9-4723-890c-adf0ff469179";

  // Check if authorization or URL has non-ByteString characters (like bullet points from masked UI values)
  const isByteString = (str: string) => {
    for (let i = 0; i < str.length; i++) {
      if (str.charCodeAt(i) > 255) return false;
    }
    return true;
  };

  if (!isByteString(authHeader)) {
    console.warn(`[INFOBIP MCP] Skipped Infobip: Authorization header contains masked or invalid characters (such as bullet points •). Please make sure INFOBIP_SMS_AUTHORIZATION is properly configured with your actual API key.`);
    return false;
  }

  if (!isByteString(mcpUrl)) {
    console.warn(`[INFOBIP MCP] Skipped Infobip: MCP URL contains invalid characters. Please check INFOBIP_SMS_URL.`);
    return false;
  }

  console.log(`[INFOBIP MCP] Attempting to send SMS to ${to} via Infobip MCP...`);
  try {
    const sseResponse = await fetch(mcpUrl, {
      method: "GET",
      headers: {
        "Authorization": authHeader,
        "Accept": "text/event-stream"
      }
    });

    if (!sseResponse.ok) {
      throw new Error(`Failed to connect to Infobip MCP SSE: ${sseResponse.status} ${sseResponse.statusText}`);
    }

    if (!sseResponse.body) {
      throw new Error(`No body in Infobip MCP SSE response`);
    }

    // Read the stream to find the endpoint URL
    const reader = sseResponse.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let endpointUrl = "";

    // Read stream chunks
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      let currentEvent = "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith("event:")) {
          currentEvent = trimmed.substring(6).trim();
        } else if (trimmed.startsWith("data:")) {
          const data = trimmed.substring(5).trim();
          if (currentEvent === "endpoint") {
            endpointUrl = data;
            break;
          }
        }
      }

      if (endpointUrl) {
        break;
      }
    }

    // Cancel reader to close connection
    try {
      await reader.cancel();
    } catch (cancelErr) {
      console.warn("[INFOBIP MCP] Non-blocking error while canceling reader:", cancelErr);
    }

    if (!endpointUrl) {
      throw new Error("Could not find MCP endpoint URL in SSE stream");
    }

    // If endpointUrl is relative, make it absolute using mcpUrl
    if (endpointUrl.startsWith("/")) {
      const parsedMcpUrl = new URL(mcpUrl);
      endpointUrl = `${parsedMcpUrl.protocol}//${parsedMcpUrl.host}${endpointUrl}`;
    }

    console.log(`[INFOBIP MCP] Successfully retrieved MCP POST endpoint: ${endpointUrl}`);

    // Now, list tools to find the send SMS tool
    const listToolsPayload = {
      jsonrpc: "2.0",
      id: "list-tools-1",
      method: "tools/list",
      params: {}
    };

    const listToolsResponse = await fetch(endpointUrl, {
      method: "POST",
      headers: {
        "Authorization": authHeader,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(listToolsPayload)
    });

    if (!listToolsResponse.ok) {
      throw new Error(`Failed to list tools from MCP endpoint: ${listToolsResponse.status} ${listToolsResponse.statusText}`);
    }

    const listToolsResult = (await listToolsResponse.json()) as any;
    const tools = listToolsResult?.result?.tools || [];
    if (!tools || tools.length === 0) {
      throw new Error("No tools available in Infobip MCP server");
    }

    // Find the send SMS tool
    const smsTool = tools.find((t: any) => {
      const name = t.name.toLowerCase();
      return name.includes("sms") || name.includes("message") || name.includes("send");
    }) || tools[0];

    console.log(`[INFOBIP MCP] Using SMS tool: ${smsTool.name}`);

    // Map properties based on the tool's input schema
    const properties = smsTool.inputSchema?.properties || {};
    const args: Record<string, any> = {};

    // Standard properties for phone
    const toPropKey = Object.keys(properties).find(key => {
      const lower = key.toLowerCase();
      return lower === "to" || lower === "phonenumber" || lower === "number" || lower === "phone";
    }) || "to";

    // Standard properties for text
    const textPropKey = Object.keys(properties).find(key => {
      const lower = key.toLowerCase();
      return lower === "text" || lower === "message" || lower === "body" || lower === "content";
    }) || "text";

    args[toPropKey] = to;
    args[textPropKey] = message;

    // Handle any other required properties like 'from'
    const fromPropKey = Object.keys(properties).find(key => {
      const lower = key.toLowerCase();
      return lower === "from" || lower === "sender" || lower === "senderid" || lower === "sender_id";
    });

    if (fromPropKey) {
      args[fromPropKey] = "SankofaEduc";
    }

    // Call the tool
    const callToolPayload = {
      jsonrpc: "2.0",
      id: "call-tool-1",
      method: "tools/call",
      params: {
        name: smsTool.name,
        arguments: args
      }
    };

    console.log(`[INFOBIP MCP] Invoking tool ${smsTool.name} with args:`, JSON.stringify(args));

    const callToolResponse = await fetch(endpointUrl, {
      method: "POST",
      headers: {
        "Authorization": authHeader,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(callToolPayload)
    });

    if (!callToolResponse.ok) {
      throw new Error(`Failed to call tool: ${callToolResponse.status} ${callToolResponse.statusText}`);
    }

    const callToolResult = (await callToolResponse.json()) as any;
    console.log(`[INFOBIP MCP] Tool execution result:`, JSON.stringify(callToolResult));

    if (callToolResult.error) {
      throw new Error(`MCP tool error: ${JSON.stringify(callToolResult.error)}`);
    }

    const isError = callToolResult.result?.isError;
    if (isError) {
      throw new Error(`MCP tool execution reported error: ${JSON.stringify(callToolResult.result?.content)}`);
    }

    console.log(`[INFOBIP MCP] SMS sent successfully via MCP!`);
    return true;
  } catch (err: any) {
    console.error(`[INFOBIP MCP] Error sending SMS via MCP:`, err);
    return false;
  }
}



const app = express();
const PORT = 3000;

// --- 1. COOKIE SECURITY & HTTP SECURITY HEADERS MIDDLEWARE ---
app.use((req, res, next) => {
  // Security Headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=(self)');

  // Intercept Set-Cookie header to enforce Secure; HttpOnly; SameSite=Lax flags
  const originalSetHeader = res.setHeader;
  res.setHeader = function (name: string, value: any) {
    if (name.toLowerCase() === 'set-cookie') {
      if (Array.isArray(value)) {
        value = value.map(cookieStr => {
          let updated = cookieStr;
          if (!/;\s*Secure/i.test(updated)) updated += '; Secure';
          if (!/;\s*HttpOnly/i.test(updated)) updated += '; HttpOnly';
          if (!/;\s*SameSite/i.test(updated)) updated += '; SameSite=Lax';
          return updated;
        });
      } else if (typeof value === 'string') {
        if (!/;\s*Secure/i.test(value)) value += '; Secure';
        if (!/;\s*HttpOnly/i.test(value)) value += '; HttpOnly';
        if (!/;\s*SameSite/i.test(value)) value += '; SameSite=Lax';
      }
    }
    return originalSetHeader.call(this, name, value);
  };

  next();
});

// --- 2. CDN OPTIMIZATION & STATIC CACHING MIDDLEWARE ---
app.use((req, res, next) => {
  // CDN header configuration for static assets vs API
  if (req.path.startsWith('/api/')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  } else if (req.path.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$/)) {
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.setHeader('CDN-Cache-Control', 'public, max-age=31536000');
    res.setHeader('Cloudflare-CDN-Cache-Control', 'max-age=31536000');
    res.setHeader('Surrogate-Control', 'max-age=31536000');
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Initialize local database path
const DB_PATH = path.join(process.cwd(), 'src', 'local_db.json');

// Helper to load/save data
function getInitialDB() {
  return {
    sheets: INITIAL_SHEETS,
    quizzes: INITIAL_QUIZZES,
    progress: {
      userId: 'student-123',
      quizCount: 2,
      studyTimeMinutes: 45,
      streakDays: 3,
      completedQuizzes: [
        {
          quizId: 'quiz-thales',
          quizTitle: 'Quiz de Géométrie : Théorème de Thalès',
          subject: 'Mathématiques',
          exam: 'BEPC' as ExamType,
          score: 2,
          total: 3,
          date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
        }
      ],
      completedSheets: ['bepc-maths-thales'],
      favorites: ['bepc-pc-acides-bases', 'bac-maths-logarithme'],
      downloads: ['bepc-maths-thales', 'bac-maths-logarithme']
    } as UserProgress,
    subscription: {
      isPremium: true,
      trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      history: []
    } as SubscriptionState,
    notifications: [
      {
        id: 'notif-1',
        title: 'Bienvenue sur Sankofa Educ ! 🇨🇮',
        body: 'Préparez vos examens BEPC, BAC et Concours avec les meilleurs fiches de révision de Côte d\'Ivoire.',
        date: new Date().toISOString(),
        read: false,
        type: 'info'
      },
      {
        id: 'notif-2',
        title: 'Application 100% Gratuite 🌟',
        body: 'Profitez de toutes les fiches, des quiz et du scanner IA de manière totalement gratuite !',
        date: new Date().toISOString(),
        read: false,
        type: 'info'
      }
    ] as AppNotification[],
    userProgresses: {} as Record<string, UserProgress>,
    userSubscriptions: {} as Record<string, SubscriptionState>,
    userNotifications: {} as Record<string, AppNotification[]>,
    teachers: [] as any[],
    videos: [] as VideoInfo[],
    questions: [
      {
        id: 'q-1',
        authorName: 'Kouadio Jean',
        authorExam: 'BEPC',
        subject: 'Mathématiques',
        title: 'Comment bien rédiger la réciproque du Théorème de Thalès ?',
        content: 'Bonjour à tous ! Dans mes devoirs de Maths 3ème, le professeur me retire des points sur la rédaction de la réciproque de Thalès. Quelles sont les phrases clés indispensables à écrire ?',
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        likes: 8,
        isResolved: true,
        answers: [
          {
            id: 'ans-101',
            authorName: 'M. Yao Kouassi',
            authorRole: 'Enseignant',
            content: "Bonjour Kouadio ! Les correcteurs au BEPC vérifient obligatoirement 2 points : 1) La phrase 'Les points A, B, C d'une part et A, D, E d'autre part sont alignés dans le même ordre'. 2) L'égalité des fractions AD/AB = AE/AC. Si ces 2 conditions sont écrites, tu auras la totalité des points !",
            createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
            likes: 14
          },
          {
            id: 'ans-102',
            authorName: 'Awa Touré',
            authorRole: 'Élève',
            content: "Merci Monsieur Yao pour ces précisions ! Ça m'aide beaucoup aussi pour mon brevet blanc.",
            createdAt: new Date(Date.now() - 3600000 * 18).toISOString(),
            likes: 5
          }
        ]
      },
      {
        id: 'q-2',
        authorName: 'Bamba Lassina',
        authorExam: 'BAC',
        subject: 'Français',
        title: 'Plan dialectique en dissertation littéraire au BAC D',
        content: 'Lorsque le sujet dit : "Expliquez et discutez cette affirmation de Victor Hugo", doit-on obligatoirement faire la partie synthèse ou Thèse + Antithèse suffit ?',
        createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
        likes: 12,
        isResolved: true,
        answers: [
          {
            id: 'ans-201',
            authorName: "Mme N'Guessan",
            authorRole: 'Enseignant',
            content: 'Bonjour Lassina ! La synthèse est fortement recommandée car elle permet de dépasser la contradiction entre Thèse et Antithèse pour proposer une réflexion plus mûre et personnelle.',
            createdAt: new Date(Date.now() - 3600000 * 40).toISOString(),
            likes: 9
          }
        ]
      },
      {
        id: 'q-3',
        authorName: 'Konan Marc',
        authorExam: 'BEPC',
        subject: 'Physique-Chimie',
        title: "Équation bilan de la réaction entre l'acide chlorhydrique et le fer",
        content: "Bonjour, est-ce que le gaz dégagé lors de cette réaction est le dihydrogène ou le dioxygène ? Et comment le mettre en évidence ?",
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        likes: 4,
        isResolved: false,
        answers: [
          {
            id: 'ans-301',
            authorName: 'Mariam Diomandé',
            authorRole: 'Élève',
            content: "C'est le Dihydrogène (H2) ! On le met en évidence en approchant une flamme de l'embout du tube à essai : on entend une petite détonation (\"Pop !\").",
            createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
            likes: 6
          }
        ]
      }
    ] as ForumQuestion[]
  };
}

function loadDB() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf-8');
      const parsed = JSON.parse(data);
      let changed = false;
      if (!parsed.teachers) {
        parsed.teachers = [];
        changed = true;
      }
      if (!parsed.videos) {
        parsed.videos = getInitialDB().videos;
        changed = true;
      }
      if (!parsed.questions) {
        parsed.questions = getInitialDB().questions;
        changed = true;
      }
      if (!parsed.registeredUsers) {
        parsed.registeredUsers = {};
        changed = true;
      }
      if (!parsed.fcmTokens) {
        parsed.fcmTokens = {};
        changed = true;
      }
      if (!parsed.appStatus) {
        parsed.appStatus = 'active';
        changed = true;
      }
      if (changed) {
        fs.writeFileSync(DB_PATH, JSON.stringify(parsed, null, 2), 'utf-8');
      }
      return parsed;
    }
  } catch (e) {
    console.error('Error reading local DB, resetting to defaults:', e);
  }
  
  // Create dir if needed
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const defaultDB = getInitialDB();
  defaultDB.teachers = [];
  defaultDB.videos = [
    {
      id: 'Y3mK0_V6qC8',
      title: 'Théorème de Thalès - Cours de Géométrie 3ème (BEPC)',
      channelTitle: 'AlloSchool CI',
      duration: '12:45',
      viewCount: '15K vues',
      thumbnailUrl: 'https://images.unsplash.com/photo-1453733190148-c44698c265a8?w=600&auto=format&fit=crop&q=80'
    },
    {
      id: 'f8S6_N0qBv4',
      title: 'Solutions acides et basiques - Physique Chimie 3ème',
      channelTitle: "Télé-Enseignement Côte d'Ivoire",
      duration: '18:20',
      viewCount: '9.4K vues',
      thumbnailUrl: 'https://images.unsplash.com/photo-1532187643603-ba119ca4109e?w=600&auto=format&fit=crop&q=80'
    },
    {
      id: 'mL9S_B8xC2e',
      title: 'La fonction Logarithme Népérien : Limites et Dérivées - Terminale D',
      channelTitle: 'La Chaine Pédagogique',
      duration: '25:10',
      viewCount: '28K vues',
      thumbnailUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&auto=format&fit=crop&q=80'
    }
  ];
  fs.writeFileSync(DB_PATH, JSON.stringify(defaultDB, null, 2), 'utf-8');
  return defaultDB;
}

function saveDB(data: any) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving local DB:', e);
  }
}

function getUserProgress(userId: string | undefined): UserProgress {
  if (!userId) return dbData.progress; // fallback to legacy
  if (!dbData.userProgresses) dbData.userProgresses = {};
  if (!dbData.userProgresses[userId]) {
    dbData.userProgresses[userId] = {
      userId: userId,
      quizCount: 0,
      studyTimeMinutes: 0,
      streakDays: 0,
      completedQuizzes: [],
      completedSheets: [],
      favorites: [],
      downloads: []
    } as UserProgress;
    saveDB(dbData);
  }
  return dbData.userProgresses[userId];
}

function getUserSubscription(userId: string | undefined): SubscriptionState {
  if (!userId) return dbData.subscription; // fallback to legacy
  if (!dbData.userSubscriptions) dbData.userSubscriptions = {};
  if (!dbData.userSubscriptions[userId]) {
    dbData.userSubscriptions[userId] = {
      isPremium: true,
      trialEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      history: []
    } as SubscriptionState;
    saveDB(dbData);
  }
  return dbData.userSubscriptions[userId];
}

function getUserNotifications(userId: string | undefined): AppNotification[] {
  if (!userId) return dbData.notifications; // fallback to legacy
  if (!dbData.userNotifications) dbData.userNotifications = {};
  if (!dbData.userNotifications[userId]) {
    dbData.userNotifications[userId] = [
      {
        id: `notif-1-${Date.now()}`,
        title: 'Bienvenue sur Sankofa Educ ! 🇨🇮',
        body: 'Préparez vos examens BEPC, BAC et Concours avec les meilleurs fiches de révision de Côte d\'Ivoire.',
        date: new Date().toISOString(),
        read: false,
        type: 'info'
      },
      {
        id: `notif-2-${Date.now()}`,
        title: 'Application 100% Gratuite 🌟',
        body: 'Profitez de toutes les fiches, des quiz et du scanner IA de manière totalement gratuite !',
        date: new Date().toISOString(),
        read: false,
        type: 'info'
      }
    ] as AppNotification[];
    saveDB(dbData);
  }
  return dbData.userNotifications[userId];
}

// Ensure database is initialized
let dbData = loadDB();

// Initialize Gemini Client
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    console.log('Gemini AI initialized successfully.');
  } catch (error) {
    console.error('Failed to initialize Gemini Client:', error);
  }
} else {
  console.log('GEMINI_API_KEY not found. AI features will use highly realistic simulated extraction.');
}

// --- SEO / Google Search Engine Indexing Endpoints ---
app.get('/robots.txt', (req, res) => {
  res.type('text/plain');
  res.send(`# Robots.txt for Sankofa Educ - Google Search Engine Indexing
User-agent: *
Allow: /
Allow: /fiches
Allow: /quiz
Allow: /forum
Allow: /videos
Allow: /concours

Disallow: /api/
Disallow: /admin

Sitemap: https://sankofaeduc.ci/sitemap.xml
`);
});

app.get('/sitemap.xml', (req, res) => {
  res.type('application/xml');
  res.send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemap.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xsi:schemaLocation="http://www.sitemap.org/schemas/sitemap/0.9 http://www.sitemap.org/schemas/sitemap/0.9/sitemap.xsd">
  <url>
    <loc>https://sankofaeduc.ci/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://sankofaeduc.ci/#fiches</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://sankofaeduc.ci/#quiz</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>https://sankofaeduc.ci/#forum</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sankofaeduc.ci/#videos</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>https://sankofaeduc.ci/#concours</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>`);
});

// --- API ROUTES ---

// 1. Get All Core Data
app.get('/api/data', (req, res) => {
  const userId = req.query.userId as string;
  dbData = loadDB();

  const userProgress = getUserProgress(userId);
  const userSubscription = getUserSubscription(userId);
  const userNotifications = getUserNotifications(userId);

  res.json({
    success: true,
    appStatus: dbData.appStatus || 'active',
    sheets: dbData.sheets || [],
    quizzes: dbData.quizzes || [],
    favorites: userProgress.favorites || [],
    downloads: userProgress.downloads || [],
    completedSheets: userProgress.completedSheets || [],
    completedQuizzes: userProgress.completedQuizzes || [],
    notifications: userNotifications || [],
    isPremium: true,
    stats: {
      totalTime: userProgress.studyTimeMinutes || 0,
      quizAvg: userProgress.completedQuizzes && userProgress.completedQuizzes.length > 0
        ? Math.round(userProgress.completedQuizzes.reduce((acc: number, q: any) => acc + (q.score / q.total), 0) / userProgress.completedQuizzes.length * 100)
        : 0,
      rank: 'Major de promo 👑'
    }
  });
});

// App Status / Republication Control Endpoints
app.get('/api/app/status', (req, res) => {
  dbData = loadDB();
  res.json({
    success: true,
    appStatus: dbData.appStatus || 'active',
    updatedAt: new Date().toISOString()
  });
});

app.post('/api/app/status', (req, res) => {
  const { appStatus, reason } = req.body;
  if (appStatus !== 'active' && appStatus !== 'inactive') {
    return res.status(400).json({ success: false, error: 'Statut invalide. Utilisez "active" ou "inactive".' });
  }

  dbData = loadDB();
  dbData.appStatus = appStatus;

  // Add system notification if turning inactive for republication
  if (appStatus === 'inactive') {
    if (!dbData.notifications) dbData.notifications = [];
    dbData.notifications.unshift({
      id: `notif-repub-${Date.now()}`,
      title: '🔄 Republication en cours',
      body: reason || 'L\'application Sankofa Educ est temporairement inactive pour mise à jour et républication des contenus pédagogiques.',
      date: new Date().toISOString(),
      read: false,
      type: 'info'
    });
  }

  saveDB(dbData);
  console.log(`[APP STATUS] Application status set to: ${appStatus}`);

  res.json({
    success: true,
    appStatus: dbData.appStatus,
    message: appStatus === 'inactive'
      ? 'Application passée en mode inactif / républication.'
      : 'Application réactivée avec succès pour tous les utilisateurs.'
  });
});

// 2. Toggle Favorite
app.post('/api/toggle-favorite', (req, res) => {
  const { sheetId, userId } = req.body;
  dbData = loadDB();
  
  const progress = getUserProgress(userId);
  const favorites = progress.favorites || [];
  const index = favorites.indexOf(sheetId);
  
  if (index > -1) {
    favorites.splice(index, 1);
  } else {
    favorites.push(sheetId);
  }
  
  progress.favorites = favorites;
  saveDB(dbData);
  res.json({ favorites });
});

// 3. Toggle Download / Save Offline
app.post('/api/toggle-download', (req, res) => {
  const { sheetId, userId } = req.body;
  dbData = loadDB();
  
  const progress = getUserProgress(userId);
  const downloads = progress.downloads || [];
  const index = downloads.indexOf(sheetId);
  
  if (index > -1) {
    downloads.splice(index, 1);
  } else {
    downloads.push(sheetId);
  }
  
  progress.downloads = downloads;
  saveDB(dbData);
  res.json({ downloads });
});

// 4. Submit Quiz Result
app.post('/api/complete-quiz', (req, res) => {
  const { quizId, score, total, userId } = req.body;
  dbData = loadDB();
  
  const quiz = dbData.quizzes.find((q: Quiz) => q.id === quizId);
  if (!quiz) {
    return res.status(404).json({ error: 'Quiz non trouvé' });
  }

  const progress = getUserProgress(userId);
  const notifications = getUserNotifications(userId);

  // Update progress
  progress.quizCount = (progress.quizCount || 0) + 1;
  progress.studyTimeMinutes = (progress.studyTimeMinutes || 0) + 15; // 15 mins estimated per quiz
  
  // Streak increase
  const todayStr = new Date().toDateString();
  const lastAttempt = progress.completedQuizzes[0];
  if (lastAttempt) {
    const lastAttemptDate = new Date(lastAttempt.date).toDateString();
    if (lastAttemptDate !== todayStr) {
      progress.streakDays = (progress.streakDays || 0) + 1;
    }
  } else {
    progress.streakDays = 1;
  }

  // Save attempt
  progress.completedQuizzes.unshift({
    quizId,
    quizTitle: quiz.title,
    subject: quiz.subject,
    exam: quiz.exam,
    score,
    total,
    date: new Date().toISOString()
  });

  // Mark associated sheet as completed if there is one
  if (quiz.sheetId && !progress.completedSheets.includes(quiz.sheetId)) {
    progress.completedSheets.push(quiz.sheetId);
  }

  // Add a notification for milestone
  if (score === total) {
    notifications.unshift({
      id: `notif-${Date.now()}`,
      title: 'Score Parfait ! 🎉',
      body: `Félicitations ! Vous avez obtenu un score parfait de ${score}/${total} sur le quiz : ${quiz.title}.`,
      date: new Date().toISOString(),
      read: false,
      type: 'quiz'
    });
  }

  saveDB(dbData);
  res.json({
    progress,
    notifications
  });
});

// 5. Mark Sheet as Read/Studied
app.post('/api/complete-sheet', (req, res) => {
  const { sheetId, userId } = req.body;
  dbData = loadDB();
  
  const progress = getUserProgress(userId);
  if (!progress.completedSheets.includes(sheetId)) {
    progress.completedSheets.push(sheetId);
    progress.studyTimeMinutes = (progress.studyTimeMinutes || 0) + 10; // 10 minutes per study card
    saveDB(dbData);
  }
  
  res.json({ progress });
});

// 6. Premium Subscription Simulation
app.post('/api/subscribe', (req, res) => {
  const { phoneNumber, paymentMethod, amount, userId } = req.body;
  dbData = loadDB();

  const purchaseId = `PAY-${Date.now()}`;
  const sub = getUserSubscription(userId);
  const notifications = getUserNotifications(userId);
  
  // Update subscription
  sub.isPremium = true;
  sub.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days
  sub.paymentMethod = paymentMethod;
  sub.phoneNumber = phoneNumber;
  
  // Add payment history
  sub.history.unshift({
    id: purchaseId,
    amount: amount || 2000,
    date: new Date().toISOString(),
    status: 'Succès',
    method: paymentMethod,
    phone: phoneNumber
  });

  // Add Notification
  notifications.unshift({
    id: `notif-${Date.now()}`,
    title: 'Abonnement Premium Actif 🌟',
    body: `Merci pour votre confiance ! Votre abonnement premium est actif jusqu'au ${new Date(sub.expiresAt).toLocaleDateString('fr-FR')}.`,
    date: new Date().toISOString(),
    read: false,
    type: 'sub'
  });

  saveDB(dbData);
  res.json({
    subscription: sub,
    notifications
  });
});

// 7. Mark Notification as Read
app.post('/api/notifications/read', (req, res) => {
  const { notificationId, userId } = req.body;
  dbData = loadDB();
  
  if (userId) {
    if (!dbData.userNotifications) dbData.userNotifications = {};
    if (!dbData.userNotifications[userId]) dbData.userNotifications[userId] = [];
    dbData.userNotifications[userId] = dbData.userNotifications[userId].map((n: any) => {
      if (n.id === notificationId) {
        return { ...n, read: true };
      }
      return n;
    });
    saveDB(dbData);
    res.json({ notifications: dbData.userNotifications[userId] });
  } else {
    dbData.notifications = dbData.notifications.map((n: AppNotification) => {
      if (n.id === notificationId) {
        return { ...n, read: true };
      }
      return n;
    });
    saveDB(dbData);
    res.json({ notifications: dbData.notifications });
  }
});

// 8. Admin : Add Revision Sheet and Quiz
app.post('/api/admin/add-fiche', (req, res) => {
  const { title, exam, subject, chapter, summary, content, formulas, definitions, illustrationUrl } = req.body;
  dbData = loadDB();

  const newId = `${exam.toLowerCase()}-${subject.toLowerCase()}-${Date.now()}`.replace(/\s+/g, '-');
  const newSheet: RevisionSheet = {
    id: newId,
    title,
    exam,
    subject,
    chapter,
    summary,
    content,
    formulas: formulas || [],
    definitions: definitions || [],
    isDownloaded: false,
    isFavorite: false,
    illustrationUrl: illustrationUrl || 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=600&auto=format&fit=crop&q=80'
  };

  dbData.sheets.push(newSheet);

  // Auto-generate empty quiz for this sheet to fill
  const newQuiz: Quiz = {
    id: `quiz-${newId}`,
    title: `Quiz de validation : ${title}`,
    sheetId: newId,
    subject,
    exam,
    difficulty: 'Moyen',
    questions: [
      {
        id: `q-${Date.now()}-1`,
        type: 'VraiFaux',
        question: `La leçon "${title}" traite de "${chapter}".`,
        correctAnswer: 'Vrai',
        explanation: `Oui, le chapitre correspondant est bien ${chapter}.`
      }
    ]
  };

  dbData.quizzes.push(newQuiz);

  // Broadcast Notification
  dbData.notifications.unshift({
    id: `notif-${Date.now()}`,
    title: `Nouvelle fiche de révision : ${title} 📚`,
    body: `Une nouvelle leçon de ${subject} est disponible pour les candidats au ${exam}. Réviser dès maintenant !`,
    date: new Date().toISOString(),
    read: false,
    type: 'info'
  });

  saveDB(dbData);
  res.json({
    sheets: dbData.sheets,
    quizzes: dbData.quizzes,
    notifications: dbData.notifications
  });
});

// 9. Admin : Delete Fiche
app.delete('/api/admin/delete-fiche/:id', (req, res) => {
  const { id } = req.params;
  dbData = loadDB();

  dbData.sheets = dbData.sheets.filter((s: RevisionSheet) => s.id !== id);
  dbData.quizzes = dbData.quizzes.filter((q: Quiz) => q.sheetId !== id);

  saveDB(dbData);
  res.json({
    sheets: dbData.sheets,
    quizzes: dbData.quizzes
  });
});

// 10. Admin : Send Notification Broadcast
app.post('/api/admin/notify', (req, res) => {
  const { title, body } = req.body;
  dbData = loadDB();

  dbData.notifications.unshift({
    id: `notif-${Date.now()}`,
    title,
    body,
    date: new Date().toISOString(),
    read: false,
    type: 'info'
  });

  saveDB(dbData);
  res.json({ notifications: dbData.notifications });
});

// --- TEACHER / ADMIN AUTHENTICATION ENDPOINTS ---
app.post('/api/admin/teachers/register', (req, res) => {
  const { name, email, password, subject, activationCode } = req.body;
  dbData = loadDB();

  if (!name || !email || !password || !subject || !activationCode) {
    return res.status(400).json({ success: false, error: 'Tous les champs sont requis.' });
  }

  // Security check for activation code
  const code = activationCode.trim().toLowerCase();
  if (code !== 'sankofa225' && code !== 'enseignant' && code !== 'admin') {
    return res.status(400).json({ success: false, error: "Code d'activation de l'enseignant incorrect. Utilisez 'sankofa225'." });
  }

  if (!dbData.teachers) {
    dbData.teachers = [];
  }

  const emailLower = email.trim().toLowerCase();
  const exists = dbData.teachers.some((t: any) => t.email.toLowerCase() === emailLower);
  if (exists) {
    return res.status(400).json({ success: false, error: 'Un enseignant avec cet email existe déjà.' });
  }

  const newTeacher = {
    id: `teacher-${Date.now()}`,
    name: name.trim(),
    email: emailLower,
    password: password,
    subject: subject,
    createdAt: new Date().toISOString()
  };

  dbData.teachers.push(newTeacher);
  saveDB(dbData);

  res.json({
    success: true,
    message: 'Inscription de l\'enseignant réussie ! Connectez-vous maintenant.',
    teacher: {
      name: newTeacher.name,
      email: newTeacher.email,
      subject: newTeacher.subject
    }
  });
});

app.post('/api/admin/teachers/login', (req, res) => {
  const { email, password } = req.body;
  dbData = loadDB();

  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email et mot de passe requis.' });
  }

  if (!dbData.teachers) {
    dbData.teachers = [];
  }

  // Backdoor master account for demo/fallback
  if (email === 'admin@sankofa.ci' && (password === 'admin' || password === 'sankofa225')) {
    return res.json({
      success: true,
      teacher: {
        name: 'Administrateur Général',
        email: 'admin@sankofa.ci',
        subject: 'Toutes les matières'
      }
    });
  }

  const emailLower = email.trim().toLowerCase();
  const teacher = dbData.teachers.find((t: any) => t.email.toLowerCase() === emailLower && t.password === password);

  if (!teacher) {
    return res.status(401).json({ success: false, error: 'Email ou mot de passe incorrect.' });
  }

  res.json({
    success: true,
    teacher: {
      name: teacher.name,
      email: teacher.email,
      subject: teacher.subject
    }
  });
});

// --- CURATED VIDEOS API ENDPOINTS ---
app.get('/api/videos', (req, res) => {
  dbData = loadDB();
  res.json({
    success: true,
    videos: dbData.videos || []
  });
});

app.post('/api/videos', (req, res) => {
  const { id, title, channelTitle, duration, viewCount, thumbnailUrl } = req.body;
  dbData = loadDB();

  if (!id || !title || !channelTitle || !duration) {
    return res.status(400).json({ success: false, error: 'Champs requis manquants.' });
  }

  if (!dbData.videos) {
    dbData.videos = [];
  }

  const finalThumbnail = thumbnailUrl || `https://img.youtube.com/vi/${id}/mqdefault.jpg`;

  const newVideo = {
    id,
    title,
    channelTitle,
    duration,
    viewCount: viewCount || '0 vue',
    thumbnailUrl: finalThumbnail
  };

  dbData.videos = dbData.videos.filter((v: any) => v.id !== id);
  dbData.videos.unshift(newVideo);
  saveDB(dbData);

  res.json({
    success: true,
    video: newVideo,
    videos: dbData.videos
  });
});

app.put('/api/videos/:id', (req, res) => {
  const { id } = req.params;
  const { title, channelTitle, duration, viewCount, thumbnailUrl } = req.body;
  dbData = loadDB();

  if (!dbData.videos) dbData.videos = [];

  const index = dbData.videos.findIndex((v: any) => v.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, error: 'Vidéo non trouvée.' });
  }

  const finalThumbnail = thumbnailUrl || `https://img.youtube.com/vi/${id}/mqdefault.jpg`;

  dbData.videos[index] = {
    ...dbData.videos[index],
    title: title || dbData.videos[index].title,
    channelTitle: channelTitle || dbData.videos[index].channelTitle,
    duration: duration || dbData.videos[index].duration,
    viewCount: viewCount || dbData.videos[index].viewCount,
    thumbnailUrl: finalThumbnail
  };

  saveDB(dbData);

  res.json({
    success: true,
    video: dbData.videos[index],
    videos: dbData.videos
  });
});

app.delete('/api/videos/:id', (req, res) => {
  const { id } = req.params;
  dbData = loadDB();

  if (!dbData.videos) dbData.videos = [];

  dbData.videos = dbData.videos.filter((v: any) => v.id !== id);
  saveDB(dbData);

  res.json({
    success: true,
    message: 'Vidéo supprimée avec succès.',
    videos: dbData.videos
  });
});

// FORUM & QUESTIONNAIRE ENDPOINTS
app.get('/api/forum/questions', (req, res) => {
  dbData = loadDB();
  res.json({
    success: true,
    questions: dbData.questions || []
  });
});

app.post('/api/forum/questions', (req, res) => {
  const { authorName, authorExam, subject, title, content } = req.body;
  if (!title || !content || !subject) {
    return res.status(400).json({ success: false, error: 'Champs obligatoires manquants.' });
  }

  dbData = loadDB();
  if (!dbData.questions) dbData.questions = [];

  const newQuestion: ForumQuestion = {
    id: `q-${Date.now()}`,
    authorName: authorName || 'Élève Sankofa',
    authorExam: authorExam || 'BAC',
    subject: subject || 'Mathématiques',
    title,
    content,
    createdAt: new Date().toISOString(),
    likes: 0,
    answers: [],
    isResolved: false
  };

  dbData.questions.unshift(newQuestion);
  saveDB(dbData);

  res.json({
    success: true,
    message: 'Question publiée avec succès !',
    question: newQuestion,
    questions: dbData.questions
  });
});

app.post('/api/forum/questions/:id/answers', (req, res) => {
  const { id } = req.params;
  const { authorName, authorRole, content } = req.body;

  if (!content) {
    return res.status(400).json({ success: false, error: 'Le contenu de la réponse ne peut pas être vide.' });
  }

  dbData = loadDB();
  if (!dbData.questions) dbData.questions = [];

  const question = dbData.questions.find((q: ForumQuestion) => q.id === id);
  if (!question) {
    return res.status(404).json({ success: false, error: 'Question introuvable.' });
  }

  const newAnswer: ForumAnswer = {
    id: `ans-${Date.now()}`,
    authorName: authorName || 'Anonyme',
    authorRole: authorRole || 'Élève',
    content,
    createdAt: new Date().toISOString(),
    likes: 0
  };

  if (!question.answers) question.answers = [];
  question.answers.push(newAnswer);

  if (authorRole === 'Enseignant' || authorRole === 'Admin') {
    question.isResolved = true;
  }

  saveDB(dbData);

  res.json({
    success: true,
    message: 'Réponse ajoutée.',
    questions: dbData.questions
  });
});

app.post('/api/forum/questions/:id/like', (req, res) => {
  const { id } = req.params;
  dbData = loadDB();
  if (!dbData.questions) dbData.questions = [];

  const question = dbData.questions.find((q: ForumQuestion) => q.id === id);
  if (question) {
    question.likes = (question.likes || 0) + 1;
    saveDB(dbData);
  }

  res.json({
    success: true,
    questions: dbData.questions
  });
});

app.delete('/api/forum/questions/:id', (req, res) => {
  const { id } = req.params;
  dbData = loadDB();
  if (!dbData.questions) dbData.questions = [];

  dbData.questions = dbData.questions.filter((q: ForumQuestion) => q.id !== id);
  saveDB(dbData);

  res.json({
    success: true,
    message: 'Question supprimée.',
    questions: dbData.questions
  });
});

// 11. AI Scanner OCR & Revision Card Generation Endpoint
app.post('/api/gemini/scan', async (req, res) => {
  const { examType, subject, sampleText, base64Image, mimeType } = req.body;
  console.log(`Starting scan for ${examType} - ${subject}...`);
  
  dbData = loadDB();

  if (ai) {
    try {
      let contents: any[] = [];
      let promptText = `Tu es une IA experte de l'éducation en Côte d'Ivoire. Ton objectif est d'aider les élèves à réviser le ${examType} en créant une fiche de révision premium et un quiz complet à partir de ce texte ou de cette image.
      Matière : ${subject}
      Niveau/Examen : ${examType}

      Analyse le contenu fourni et extrait/génère une fiche de révision de très haute qualité en français avec la structure JSON demandée.
      Le champ "content" doit être détaillé, rédigé en Markdown propre avec des titres de sections, des explications claires et de niveau académique ivoirien. Les formules mathématiques ou physiques doivent être bien écrites.
      Le mini-quiz doit comporter exactement 3 questions pertinentes basées sur la leçon (1 QCM, 1 VraiFaux, et 1 Libre). Pour la question "Libre", la réponse doit être courte (un chiffre ou un mot simple).
      La réponse DOIT respecter strictement le schéma JSON défini.`;

      if (base64Image) {
        contents = [
          {
            inlineData: {
              mimeType: mimeType || 'image/jpeg',
              data: base64Image
            }
          },
          { text: promptText }
        ];
      } else {
        contents = [`${promptText}\n\nTexte source extrait :\n${sampleText || 'Leçons de mathématiques ou de sciences.'}`];
      }

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Un titre élégant et académique pour cette fiche de révision." },
          chapter: { type: Type.STRING, description: "Le chapitre ou domaine correspondant à la leçon (ex: Algèbre, Électricité, Civilisation)." },
          summary: { type: Type.STRING, description: "Un résumé accrocheur et synthétique de la leçon en 2-3 phrases." },
          content: { type: Type.STRING, description: "Le contenu ultra détaillé du cours structuré en Markdown français avec des sections claires (ex: ### 1. Titre, tirets, etc.)." },
          formulas: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Liste des formules clés à mémoriser (au moins 2)."
          },
          definitions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                term: { type: Type.STRING, description: "Le mot clé ou concept." },
                definition: { type: Type.STRING, description: "La définition simple et claire en français." }
              },
              required: ["term", "definition"]
            },
            description: "Liste des notions clés et des définitions importantes (au moins 2)."
          },
          youtubeKeywords: { type: Type.STRING, description: "Mots-clés de recherche YouTube optimaux en français pour cette leçon (ex: 'cours fonctions logarithmes terminale d')." },
          quizQuestions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING, enum: ["QCM", "VraiFaux", "Libre"] },
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Requis SEULEMENT si type est QCM. Fournir 4 choix cohérents." },
                correctAnswer: { type: Type.STRING, description: "La réponse correcte exacte (pour VraiFaux: 'Vrai' ou 'Faux'. Pour Libre: mot clé court ou chiffre)." },
                explanation: { type: Type.STRING, description: "Explication claire et pédagogique de la réponse." }
              },
              required: ["type", "question", "correctAnswer", "explanation"]
            },
            description: "Exactement 3 questions de quiz pour valider la fiche."
          }
        },
        required: ["title", "chapter", "summary", "content", "formulas", "definitions", "youtubeKeywords", "quizQuestions"]
      };

      const result = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema
        }
      });

      const rawJson = result.text;
      console.log('Gemini raw response fetched.');
      
      const parsedData = JSON.parse(rawJson.trim());

      // Format Sheet and Quiz to match our model
      const sheetId = `ai-fiche-${Date.now()}`;
      const newSheet: RevisionSheet = {
        id: sheetId,
        title: parsedData.title,
        exam: examType as ExamType,
        subject,
        chapter: parsedData.chapter || 'Général',
        summary: parsedData.summary,
        content: parsedData.content,
        formulas: parsedData.formulas,
        definitions: parsedData.definitions,
        youtubeKeywords: parsedData.youtubeKeywords,
        isDownloaded: true,
        isFavorite: false,
        isAIGenerated: true,
        illustrationUrl: 'https://images.unsplash.com/photo-1616469829581-73993eb86b02?w=600&auto=format&fit=crop&q=80'
      };

      const newQuiz: Quiz = {
        id: `quiz-${sheetId}`,
        title: `Quiz IA : ${parsedData.title}`,
        sheetId,
        subject,
        exam: examType as ExamType,
        difficulty: 'Moyen',
        questions: parsedData.quizQuestions.map((q: any, i: number) => ({
          id: `q-ai-${sheetId}-${i}`,
          type: q.type,
          question: q.question,
          options: q.options,
          correctAnswer: q.correctAnswer,
          explanation: q.explanation
        }))
      };

      // Push into database
      dbData.sheets.push(newSheet);
      dbData.quizzes.push(newQuiz);

      // Add Notification
      dbData.notifications.unshift({
        id: `notif-${Date.now()}`,
        title: 'Fiche générée par l\'IA ! ✨🤖',
        body: `Votre cours sur "${parsedData.title}" (${subject}) a été numérisé, résumé et doté d'un quiz personnalisé par notre IA Sankofa.`,
        date: new Date().toISOString(),
        read: false,
        type: 'info'
      });

      saveDB(dbData);
      
      return res.json({
        success: true,
        sheet: newSheet,
        quiz: newQuiz
      });

    } catch (e: any) {
      console.error('Gemini processing error, falling back to simulated generation:', e);
      // Fallback
    }
  }

  // Fallback simulated generation if API is not available or errors out
  console.log('Running simulated revision card generation (Fallback)...');
  const delay = (ms: number) => new Promise(res => setTimeout(res, ms));
  await delay(2000); // simulate thinking

  const titles = [
    `Fiche d'étude : ${subject || 'Sciences'} - Concepts Clés`,
    `Résumé express : Les Fondamentaux de ${subject || 'Français'}`,
    `Synthèse Numérisée : Réussir le ${examType} - ${subject || 'Histoire'}`
  ];
  
  const selectedTitle = titles[Math.floor(Math.random() * titles.length)];
  const sheetId = `sim-fiche-${Date.now()}`;
  
  const sampleContent = `### Introduction générale
Ce document résume les notions fondamentales apprises lors de l'étude. Idéal pour la préparation de l'examen du **${examType}** en Côte d'Ivoire.

### 1. Les Notions Clés
La maîtrise de cette leçon implique la compréhension fine des mécanismes décrits ci-dessous :
* **Rigueur de raisonnement** : Chaque démonstration doit s'appuyer sur des propriétés précises.
* **Mise en pratique** : L'exercice régulier permet de fixer les connaissances à long terme.

### 2. Conseils pour le Jour J
* Lisez attentivement l'énoncé en entier avant de commencer à rédiger votre copie.
* Prenez soin de la présentation et écrivez lisiblement pour le correcteur.`;

  const newSheet: RevisionSheet = {
    id: sheetId,
    title: selectedTitle,
    exam: examType as ExamType,
    subject: subject || 'Culture Générale',
    chapter: 'Numérisation IA',
    summary: 'Cette fiche a été automatiquement extraite et rédigée par l’intelligence artificielle Sankofa Educ à partir d\'un document ou d\'une image fournie par l\'élève.',
    content: sampleContent,
    formulas: [
      'Formule de concentration : C = n / V',
      'Principe fondamental : L\'effort régulier surpasse le talent brut.'
    ],
    definitions: [
      { term: 'Méthodologie', definition: 'Ensemble de méthodes et de règles suivies dans une science ou une révision.' },
      { term: 'Sankofa', definition: 'Symbole africain signifiant "retourner chercher ce qui est oublié", reliant le passé à l\'éducation future.' }
    ],
    youtubeKeywords: `cours ${subject || 'cours'} ${examType.toLowerCase()}`,
    isDownloaded: true,
    isFavorite: false,
    isAIGenerated: true,
    illustrationUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=80'
  };

  const newQuiz: Quiz = {
    id: `quiz-${sheetId}`,
    title: `Quiz IA : ${selectedTitle}`,
    sheetId,
    subject: subject || 'Culture Générale',
    exam: examType as ExamType,
    difficulty: 'Moyen',
    questions: [
      {
        id: `q-sim-1`,
        type: 'QCM',
        question: `À quel examen s'adresse cette fiche générée par l'intelligence artificielle ?`,
        options: ['BEPC uniquement', 'BAC uniquement', `Le ${examType}`, 'Aucun de ces examens'],
        correctAnswer: `Le ${examType}`,
        explanation: `La fiche a été spécifiquement étiquetée et structurée pour l'examen du ${examType}.`
      },
      {
        id: `q-sim-2`,
        type: 'VraiFaux',
        question: `Le symbole Sankofa est lié à la notion de retour aux sources et d'apprentissage du passé.`,
        correctAnswer: 'Vrai',
        explanation: 'Sankofa est un symbole Akan représenté par un oiseau qui regarde en arrière, signifiant qu\'il est sage de s\'inspirer du passé pour construire l\'avenir.'
      },
      {
        id: `q-sim-3`,
        type: 'Libre',
        question: 'Quel est le nombre total de questions contenues dans ce mini-quiz IA (répondre en chiffre) ?',
        correctAnswer: '3',
        explanation: 'Ce mini-quiz généré automatiquement comporte exactement 3 questions d\'évaluation.'
      }
    ]
  };

  dbData.sheets.push(newSheet);
  dbData.quizzes.push(newQuiz);

  dbData.notifications.unshift({
    id: `notif-${Date.now()}`,
    title: 'Fiche simulée générée avec succès ! ✨',
    body: `Votre fiche de ${subject} pour le ${examType} est prête. (Gemini s'est exécuté en mode simulation pour assurer la continuité).`,
    date: new Date().toISOString(),
    read: false,
    type: 'info'
  });

  saveDB(dbData);

  res.json({
    success: true,
    sheet: newSheet,
    quiz: newQuiz
  });
});

// --- COMPATIBILITY ENDPOINTS BETWEEN FRONTEND & BACKEND ---

app.post('/api/user/favorite', (req, res) => {
  const { id, userId } = req.body;
  dbData = loadDB();
  const progress = getUserProgress(userId);
  const favorites = progress.favorites || [];
  const index = favorites.indexOf(id);
  if (index > -1) {
    favorites.splice(index, 1);
  } else {
    favorites.push(id);
  }
  progress.favorites = favorites;
  saveDB(dbData);
  res.json({ success: true, favorites });
});

app.post('/api/user/download', (req, res) => {
  const { id, userId } = req.body;
  dbData = loadDB();
  const progress = getUserProgress(userId);
  const downloads = progress.downloads || [];
  const index = downloads.indexOf(id);
  if (index > -1) {
    downloads.splice(index, 1);
  } else {
    downloads.push(id);
  }
  progress.downloads = downloads;
  saveDB(dbData);
  res.json({ success: true, downloads });
});

app.post('/api/user/sheet/complete', (req, res) => {
  const { id, userId } = req.body;
  dbData = loadDB();
  const progress = getUserProgress(userId);
  if (!progress.completedSheets.includes(id)) {
    progress.completedSheets.push(id);
    progress.studyTimeMinutes = (progress.studyTimeMinutes || 0) + 10;
    saveDB(dbData);
  }
  res.json({ success: true, completedSheets: progress.completedSheets });
});

app.post('/api/user/quiz/complete', (req, res) => {
  const { id, score, total, userId } = req.body;
  dbData = loadDB();
  const quiz = dbData.quizzes.find((q: Quiz) => q.id === id);
  if (!quiz) {
    return res.status(404).json({ error: 'Quiz non trouvé' });
  }

  const progress = getUserProgress(userId);
  progress.quizCount = (progress.quizCount || 0) + 1;
  progress.studyTimeMinutes = (progress.studyTimeMinutes || 0) + 15;

  progress.completedQuizzes.unshift({
    quizId: id,
    quizTitle: quiz.title,
    subject: quiz.subject,
    exam: quiz.exam,
    score,
    total,
    date: new Date().toISOString()
  });

  if (quiz.sheetId && !progress.completedSheets.includes(quiz.sheetId)) {
    progress.completedSheets.push(quiz.sheetId);
  }

  saveDB(dbData);
  res.json({ success: true, completedQuizzes: progress.completedQuizzes });
});

app.post('/api/user/subscribe', (req, res) => {
  const { phoneNumber, paymentMethod, amount, userId } = req.body;
  dbData = loadDB();
  
  const sub = getUserSubscription(userId);
  const notifications = getUserNotifications(userId);
  
  sub.isPremium = true;
  sub.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
  sub.paymentMethod = paymentMethod || 'Orange Money';
  sub.phoneNumber = phoneNumber || '0707070707';
  
  sub.history.unshift({
    id: `PAY-${Date.now()}`,
    amount: amount || 2000,
    date: new Date().toISOString(),
    status: 'Succès',
    method: paymentMethod || 'Orange Money',
    phone: phoneNumber || '0707070707'
  });

  notifications.unshift({
    id: `notif-${Date.now()}`,
    title: 'Abonnement Premium Actif 🌟',
    body: `Merci ! Votre abonnement premium est actif jusqu'au ${new Date(sub.expiresAt).toLocaleDateString('fr-FR')}.`,
    date: new Date().toISOString(),
    read: false,
    type: 'sub'
  });

  saveDB(dbData);
  res.json({ success: true, subscription: sub, notifications });
});

app.post('/api/fiches', (req, res) => {
  const { title, exam, subject, chapter, summary, content, formulas, definitions, youtubeKeywords } = req.body;
  dbData = loadDB();
  const sheetId = `fiche-manual-${Date.now()}`;
  const newSheet: RevisionSheet = {
    id: sheetId,
    title,
    exam,
    subject,
    chapter: chapter || 'Général',
    summary,
    content,
    formulas: Array.isArray(formulas) ? formulas : formulas ? [formulas] : [],
    definitions: Array.isArray(definitions) ? definitions : [],
    youtubeKeywords: youtubeKeywords || '',
    isDownloaded: true,
    isFavorite: false
  };

  const newQuiz: Quiz = {
    id: `quiz-${sheetId}`,
    title: `Quiz : ${title}`,
    sheetId,
    subject,
    exam,
    difficulty: 'Facile',
    questions: [
      {
        id: `q-man-${Date.now()}-1`,
        type: 'VraiFaux',
        question: `La leçon "${title}" traite du sujet principal décrit.`,
        correctAnswer: 'Vrai',
        explanation: 'Validation générale de la leçon.'
      }
    ]
  };

  dbData.sheets.unshift(newSheet);
  dbData.quizzes.unshift(newQuiz);
  saveDB(dbData);
  res.json({ success: true, sheet: newSheet });
});

app.delete('/api/fiches/:id', (req, res) => {
  const { id } = req.params;
  dbData = loadDB();
  dbData.sheets = dbData.sheets.filter((s: RevisionSheet) => s.id !== id);
  dbData.quizzes = dbData.quizzes.filter((q: Quiz) => q.sheetId !== id);
  saveDB(dbData);
  res.json({ success: true });
});

app.post('/api/notifications/broadcast', (req, res) => {
  const { title, body } = req.body;
  dbData = loadDB();
  dbData.notifications.unshift({
    id: `notif-broad-${Date.now()}`,
    title,
    body,
    date: new Date().toISOString(),
    read: false,
    type: 'broadcast'
  });
  saveDB(dbData);
  const registeredFcmCount = Object.keys(dbData.fcmTokens || {}).length;
  res.json({ success: true, notifications: dbData.notifications, fcmDevices: registeredFcmCount });
});

// --- FIREBASE CLOUD MESSAGING (FCM) ENDPOINTS ---
app.post('/api/fcm/token', (req, res) => {
  const { userId, token } = req.body;
  if (!token) {
    return res.status(400).json({ success: false, error: 'Jeton FCM requis.' });
  }

  dbData = loadDB();
  if (!dbData.fcmTokens) dbData.fcmTokens = {};

  const tokenKey = token.slice(-32);
  dbData.fcmTokens[tokenKey] = {
    token,
    userId: userId || 'anonymous',
    updatedAt: new Date().toISOString()
  };
  saveDB(dbData);

  console.log(`[FCM SERVER] Jeton enregistré (${userId || 'anonyme'}): ${token.slice(0, 15)}...`);
  res.json({ success: true, message: 'Jeton FCM enregistré avec succès' });
});

app.get('/api/fcm/status', (req, res) => {
  dbData = loadDB();
  const tokenCount = Object.keys(dbData.fcmTokens || {}).length;
  res.json({
    success: true,
    fcmEnabled: true,
    registeredDevicesCount: tokenCount,
    messagingSenderId: '27739222968'
  });
});

// Real-time YouTube search endpoint
app.get('/api/youtube/search', async (req, res) => {
  const query = req.query.q as string || '';
  if (!query) {
    return res.json({ success: true, videos: [] });
  }

  try {
    const results = await yts(query);
    const videos = results.videos.slice(0, 15).map(v => ({
      id: v.videoId,
      title: v.title,
      channelTitle: v.author.name,
      duration: v.timestamp || v.duration.toString(),
      viewCount: `${v.views >= 1000 ? Math.round(v.views / 1000) + 'K' : v.views} vues`,
      thumbnailUrl: v.thumbnail || v.image
    }));
    res.json({ success: true, videos });
  } catch (error) {
    console.error('YouTube search error:', error);
    res.status(500).json({ success: false, error: 'Erreur lors de la recherche YouTube en temps réel' });
  }
});


// --- PAYMENTS REGIONAL MOBILE MONEY API GATEWAY ---

function getCinetPayConfig() {
  return {
    apiKey: process.env.CINETPAY_API_KEY,
    siteId: process.env.CINETPAY_SITE_ID,
    isConfigured: !!(process.env.CINETPAY_API_KEY && process.env.CINETPAY_SITE_ID)
  };
}

app.post('/api/payments/initiate', async (req, res) => {
  const { phoneNumber, provider, amount, userId, name, email } = req.body;
  dbData = loadDB();

  if (!phoneNumber) {
    return res.status(400).json({ success: false, error: 'Numéro de téléphone requis.' });
  }

  const cinetPay = getCinetPayConfig();

  // --- COLD COUPLING PATH: IF REAL CINETPAY IS CONFIGURED ---
  if (cinetPay.isConfigured) {
    try {
      const transactionId = `SANKOFA-TX-${Date.now()}`;
      const finalAmount = Number(amount) || 2000;
      
      const cleanEmail = email || `${userId || 'student'}@sankofa-educ.ci`;
      const cleanName = name || 'Élève';
      const cleanPhone = phoneNumber;
      
      let formattedPhone = cleanPhone.replace(/\s+/g, '');
      if (!formattedPhone.startsWith('+')) {
        if (formattedPhone.startsWith('225')) {
          formattedPhone = '+' + formattedPhone;
        } else {
          formattedPhone = '+225' + formattedPhone;
        }
      }

      const returnUrl = `${process.env.APP_URL || 'http://localhost:3000'}/?payment=check&tx=${transactionId}&userId=${userId || ''}`;
      const notifyUrl = `${process.env.APP_URL || 'http://localhost:3000'}/api/payments/cinetpay-webhook`;

      const payload = {
        apikey: cinetPay.apiKey,
        site_id: cinetPay.siteId,
        transaction_id: transactionId,
        amount: finalAmount,
        currency: "XOF",
        alternative_currency: "",
        description: `Abonnement Premium Sankofa Educ - Révision examens`,
        customer_id: userId || cleanEmail,
        customer_name: cleanName,
        customer_surname: "Sankofa",
        customer_email: cleanEmail,
        customer_phone_number: formattedPhone,
        customer_address: "Abidjan",
        customer_city: "Abidjan",
        customer_country: "CI",
        customer_state: "CI",
        customer_zip_code: "00225",
        channels: "ALL",
        return_url: returnUrl,
        notify_url: notifyUrl
      };

      console.log('Initiating real CinetPay transaction:', transactionId);
      
      const cpResponse = await fetch('https://api-checkout.cinetpay.com/v2/payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const result = await cpResponse.json();
      console.log('CinetPay API Response:', result);

      if ((result.code === '201' || result.message === 'CREATED') && result.data && result.data.payment_url) {
        if (!dbData.pendingPayments) {
          dbData.pendingPayments = {};
        }
        dbData.pendingPayments[transactionId] = {
          transactionId,
          phoneNumber: cleanPhone,
          provider: provider || 'cinetpay',
          amount: finalAmount,
          userId: userId || cleanEmail,
          status: 'En attente',
          realCinetPay: true,
          createdAt: new Date().toISOString()
        };
        saveDB(dbData);

        return res.json({
          success: true,
          useCinetPay: true,
          paymentUrl: result.data.payment_url,
          transactionId
        });
      } else {
        console.error('CinetPay setup rejected:', result);
        return res.status(500).json({ 
          success: false, 
          error: `Erreur d'initialisation CinetPay: ${result.description || result.message || 'Clés incorrectes'}` 
        });
      }
    } catch (err: any) {
      console.error('CinetPay connection error:', err);
      // Fall back gracefully to simulator if gateway is completely unreachable
    }
  }

  // --- GRADUAL FALLBACK PATH: SIMULATED/TWILIO FLOW ---
  const transactionId = `SANKOFA-TX-${Date.now()}`;
  const otpCode = Math.floor(1000 + Math.random() * 9000).toString(); 

  if (!dbData.pendingPayments) {
    dbData.pendingPayments = {};
  }

  dbData.pendingPayments[transactionId] = {
    transactionId,
    phoneNumber,
    provider,
    amount: amount || 2000,
    userId,
    status: 'En attente',
    otpCode,
    createdAt: new Date().toISOString()
  };

  saveDB(dbData);

  const client = getTwilioClient();
  const fromNumber = process.env.TWILIO_PHONE_NUMBER;
  let twilioStatus = 'not_configured';
  let twilioError = null;

  if (client && fromNumber) {
    let formattedPhone = phoneNumber.replace(/\s+/g, '');
    if (!formattedPhone.startsWith('+')) {
      if (formattedPhone.startsWith('225')) {
        formattedPhone = '+' + formattedPhone;
      } else {
        formattedPhone = '+225' + formattedPhone;
      }
    }

    try {
      const messageBody = `SANKOFA EDUC: Votre code de confirmation OTP est [${otpCode}]. Entrez ce code pour activer votre abonnement de révision (BAC, BEPC, Concours).`;
      await client.messages.create({
        body: messageBody,
        from: fromNumber,
        to: formattedPhone
      });
      twilioStatus = 'sent';
      console.log(`Real OTP sent successfully via Twilio to ${formattedPhone}`);
    } catch (err: any) {
      console.error('Failed to send real SMS via Twilio:', err);
      twilioStatus = 'failed';
      twilioError = err.message || err;
    }
  }

  res.json({
    success: true,
    transactionId,
    otpCode,
    provider,
    phoneNumber,
    amount: amount || 2000,
    twilioStatus,
    twilioError,
    message: twilioStatus === 'sent' 
      ? 'Paiement mobile initié. Un vrai code de confirmation OTP a été envoyé par SMS à votre numéro.' 
      : 'Paiement mobile initié (Mode Simulation).'
  });
});

// --- VERIFY CINETPAY TRANSACTION STATUS MANUALLY FROM CLIENT ---
app.post('/api/payments/verify-cinetpay', async (req, res) => {
  const { transactionId, userId } = req.body;
  const cinetPay = getCinetPayConfig();
  dbData = loadDB();

  if (!transactionId) {
    return res.status(400).json({ success: false, error: 'transactionId requis.' });
  }

  if (!cinetPay.isConfigured) {
    return res.status(400).json({ success: false, error: 'CinetPay n\'est pas configuré.' });
  }

  try {
    console.log(`Verifying real CinetPay status for transaction: ${transactionId}`);
    
    const cpResponse = await fetch('https://api-checkout.cinetpay.com/v2/payment/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apikey: cinetPay.apiKey,
        site_id: cinetPay.siteId,
        transaction_id: transactionId
      })
    });

    const result = await cpResponse.json();
    console.log(`CinetPay check response for ${transactionId}:`, result);

    if (result.code === '00' && result.data) {
      const status = result.data.status; 
      const amount = Number(result.data.amount) || 2000;
      const paymentMethod = result.data.payment_method || 'Mobile Money';
      const phone = result.data.phone_number || '';

      const pending = dbData.pendingPayments ? dbData.pendingPayments[transactionId] : null;
      const targetUserId = userId || (pending ? pending.userId : null);

      if (status === 'ACCEPTED' || status === 'SUCCES' || status === 'SUCCESS') {
        if (targetUserId) {
          const sub = getUserSubscription(targetUserId);
          const notifications = getUserNotifications(targetUserId);

          sub.isPremium = true;
          sub.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
          sub.paymentMethod = paymentMethod;
          sub.phoneNumber = phone || (pending ? pending.phoneNumber : '');

          const alreadyLogged = sub.history.some((h: any) => h.id === transactionId);
          if (!alreadyLogged) {
            sub.history.unshift({
              id: transactionId,
              amount: amount,
              date: new Date().toISOString(),
              status: 'Succès',
              method: paymentMethod,
              phone: sub.phoneNumber
            });

            notifications.unshift({
              id: `notif-${Date.now()}`,
              title: 'Abonnement Premium Activé ! 🌟',
              body: `Votre paiement réel de ${amount} FCFA via ${paymentMethod} a été validé par CinetPay. Profil premium actif jusqu'au ${new Date(sub.expiresAt).toLocaleDateString('fr-FR')}.`,
              date: new Date().toISOString(),
              read: false,
              type: 'sub'
            });
          }

          if (pending) {
            pending.status = 'Succès';
          }
          saveDB(dbData);

          return res.json({
            success: true,
            status: 'Succès',
            subscription: sub,
            notifications
          });
        } else {
          return res.status(400).json({ success: false, error: 'Paiement accepté mais aucun identifiant d\'élève (userId) n\'a pu être déterminé.' });
        }
      } else {
        if (pending) {
          pending.status = status === 'PENDING' ? 'En attente' : 'Échoué';
          saveDB(dbData);
        }
        return res.json({
          success: false,
          status: status,
          message: `Le paiement est actuellement dans l'état: ${status}`
        });
      }
    } else {
      return res.status(400).json({
        success: false,
        error: `Erreur retournée par CinetPay: ${result.message || 'Inconnue'}`
      });
    }
  } catch (error: any) {
    console.error('Error verifying CinetPay payment:', error);
    return res.status(500).json({ success: false, error: `Erreur de connexion au service CinetPay` });
  }
});

// --- CINETPAY WEBHOOK INSTANT NOTIFICATION URL ---
app.post('/api/payments/cinetpay-webhook', async (req, res) => {
  const { cpm_trans_id, cpm_site_id } = req.body;
  const transactionId = cpm_trans_id;
  const cinetPay = getCinetPayConfig();
  dbData = loadDB();

  console.log('Received CinetPay Webhook Notification:', req.body);

  if (!transactionId || !cinetPay.isConfigured) {
    return res.status(200).send('Ignored');
  }

  try {
    const cpResponse = await fetch('https://api-checkout.cinetpay.com/v2/payment/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apikey: cinetPay.apiKey,
        site_id: cinetPay.siteId,
        transaction_id: transactionId
      })
    });

    const result = await cpResponse.json();
    if (result.code === '00' && result.data) {
      const status = result.data.status;
      const amount = Number(result.data.amount) || 2000;
      const paymentMethod = result.data.payment_method || 'Mobile Money';
      const phone = result.data.phone_number || '';

      if (status === 'ACCEPTED' || status === 'SUCCES' || status === 'SUCCESS') {
        const pending = dbData.pendingPayments ? dbData.pendingPayments[transactionId] : null;
        const targetUserId = result.data.customer_id || (pending ? pending.userId : null);

        if (targetUserId) {
          const sub = getUserSubscription(targetUserId);
          const notifications = getUserNotifications(targetUserId);

          sub.isPremium = true;
          sub.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
          sub.paymentMethod = paymentMethod;
          sub.phoneNumber = phone || (pending ? pending.phoneNumber : '');

          const alreadyLogged = sub.history.some((h: any) => h.id === transactionId);
          if (!alreadyLogged) {
            sub.history.unshift({
              id: transactionId,
              amount: amount,
              date: new Date().toISOString(),
              status: 'Succès',
              method: paymentMethod,
              phone: sub.phoneNumber
            });

            notifications.unshift({
              id: `notif-${Date.now()}`,
              title: 'Abonnement Premium Activé ! 🌟',
              body: `Votre paiement de ${amount} FCFA via ${paymentMethod} a été validé automatiquement par webhook.`,
              date: new Date().toISOString(),
              read: false,
              type: 'sub'
            });
          }

          if (pending) {
            pending.status = 'Succès';
          }
          saveDB(dbData);
          console.log(`Premium activated via CinetPay webhook for user: ${targetUserId}`);
        }
      }
    }
    return res.status(200).send('OK');
  } catch (err) {
    console.error('Error in CinetPay Webhook processing:', err);
    return res.status(500).send('Internal Server Error');
  }
});


// Store active auth OTPs in an in-memory map
const activeAuthOtps = new Map<string, { code: string; expiresAt: number }>();

// Real OTP Authentication endpoints
app.post('/api/auth/send-otp', async (req, res) => {
  const { phoneNumber, email, method, mode, password } = req.body;
  const rawKey = method === 'phone' ? phoneNumber : email;

  if (!rawKey) {
    return res.status(400).json({ success: false, error: 'Identifiant (numéro ou email) requis.' });
  }

  const key = rawKey.toLowerCase().trim();
  dbData = loadDB();
  if (!dbData.registeredUsers) {
    dbData.registeredUsers = {};
  }

  const existingUser = dbData.registeredUsers[key];

  // STRICT RULE: Unregistered users cannot log in directly
  if (mode === 'login') {
    if (!existingUser) {
      return res.status(400).json({
        success: false,
        error: "Cet identifiant n'est pas encore inscrit sur Sankofa Educ. Veuillez créer un compte avant de vous connecter."
      });
    }

    // Verify password if provided
    if (password && existingUser.password && password !== existingUser.password) {
      return res.status(400).json({
        success: false,
        error: "Mot de passe incorrect. Veuillez vérifier votre saisie."
      });
    }
  }

  // Prevent duplicate registration for existing users
  if (mode === 'register') {
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: "Un compte existe déjà avec cet identifiant. Veuillez basculer sur 'Connexion' pour vous connecter."
      });
    }
  }

  // Generate a random 4-digit code
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes from now
  activeAuthOtps.set(key, { code, expiresAt });

  console.log(`\n==============================================`);
  console.log(`[SANKOFA AUTH] OTP Code generated for ${key} (mode: ${mode}): ${code}`);
  console.log(`==============================================\n`);

  if (method === 'phone') {
    // Format number to international format +225XXXXXXXXXX
    let formattedPhone = phoneNumber.replace(/\s+/g, '');
    if (!formattedPhone.startsWith('+')) {
      if (formattedPhone.startsWith('225')) {
        formattedPhone = '+' + formattedPhone;
      } else {
        formattedPhone = '+225' + formattedPhone;
      }
    }

    const messageBody = `SANKOFA EDUC : Votre code de vérification OTP est [${code}]. Saisissez-le pour ${mode === 'register' ? 'finaliser votre inscription' : 'vous connecter'}.`;

    // Try Infobip MCP SMS first
    const infobipSent = await sendSmsViaInfobipMcp(formattedPhone, messageBody);
    if (infobipSent) {
      return res.json({
        success: true,
        twilioSent: false,
        infobipSent: true,
        message: 'Un vrai code OTP de sécurité a été envoyé par SMS à votre numéro.'
      });
    }

    // Fallback to Twilio if Infobip fails or is not configured
    const client = getTwilioClient();
    const fromNumber = process.env.TWILIO_PHONE_NUMBER;

    if (client && fromNumber) {
      try {
        await client.messages.create({
          body: messageBody,
          from: fromNumber,
          to: formattedPhone
        });
        console.log(`Real OTP SMS sent successfully to ${formattedPhone} via Twilio fallback`);
        return res.json({
          success: true,
          twilioSent: true,
          infobipSent: false,
          message: 'Un vrai code OTP de sécurité a été envoyé par SMS à votre numéro.'
        });
      } catch (err: any) {
        console.error('Failed to send real SMS via Twilio fallback in Auth:', err);
        return res.json({
          success: true,
          twilioSent: false,
          infobipSent: false,
          message: `Échec de l'envoi du SMS réel (${err.message || err}). Pour tester en développement, saisissez le code universel : 2255.`
        });
      }
    } else {
      console.log(`Neither Infobip nor Twilio is configured or working. Simulated OTP for ${phoneNumber}: ${code}`);
      return res.json({
        success: true,
        twilioSent: false,
        infobipSent: false,
        message: "Le service d'envoi SMS réel n'est pas configuré. Saisissez le code de test universel '2255' pour continuer."
      });
    }
  } else {
    // Send Real Email OTP via SMTP or Resend
    const result = await sendRealEmailOtp(email, code);
    return res.json({
      success: true,
      emailSent: result.sent,
      code: code,
      message: result.message
    });
  }
});

app.post('/api/auth/verify-otp', (req, res) => {
  const { phoneNumber, email, method, code, mode, name, password, targetExam, series } = req.body;
  const rawKey = method === 'phone' ? phoneNumber : email;

  if (!rawKey || !code) {
    return res.status(400).json({ success: false, error: 'Identifiant et code OTP requis.' });
  }

  const key = rawKey.toLowerCase().trim();
  const stored = activeAuthOtps.get(key);
  if (!stored) {
    return res.status(400).json({ success: false, error: 'Aucun code OTP n\'a été demandé pour cet identifiant ou le code a expiré.' });
  }

  if (Date.now() > stored.expiresAt) {
    activeAuthOtps.delete(key);
    return res.status(400).json({ success: false, error: 'Le code OTP a expiré. Veuillez en demander un nouveau.' });
  }

  // Allow constant backdoor '2255' or the real code
  if (stored.code === code || code === '2255') {
    activeAuthOtps.delete(key); // clear after successful verification

    dbData = loadDB();
    if (!dbData.registeredUsers) {
      dbData.registeredUsers = {};
    }

    let userProfile = dbData.registeredUsers[key];

    if (mode === 'register') {
      userProfile = {
        name: name || key.split('@')[0],
        email: email ? email.toLowerCase().trim() : key,
        phone: phoneNumber || '',
        password: password || '',
        targetExam: targetExam || 'BAC',
        series: series || 'D',
        registeredAt: new Date().toISOString()
      };
      dbData.registeredUsers[key] = userProfile;
      saveDB(dbData);
      console.log(`[AUTH] User successfully registered and saved to database: ${key}`);
    } else {
      if (!userProfile) {
        return res.status(400).json({
          success: false,
          error: "Cet utilisateur n'est pas encore inscrit sur l'application. Veuillez créer un compte."
        });
      }
    }

    return res.json({
      success: true,
      message: mode === 'register' ? 'Compte créé avec succès !' : 'Connexion réussie !',
      user: userProfile
    });
  } else {
    return res.status(400).json({ success: false, error: 'Le code OTP saisi est incorrect.' });
  }
});


app.post('/api/payments/verify', (req, res) => {
  const { transactionId, otpCode, userId } = req.body;
  dbData = loadDB();

  const pending = dbData.pendingPayments ? dbData.pendingPayments[transactionId] : null;
  if (!pending) {
    return res.status(404).json({ success: false, error: 'Transaction non trouvée ou expirée.' });
  }

  if (otpCode && pending.otpCode !== otpCode) {
    return res.status(400).json({ success: false, error: 'Code de confirmation OTP incorrect.' });
  }

  // Update subscription properties
  const sub = getUserSubscription(userId || pending.userId);
  const notifications = getUserNotifications(userId || pending.userId);

  const providerName = pending.provider === 'wave' ? 'Wave' : pending.provider === 'orange' ? 'Orange Money' : 'MTN MoMo';

  sub.isPremium = true;
  sub.expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
  sub.paymentMethod = providerName;
  sub.phoneNumber = pending.phoneNumber;

  // Record payment in local database history
  sub.history.unshift({
    id: transactionId,
    amount: pending.amount,
    date: new Date().toISOString(),
    status: 'Succès',
    method: providerName,
    phone: pending.phoneNumber
  });

  // Create notifications to push into local list
  notifications.unshift({
    id: `notif-${Date.now()}`,
    title: 'Abonnement Premium Activé ! 🌟',
    body: `Votre paiement de ${pending.amount} FCFA via ${providerName} a été validé. Profil premium actif jusqu'au ${new Date(sub.expiresAt).toLocaleDateString('fr-FR')}.`,
    date: new Date().toISOString(),
    read: false,
    type: 'sub'
  });

  pending.status = 'Succès';
  saveDB(dbData);

  res.json({
    success: true,
    status: 'Succès',
    subscription: sub,
    notifications
  });
});

// --- VITE MIDDLEWARE SETUP ---

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      maxAge: '1y',
      etag: true,
      lastModified: true,
      setHeaders: (res, pathName) => {
        if (pathName.endsWith('.html')) {
          res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
        } else {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          res.setHeader('CDN-Cache-Control', 'public, max-age=31536000');
        }
      }
    }));
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
