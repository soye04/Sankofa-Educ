# Security Specification & "Dirty Dozen" Audit

This document establishes the security guidelines, invariants, and test payload boundaries for Firestore rules on Sankofa Educ.

## 1. Data Invariants

1. **Identity Integrity**: No student can write, read, or list profiles, progress metrics, subscriptions, or notifications belonging to any other user UID.
2. **Schema Correctness**: Write operations (creation and modifications) must strictly conform to the expected properties, sizes, and formats.
3. **No Field Spoofing**: Users cannot inject arbitrary fields or self-escalate their subscriptions to premium without satisfying API checks.
4. **Id Sanitization**: Path and document IDs must follow strict format rules to prevent resource exhaustion or Denial of Wallet attacks.

---

## 2. The Dirty Dozen Payloads (Negative Tests)

The following payloads represent malicious attempts to bypass security policies. Our rules are mathematically modeled to return `PERMISSION_DENIED` for all these cases.

### Payload 1: Profile Theft (Identity Spoofing)
An authenticated user `attacker-uid` attempts to read user profile `victim-uid`.
```json
// GET /users/victim-uid
// Expected result: PERMISSION_DENIED
```

### Payload 2: Profile Spoofing
An authenticated user `attacker-uid` attempts to register a profile under `victim-uid`'s path.
```json
// CREATE /users/victim-uid
{
  "userId": "victim-uid",
  "email": "victim@gmail.com",
  "name": "Victim student",
  "targetExam": "BAC",
  "series": "D"
}
// Expected result: PERMISSION_DENIED
```

### Payload 3: Privilege Escalation
A user attempts to create a premium subscription status bypassing real gateway logs.
```json
// CREATE /users/student-123/subscription/status
{
  "userId": "student-123",
  "isPremium": true,
  "trialEndsAt": "2026-07-18T17:20:35.000Z",
  "expiresAt": "2028-10-10T00:00:00.000Z",
  "paymentMethod": "Wave",
  "unauthorizedField": "bypass_flag"
}
// Expected result: PERMISSION_DENIED (Due to keys size gate)
```

### Payload 4: Invalid Exam Format
A user attempts to submit an unsupported exam type.
```json
// CREATE /users/student-123
{
  "userId": "student-123",
  "email": "student@gmail.com",
  "name": "Jean",
  "targetExam": "A_LEVELS_BANNED",
  "series": "D"
}
// Expected result: PERMISSION_DENIED
```

### Payload 5: Giant Username Payload (Denial of Wallet)
An attacker tries to post a 1MB string into the student's name attribute to exhaust space.
```json
// CREATE /users/student-123
{
  "userId": "student-123",
  "email": "student@gmail.com",
  "name": "[1MB string of characters...]",
  "targetExam": "BAC",
  "series": "D"
}
// Expected result: PERMISSION_DENIED (Size check failure)
```

### Payload 6: Shadow Update Ghost Fields
An attacker modifies their progress and injects an unverified/banned schema field `isAdministrator: true`.
```json
// UPDATE /users/student-123/progress/metrics
{
  "userId": "student-123",
  "quizCount": 5,
  "studyTimeMinutes": 120,
  "streakDays": 4,
  "isAdministrator": true
}
// Expected result: PERMISSION_DENIED
```

### Payload 7: Orphaned Notification Hijack
An attacker attempts to write an notification document with a mismatched userId.
```json
// CREATE /users/student-123/notifications/notif-abc
{
  "id": "notif-abc",
  "userId": "victim-uid",
  "title": "Hack Alert",
  "body": "Spam details",
  "read": false,
  "type": "info",
  "date": "2026-07-11T17:20:35.000Z"
}
// Expected result: PERMISSION_DENIED
```

### Payload 8: Path ID Poisoning
An attacker attempts to inject a dangerous path string containing directory traversals or special characters into subcollections.
```json
// CREATE /users/student-123/notifications/../../../etc/passwd
// Expected result: PERMISSION_DENIED
```

### Payload 9: Blanket Reading Progress List
An authenticated attacker attempts to query or list the complete progress records of other students.
```json
// LIST /users (Without specific UID)
// Expected result: PERMISSION_DENIED
```

### Payload 10: Notification Title Overflow
A client attempts to create an excessively long notification title.
```json
// CREATE /users/student-123/notifications/notif-1
{
  "id": "notif-1",
  "userId": "student-123",
  "title": "[A string of 300 characters...]",
  "body": "Normal body",
  "read": false,
  "type": "info",
  "date": "2026-07-11T17:20:35.000Z"
}
// Expected result: PERMISSION_DENIED (Size check failure)
```

### Payload 11: Immutable Field Mutation
An existing user attempts to change their immutable `userId` on progress metrics after document creation.
```json
// UPDATE /users/student-123/progress/metrics
{
  "userId": "attacker-uid",
  "quizCount": 10,
  "studyTimeMinutes": 300,
  "streakDays": 5
}
// Expected result: PERMISSION_DENIED
```

### Payload 12: Notification Type Spoofing
A user attempts to post a notification of an illegal type.
```json
// CREATE /users/student-123/notifications/notif-1
{
  "id": "notif-1",
  "userId": "student-123",
  "title": "Title",
  "body": "Body text",
  "read": false,
  "type": "SUPER_ADMIN_BANNER",
  "date": "2026-07-11T17:20:35.000Z"
}
// Expected result: PERMISSION_DENIED
```
